import { MetadataRoute } from "next";
import { CALCULATORS, SITE_CONFIG } from "@/lib/config";

// Use a fixed date so the sitemap is deterministic across builds.
// Update this when content changes significantly.
const LAST_UPDATED = new Date("2025-01-01");

export default function sitemap(): MetadataRoute.Sitemap {
  const staticRoutes: MetadataRoute.Sitemap = [
    {
      url: SITE_CONFIG.url,
      lastModified: LAST_UPDATED,
      changeFrequency: "weekly",
      priority: 1.0,
    },
    {
      // Hub page for all calculators — important for internal link equity
      url: `${SITE_CONFIG.url}/calculadoras`,
      lastModified: LAST_UPDATED,
      changeFrequency: "weekly",
      priority: 0.9,
    },
    {
      url: `${SITE_CONFIG.url}/contacto`,
      lastModified: LAST_UPDATED,
      changeFrequency: "monthly",
      priority: 0.4,
    },
    {
      url: `${SITE_CONFIG.url}/legal/privacidad`,
      lastModified: LAST_UPDATED,
      changeFrequency: "yearly",
      priority: 0.2,
    },
    {
      url: `${SITE_CONFIG.url}/legal/cookies`,
      lastModified: LAST_UPDATED,
      changeFrequency: "yearly",
      priority: 0.2,
    },
    {
      url: `${SITE_CONFIG.url}/legal/terminos`,
      lastModified: LAST_UPDATED,
      changeFrequency: "yearly",
      priority: 0.2,
    },
  ];

  const calculatorRoutes: MetadataRoute.Sitemap = CALCULATORS.map((calc) => ({
    url: `${SITE_CONFIG.url}${calc.href}`,
    lastModified: LAST_UPDATED,
    changeFrequency: "monthly" as const,
    priority: calc.featured ? 0.9 : 0.8,
  }));

  return [...staticRoutes, ...calculatorRoutes];
}
