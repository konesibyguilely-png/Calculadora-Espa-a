"use client";

import { useState, useMemo } from "react";
import { formatNumber } from "@/lib/utils";

interface Subject {
  id: string;
  name: string;
  grade: string;
  credits: number;
  isCore: boolean;
}

const DEFAULT_SUBJECTS: Subject[] = [
  { id: "1", name: "Lengua Castellana y Literatura", grade: "", credits: 4, isCore: true },
  { id: "2", name: "Lengua Extranjera (Inglés)", grade: "", credits: 3, isCore: true },
  { id: "3", name: "Historia de España", grade: "", credits: 3, isCore: true },
  { id: "4", name: "Filosofía", grade: "", credits: 2, isCore: true },
  { id: "5", name: "Educación Física", grade: "", credits: 2, isCore: false },
  { id: "6", name: "Materia de modalidad 1", grade: "", credits: 4, isCore: false },
  { id: "7", name: "Materia de modalidad 2", grade: "", credits: 4, isCore: false },
  { id: "8", name: "Materia de modalidad 3", grade: "", credits: 4, isCore: false },
  { id: "9", name: "Optativa", grade: "", credits: 2, isCore: false },
];

export function BachilleratoCalculator() {
  const [subjects, setSubjects] = useState<Subject[]>(DEFAULT_SUBJECTS);
  const [weighted, setWeighted] = useState(true);

  const updateGrade = (id: string, grade: string) => {
    setSubjects((prev) => prev.map((s) => (s.id === id ? { ...s, grade } : s)));
  };

  const updateName = (id: string, name: string) => {
    setSubjects((prev) => prev.map((s) => (s.id === id ? { ...s, name } : s)));
  };

  const results = useMemo(() => {
    const valid = subjects.filter((s) => {
      const g = parseFloat(s.grade.replace(",", "."));
      return !isNaN(g) && g >= 0 && g <= 10;
    });

    if (valid.length === 0) return null;

    let avg: number;
    if (weighted) {
      const totalCredits = valid.reduce((acc, s) => acc + s.credits, 0);
      const weightedSum = valid.reduce((acc, s) => acc + parseFloat(s.grade.replace(",", ".")) * s.credits, 0);
      avg = totalCredits > 0 ? weightedSum / totalCredits : 0;
    } else {
      avg = valid.reduce((acc, s) => acc + parseFloat(s.grade.replace(",", ".")), 0) / valid.length;
    }

    const highest = [...valid].sort((a, b) =>
      parseFloat(b.grade.replace(",", ".")) - parseFloat(a.grade.replace(",", "."))
    )[0];
    const lowest = [...valid].sort((a, b) =>
      parseFloat(a.grade.replace(",", ".")) - parseFloat(b.grade.replace(",", "."))
    )[0];

    return { avg, highest, lowest, count: valid.length };
  }, [subjects, weighted]);

  const gradeLabel = (g: number) => {
    if (g >= 9) return { label: "Sobresaliente", color: "text-green-700 bg-green-100" };
    if (g >= 7) return { label: "Notable", color: "text-blue-700 bg-blue-100" };
    if (g >= 6) return { label: "Bien", color: "text-teal-700 bg-teal-100" };
    if (g >= 5) return { label: "Aprobado", color: "text-yellow-700 bg-yellow-100" };
    return { label: "Suspenso", color: "text-red-700 bg-red-100" };
  };

  return (
    <div className="card p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <input type="checkbox" id="weighted" checked={weighted}
            onChange={(e) => setWeighted(e.target.checked)}
            className="w-4 h-4 accent-brand-600 rounded" />
          <label htmlFor="weighted" className="text-sm font-medium text-neutral-700 cursor-pointer">
            Media ponderada por créditos
          </label>
        </div>
      </div>

      <div className="space-y-2">
        <div className="grid grid-cols-12 gap-2 text-xs font-semibold text-neutral-500 px-3">
          <span className="col-span-6">Asignatura</span>
          <span className="col-span-2 text-center">Créditos</span>
          <span className="col-span-4 text-center">Nota</span>
        </div>
        {subjects.map((subject) => {
          const grade = parseFloat(subject.grade.replace(",", "."));
          const hasGrade = !isNaN(grade);
          return (
            <div key={subject.id}
              className={`grid grid-cols-12 gap-2 items-center bg-neutral-50 rounded-xl p-2 ${
                hasGrade && grade < 5 ? "bg-red-50" : ""
              }`}>
              <div className="col-span-6">
                <input
                  type="text"
                  value={subject.name}
                  onChange={(e) => updateName(subject.id, e.target.value)}
                  className="w-full text-sm bg-transparent border-none focus:outline-none text-neutral-700 font-medium"
                />
              </div>
              <div className="col-span-2 text-center">
                <span className="text-xs text-neutral-400">{subject.credits}h</span>
              </div>
              <div className="col-span-4">
                <input
                  type="number"
                  inputMode="decimal"
                  placeholder="0-10"
                  value={subject.grade}
                  onChange={(e) => updateGrade(subject.id, e.target.value)}
                  className="w-full px-3 py-1.5 text-sm border border-neutral-300 rounded-lg text-center font-semibold
                             focus:outline-none focus:ring-2 focus:ring-brand-400 focus:border-brand-400 bg-white"
                  min="0" max="10" step="0.1"
                />
              </div>
            </div>
          );
        })}
      </div>

      {results ? (
        <div className="space-y-3">
          <div className="result-box text-center py-5">
            <p className="result-label text-sm mb-1">Nota media de Bachillerato</p>
            <p className="text-5xl font-bold text-brand-700 tabular-nums">
              {formatNumber(results.avg, 2)}
            </p>
            <span className={`inline-block mt-2 px-3 py-0.5 rounded-full text-sm font-semibold ${gradeLabel(results.avg).color}`}>
              {gradeLabel(results.avg).label}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="bg-green-50 rounded-xl p-3">
              <p className="text-xs text-green-500">Mejor nota</p>
              <p className="font-bold text-green-800">{results.highest.name}</p>
              <p className="text-lg font-bold text-green-700">{results.highest.grade}</p>
            </div>
            <div className="bg-red-50 rounded-xl p-3">
              <p className="text-xs text-red-500">Nota más baja</p>
              <p className="font-bold text-red-800">{results.lowest.name}</p>
              <p className="text-lg font-bold text-red-700">{results.lowest.grade}</p>
            </div>
          </div>
          <p className="text-xs text-neutral-400 text-center">
            Calculada sobre {results.count} de {subjects.length} asignaturas
          </p>
        </div>
      ) : (
        <div className="bg-neutral-50 rounded-2xl p-8 text-center">
          <p className="text-4xl mb-3">📖</p>
          <p className="text-neutral-500 text-sm">Introduce tus notas para calcular tu media de Bachillerato</p>
        </div>
      )}
    </div>
  );
}
