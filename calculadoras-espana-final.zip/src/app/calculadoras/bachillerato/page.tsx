import type { Metadata } from "next";
import { BachilleratoCalculator } from "./BachilleratoCalculator";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { FAQ } from "@/components/ui/FAQ";
import { AdPlaceholder } from "@/components/ui/AdSense";
import { CalculatorCard } from "@/components/ui/CalculatorCard";
import { CALCULATORS, SITE_CONFIG } from "@/lib/config";

export const metadata: Metadata = {
  title: "Calculadora Nota Media Bachillerato — Media Ponderada Gratis",
  description:
    "Calcula tu nota media de Bachillerato con ponderación por créditos. Editable por asignatura. Imprescindible para conocer tu nota de acceso a la EVAU.",
  twitter: {
    card: "summary_large_image",
    title: "Calculadora Bachillerato 2025",
    description: "Calcula tu nota media de Bachillerato ponderada por horas semanales.",
    images: ["/og-image.png"],
  },
  alternates: { canonical: `${SITE_CONFIG.url}/calculadoras/bachillerato` },
  openGraph: {
    title: "Calculadora Nota Media Bachillerato 2025",
    description: "Calcula tu nota media de Bachillerato con ponderación por créditos.",
    url: `${SITE_CONFIG.url}/calculadoras/bachillerato`,
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "Calculadora Nota Media Bachillerato 2025",
      },
    ],
  },

};

const FAQ_ITEMS = [
  {
    question: "¿Cómo se calcula la nota media de Bachillerato?",
    answer:
      "La nota media de Bachillerato se calcula como la media ponderada de todas las asignaturas cursadas en 1.º y 2.º de Bachillerato. Se suman las notas de cada asignatura multiplicadas por sus horas semanales (créditos) y se divide entre el total de horas. El resultado se expresa con dos decimales.",
  },
  {
    question: "¿Qué nota media necesito en Bachillerato para ir a la universidad?",
    answer:
      "No existe una nota mínima de Bachillerato para presentarse a la EVAU, pero sí se necesita haberlo aprobado (media de 5 o superior). La nota de Bachillerato pondera el 60% en la nota de acceso a la universidad.",
  },
  {
    question: "¿Se tienen en cuenta las notas de 1.º y 2.º de Bachillerato?",
    answer:
      "Sí. La nota media del expediente de Bachillerato incluye todas las asignaturas de ambos cursos. Es la nota que aparece en el título de Bachillerato y la que se usa para el cálculo de la nota de acceso a la EVAU (ponderación del 60%).",
  },
  {
    question: "¿Las asignaturas optativas cuentan para la nota media?",
    answer:
      "Sí, todas las asignaturas cursadas en Bachillerato, incluidas las optativas, cuentan para el cálculo de la nota media del expediente académico.",
  },
  {
    question: "¿Cuándo se calcula la nota media de Bachillerato?",
    answer:
      "La nota media del expediente de Bachillerato se calcula al finalizar el segundo curso, una vez superadas todas las asignaturas de ambos cursos. Es la nota que aparece en el título de Bachillerato y la que comunica el centro al sistema de acceso universitario (PAU/EVAU).",
  },
  {
    question: "¿Influye el tipo de centro (público vs privado) en la nota?",
    answer:
      "No existe una diferencia oficial en la valoración de la nota de Bachillerato según el tipo de centro. Sin embargo, las universidades pueden aplicar criterios de admisión propios para determinados grados. La nota de la EVAU sí es una prueba externa e igual para todos, lo que actúa como nivelador entre centros.",
  },
];

const RELATED = CALCULATORS.filter((c) => ["evau", "edad"].includes(c.id));

const schema = {
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  name: "Calculadora Nota Media Bachillerato",
  applicationCategory: "EducationApplication",
  operatingSystem: "Web",
  browserRequirements: "Requires JavaScript",
  inLanguage: "es",
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "EUR",
    availability: "https://schema.org/InStock",
  },
  description: metadata.description,
  url: `${SITE_CONFIG.url}/calculadoras/bachillerato`,
  author: {
    "@type": "Organization",
    name: SITE_CONFIG.name,
    url: SITE_CONFIG.url,
  },
};

export default function BachilleratoPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
      />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Breadcrumb
          items={[
            { name: "Calculadoras", href: "/calculadoras" },
            { name: "Educación", href: "/calculadoras#educacion" },
            { name: "Nota Media Bachillerato", href: "/calculadoras/bachillerato" },
          ]}
        />
        <AdPlaceholder label="Publicidad — 728×90" height={90} />

        <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="mb-6">
              <div className="flex items-center gap-3 mb-3">
                <span className="text-4xl">📖</span>
                <div>
                  <h1 className="text-3xl sm:text-4xl font-bold text-neutral-900">
                    Calculadora Bachillerato
                  </h1>
                  <p className="text-neutral-500 mt-0.5">Nota media ponderada · 2025</p>
                </div>
              </div>
              <p className="text-neutral-600 leading-relaxed">
                Calcula tu nota media de Bachillerato con ponderación por horas semanales.
                Edita el nombre de cada asignatura y obtén tu nota exacta de expediente.
              </p>
            </div>

            <BachilleratoCalculator />

            <section className="mt-8 card p-6">
              <h2 className="text-xl font-bold text-neutral-900 mb-4">
                Fórmula de la nota media ponderada
              </h2>
              <div className="bg-neutral-50 border border-neutral-200 rounded-xl p-4 font-mono text-sm mb-4">
                <p className="font-bold text-neutral-900">
                  Media = Σ (Nota_i × Créditos_i) / Σ Créditos_i
                </p>
              </div>
              <div className="bg-brand-50 border border-brand-100 rounded-xl p-4 text-sm">
                <p className="font-semibold text-brand-800 mb-2">Ejemplo:</p>
                <ul className="space-y-1 text-brand-700">
                  <li>Lengua (4h) × 8 = 32</li>
                  <li>Inglés (3h) × 9 = 27</li>
                  <li>Historia (3h) × 7 = 21</li>
                  <li className="font-bold pt-1 border-t border-brand-200">
                    Media = 80 / 10 = <span className="text-brand-900">8,00</span>
                  </li>
                </ul>
              </div>
            </section>

            {/* Tabla de asignaturas por modalidad */}
            <section className="mt-6 card p-6 overflow-x-auto" aria-labelledby="asignaturas-bach">
              <h2 id="asignaturas-bach" className="text-xl font-bold text-neutral-900 mb-4">
                Asignaturas de Bachillerato y horas semanales
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                <div>
                  <h3 className="font-semibold text-neutral-800 mb-2 text-sm">Materias comunes</h3>
                  <div className="space-y-1">
                    {[
                      { name: "Lengua Castellana y Literatura", hours: 4 },
                      { name: "Lengua Extranjera (Inglés/Francés)", hours: 3 },
                      { name: "Historia de España (2.º)", hours: 3 },
                      { name: "Filosofía (1.º) / Historia de la Filosofía (2.º)", hours: 2 },
                      { name: "Educación Física (1.º)", hours: 2 },
                      { name: "Lengua cooficial (CCAA bilingües)", hours: 2 },
                    ].map((item) => (
                      <div key={item.name} className="flex justify-between text-xs py-1 border-b border-neutral-100">
                        <span className="text-neutral-700">{item.name}</span>
                        <span className="font-semibold text-brand-700 ml-2">{item.hours}h</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <h3 className="font-semibold text-neutral-800 mb-2 text-sm">Modalidades disponibles</h3>
                  <div className="space-y-2">
                    {[
                      { modal: "Ciencias", desc: "Matemáticas, Física, Química, Biología" },
                      { modal: "Humanidades y CC.SS.", desc: "Historia, Economía, Latín, Geografía" },
                      { modal: "Artes", desc: "Dibujo Artístico, Diseño, Música" },
                    ].map((item) => (
                      <div key={item.modal} className="bg-neutral-50 rounded-lg p-2">
                        <p className="font-semibold text-neutral-800 text-xs">{item.modal}</p>
                        <p className="text-neutral-500 text-xs">{item.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-xs text-neutral-400 mt-3">* Las horas pueden variar ligeramente según la comunidad autónoma y el centro educativo.</p>
            </section>

            {/* Escala de calificaciones */}
            <section className="mt-6 card p-6" aria-labelledby="escala-notas">
              <h2 id="escala-notas" className="text-xl font-bold text-neutral-900 mb-4">
                Escala de calificaciones en Bachillerato
              </h2>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-neutral-50">
                      <th className="text-left p-3 font-semibold text-neutral-700">Nota</th>
                      <th className="text-left p-3 font-semibold text-neutral-700">Calificación</th>
                      <th className="text-left p-3 font-semibold text-neutral-700">Nivel EVAU</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {[
                      { range: "9,0 – 10", label: "Sobresaliente", evau: "Excelente base para EVAU" },
                      { range: "7,0 – 8,9", label: "Notable", evau: "Buena posición para la mayoría de grados" },
                      { range: "6,0 – 6,9", label: "Bien", evau: "Acceso a grados con corte medio-bajo" },
                      { range: "5,0 – 5,9", label: "Suficiente (Aprobado)", evau: "Mínimo para presentarse a la EVAU" },
                      { range: "< 5,0", label: "Insuficiente (Suspenso)", evau: "No se puede presentar a la EVAU" },
                    ].map((row) => (
                      <tr key={row.range} className="hover:bg-neutral-50">
                        <td className="p-3 font-mono font-semibold text-neutral-800">{row.range}</td>
                        <td className="p-3 text-neutral-700">{row.label}</td>
                        <td className="p-3 text-neutral-500 text-xs">{row.evau}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>


            <div className="mt-6">
              <FAQ items={FAQ_ITEMS} title="Preguntas sobre la nota media de Bachillerato" />

            {/* Enlace interno contextual */}
            <div className="mt-6 bg-neutral-50 border border-neutral-200 rounded-2xl p-5">
              <p className="text-sm text-neutral-600">
                Con tu nota media calculada, estima tu nota de acceso a la universidad con la{" "}
                <a href="/calculadoras/evau" className="text-brand-600 hover:underline font-semibold">calculadora EVAU</a>
                , que incluye la Fase General y Específica con ponderaciones reales.
              </p>
            </div>
            </div>
          </div>

          <aside className="space-y-5">
            <AdPlaceholder label="Publicidad — 300×250" height={250} />
            <div className="card p-5">
              <h3 className="font-semibold text-neutral-900 mb-3">Relación con la EVAU</h3>
              <div className="space-y-2.5 text-sm">
                <div className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-brand-100 text-brand-700 text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">1</span>
                  <p className="text-neutral-600">Tu nota media pondera un <strong>60%</strong> en la nota de acceso</p>
                </div>
                <div className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-brand-100 text-brand-700 text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">2</span>
                  <p className="text-neutral-600">La Fase General de la EVAU aporta hasta <strong>4 puntos</strong></p>
                </div>
                <div className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-green-100 text-green-700 text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">+</span>
                  <p className="text-neutral-600">La Fase Específica suma hasta <strong>4 puntos</strong> más</p>
                </div>
              </div>
            </div>
            <div className="card p-5">
              <h3 className="font-semibold text-neutral-900 mb-3">Calculadoras relacionadas</h3>
              <div className="space-y-2">
                {RELATED.map((calc) => (
                  <CalculatorCard key={calc.id} icon={calc.icon} name={calc.name} description={calc.description} href={calc.href} />
                ))}
              </div>
            </div>
            <AdPlaceholder label="Publicidad — 300×600" height={300} />
          </aside>
        </div>
      </div>
    </>
  );
}
