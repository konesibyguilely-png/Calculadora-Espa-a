"use client";

import { useState, useMemo } from "react";
import { formatCurrency, formatNumber } from "@/lib/utils";

interface AmortizationRow {
  month: number;
  payment: number;
  principal: number;
  interest: number;
  balance: number;
}

export function HipotecaCalculator() {
  const [capital, setCapital] = useState("200000");
  const [interest, setInterest] = useState("3.5");
  const [years, setYears] = useState("30");
  const [showTable, setShowTable] = useState(false);

  const results = useMemo(() => {
    const P = parseFloat(capital.replace(",", ".")) || 0;
    const r = (parseFloat(interest.replace(",", ".")) || 0) / 100 / 12;
    const n = (parseInt(years) || 0) * 12;

    if (P <= 0 || r <= 0 || n <= 0) return null;

    // French amortization (cuota fija)
    const monthlyPayment = (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    const totalPayment = monthlyPayment * n;
    const totalInterest = totalPayment - P;

    // First year amortization table
    const table: AmortizationRow[] = [];
    let balance = P;
    for (let month = 1; month <= Math.min(n, 12); month++) {
      const interestPayment = balance * r;
      const principalPayment = monthlyPayment - interestPayment;
      balance -= principalPayment;
      table.push({
        month,
        payment: monthlyPayment,
        principal: principalPayment,
        interest: interestPayment,
        balance: Math.max(0, balance),
      });
    }

    return {
      monthlyPayment,
      totalPayment,
      totalInterest,
      table,
      n,
      P,
    };
  }, [capital, interest, years]);

  return (
    <div className="card p-6">
      {/* Inputs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div>
          <label className="input-label">Capital prestado (€)</label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400 font-medium text-sm">€</span>
            <input
              type="number"
              inputMode="numeric"
              value={capital}
              onChange={(e) => setCapital(e.target.value)}
              className="input-field pl-8"
              min="1000"
              max="10000000"
              step="1000"
            />
          </div>
        </div>

        <div>
          <label className="input-label">Tipo de interés anual (%)</label>
          <div className="relative">
            <input
              type="number"
              inputMode="decimal"
              value={interest}
              onChange={(e) => setInterest(e.target.value)}
              className="input-field pr-8"
              min="0.1"
              max="30"
              step="0.1"
            />
            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-neutral-400 font-medium text-sm">%</span>
          </div>
        </div>

        <div>
          <label className="input-label">Plazo (años)</label>
          <select
            value={years}
            onChange={(e) => setYears(e.target.value)}
            className="input-field"
          >
            {[5, 10, 15, 20, 25, 30, 35, 40].map((y) => (
              <option key={y} value={y}>{y} años</option>
            ))}
          </select>
        </div>
      </div>

      {/* Slider for capital */}
      <div className="mb-6">
        <div className="flex justify-between text-xs text-neutral-500 mb-1">
          <span>10.000€</span>
          <span className="font-semibold text-neutral-700">Capital: {formatCurrency(parseFloat(capital) || 0)}</span>
          <span>1.000.000€</span>
        </div>
        <input
          type="range"
          min="10000"
          max="1000000"
          step="5000"
          value={capital}
          onChange={(e) => setCapital(e.target.value)}
          className="w-full h-2 bg-neutral-200 rounded-full appearance-none cursor-pointer accent-brand-600"
        />
      </div>

      {/* Results */}
      {results ? (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
            <div className="result-box text-center">
              <p className="result-label text-xs">Cuota mensual</p>
              <p className="result-value text-2xl sm:text-3xl">
                {formatCurrency(results.monthlyPayment)}
              </p>
              <p className="text-xs text-brand-400 mt-0.5">al mes</p>
            </div>
            <div className="bg-gradient-to-br from-accent-50 to-orange-50 border border-accent-200 rounded-2xl p-4 text-center">
              <p className="text-xs font-medium text-accent-500">Total intereses</p>
              <p className="text-2xl sm:text-3xl font-bold text-accent-700 tabular-nums">
                {formatCurrency(results.totalInterest)}
              </p>
              <p className="text-xs text-accent-400 mt-0.5">a pagar de más</p>
            </div>
            <div className="bg-gradient-to-br from-red-50 to-pink-50 border border-red-200 rounded-2xl p-4 text-center">
              <p className="text-xs font-medium text-red-500">Total a pagar</p>
              <p className="text-2xl sm:text-3xl font-bold text-red-700 tabular-nums">
                {formatCurrency(results.totalPayment)}
              </p>
              <p className="text-xs text-red-400 mt-0.5">en {years} años</p>
            </div>
          </div>

          {/* Visual ratio */}
          <div className="bg-neutral-50 rounded-xl p-4 mb-4">
            <div className="flex justify-between text-xs font-semibold mb-2">
              <span className="text-brand-600">Capital: {formatCurrency(results.P)}</span>
              <span className="text-accent-600">Intereses: {formatCurrency(results.totalInterest)}</span>
            </div>
            <div className="h-3 bg-neutral-200 rounded-full overflow-hidden flex">
              <div
                className="bg-brand-500 h-full rounded-l-full transition-all duration-500"
                style={{ width: `${(results.P / results.totalPayment) * 100}%` }}
              />
              <div
                className="bg-accent-400 h-full rounded-r-full"
                style={{ width: `${(results.totalInterest / results.totalPayment) * 100}%` }}
              />
            </div>
            <p className="text-xs text-neutral-500 mt-2 text-center">
              De cada euro pagado, {formatNumber((results.P / results.totalPayment) * 100, 0)}% es capital y {formatNumber((results.totalInterest / results.totalPayment) * 100, 0)}% son intereses
            </p>
          </div>

          {/* Amortization table toggle */}
          <button
            onClick={() => setShowTable(!showTable)}
            className="btn-secondary w-full text-sm py-2.5"
          >
            {showTable ? "Ocultar" : "Ver"} tabla de amortización (1er año)
          </button>

          {showTable && (
            <div className="mt-4 overflow-x-auto">
              <table className="w-full text-xs sm:text-sm">
                <thead>
                  <tr className="bg-neutral-50">
                    <th className="text-left p-2.5 font-semibold text-neutral-600">Mes</th>
                    <th className="text-right p-2.5 font-semibold text-neutral-600">Cuota</th>
                    <th className="text-right p-2.5 font-semibold text-neutral-600">Capital</th>
                    <th className="text-right p-2.5 font-semibold text-neutral-600">Intereses</th>
                    <th className="text-right p-2.5 font-semibold text-neutral-600">Saldo</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {results.table.map((row) => (
                    <tr key={row.month} className="hover:bg-neutral-50">
                      <td className="p-2.5 text-neutral-700">{row.month}</td>
                      <td className="p-2.5 text-right font-medium text-neutral-800">{formatCurrency(row.payment)}</td>
                      <td className="p-2.5 text-right text-brand-600">{formatCurrency(row.principal)}</td>
                      <td className="p-2.5 text-right text-accent-600">{formatCurrency(row.interest)}</td>
                      <td className="p-2.5 text-right text-neutral-700">{formatCurrency(row.balance)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      ) : (
        <div className="bg-neutral-50 rounded-2xl p-8 text-center">
          <p className="text-4xl mb-3">🏠</p>
          <p className="text-neutral-500 text-sm">Introduce los datos de tu hipoteca para ver el resultado</p>
        </div>
      )}
    </div>
  );
}
