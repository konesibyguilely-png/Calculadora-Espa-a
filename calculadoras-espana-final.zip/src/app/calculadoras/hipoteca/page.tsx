import type { Metadata } from "next";
import { HipotecaCalculator } from "./HipotecaCalculator";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { FAQ } from "@/components/ui/FAQ";
import { AdPlaceholder, AffiliateBlock } from "@/components/ui/AdSense";
import { CalculatorCard } from "@/components/ui/CalculatorCard";
import { CALCULATORS, SITE_CONFIG } from "@/lib/config";

export const metadata: Metadata = {
  title: "Calculadora de Hipoteca 2025 — Cuota Mensual y Tabla de Amortización",
  description:
    "Calcula la cuota mensual de tu hipoteca, el total de intereses y la tabla de amortización completa. Simulador actualizado con tipos de 2025. Incluye comparativa fija vs variable, gastos y guía para elegir la mejor hipoteca.",
  alternates: { canonical: `${SITE_CONFIG.url}/calculadoras/hipoteca` },
  openGraph: {
    title: "Calculadora de Hipoteca 2025 — Cuota Mensual y Total de Intereses",
    description:
      "Simula tu hipoteca al instante: cuota mensual, intereses totales y tabla de amortización. Incluye comparativa fija vs variable.",
    url: `${SITE_CONFIG.url}/calculadoras/hipoteca`,
    images: [{ url: "/og-image.png", width: 1200, height: 630, alt: "Calculadora de Hipoteca 2025 — Calculadoras España" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Calculadora de Hipoteca 2025",
    description: "Cuota mensual, intereses totales y tabla de amortización de tu hipoteca en España.",
    images: ["/og-image.png"],
  },
};

const FAQ_ITEMS = [
  {
    question: "¿Cómo se calcula la cuota mensual de una hipoteca?",
    answer:
      "La cuota mensual de una hipoteca de tipo fijo se calcula con la fórmula de anualidad francesa: Cuota = Capital × [r(1+r)^n] / [(1+r)^n - 1], donde r es el tipo de interés mensual (TIN anual / 12) y n es el número de cuotas totales. Esta fórmula garantiza cuotas constantes durante toda la vida del préstamo, de ahí el nombre de 'sistema francés de amortización'. En hipotecas variables, la cuota se recalcula periódicamente cuando varía el euríbor.",
  },
  {
    question: "¿Qué diferencia hay entre TIN y TAE en una hipoteca?",
    answer:
      "El TIN (Tipo de Interés Nominal) es el interés puro del préstamo. La TAE (Tasa Anual Equivalente) incluye el TIN más todos los gastos y comisiones asociados, siendo el indicador más completo para comparar hipotecas. Desde la Ley Hipotecaria de 2019, los bancos también deben proporcionar la FEIN (Ficha Europea de Información Normalizada), que detalla todos los costes reales. Cuando compares hipotecas, usa siempre la TAE y no el TIN.",
  },
  {
    question: "¿Cuánto debería pagar como máximo por mi hipoteca?",
    answer:
      "La recomendación general de los expertos financieros es que la cuota mensual no supere el 30-35% de tus ingresos netos mensuales. Por ejemplo, si cobras 2.500€ netos al mes, tu cuota no debería superar los 750-875€. Los bancos también aplican este criterio (ratio de endeudamiento) al conceder hipotecas. Además, lo habitual es que el banco financie como máximo el 80% del valor de tasación, por lo que necesitas ahorros previos para cubrir el 20% restante más los gastos asociados (aprox. 10% adicional).",
  },
  {
    question: "¿Qué es la amortización anticipada y cuándo conviene?",
    answer:
      "La amortización anticipada consiste en pagar cuotas extraordinarias para reducir el capital pendiente antes del plazo. Puedes amortizar para reducir el plazo (pagas antes) o para reducir la cuota mensual. Conviene especialmente cuando tienes un tipo de interés alto (> 3,5%) y dispongas de ahorros que no necesitas a corto plazo. La comisión máxima por amortización en hipotecas variables (desde 2019) es del 0,25% los 3 primeros años y 0% después. En fijas puede llegar al 2% los 10 primeros años.",
  },
  {
    question: "¿Hipoteca fija o variable en 2025?",
    answer:
      "En 2025, con el euríbor en torno al 2,5-3%, las hipotecas fijas a tipos similares ofrecen la ventaja de la certeza: sabes exactamente cuánto pagarás siempre. Las hipotecas variables pueden ser atractivas si esperas que el euríbor baje más. La hipoteca mixta (fija los primeros años, variable después) es una opción intermedia. La elección depende de tu perfil de riesgo, plazo y tolerancia a la incertidumbre. Si valoras la tranquilidad, elige fija. Si puedes asumir variaciones, la variable puede salir más barata si el euríbor baja.",
  },
  {
    question: "¿Qué gastos tiene una hipoteca en España?",
    answer:
      "Desde la Ley Hipotecaria de 2019, el banco asume la mayoría de los gastos: notaría, registro, gestoría, AJD (Impuesto de Actos Jurídicos Documentados) y la tasación del banco. El comprador solo paga: su propia tasación independiente (300-600€), la comisión de apertura si existe (0-1% del capital), y el seguro de hogar obligatorio (200-500€/año). En total, el comprador debe tener disponibles aproximadamente un 10% del precio del inmueble para gastos: notaría de compra, ITP o IVA (si es nueva), registro y gestoría.",
  },
  {
    question: "¿Qué plazo de hipoteca es recomendable en España?",
    answer:
      "El plazo más habitual en España es de 25-30 años. Los plazos más largos reducen la cuota mensual pero incrementan significativamente el total de intereses pagados. Por ejemplo, en una hipoteca de 200.000€ al 3,5%, pasar de 25 a 30 años reduce la cuota ~85€/mes pero añade ~30.000€ en intereses totales. Se recomienda elegir el plazo más corto que la cuota mensual te permita sin superar el 35% de tus ingresos. Las hipotecas superiores a 30 años están disponibles en algunos bancos hasta los 40 años, aunque son menos habituales.",
  },
];

const RELATED = CALCULATORS.filter((c) => ["iva", "interes-compuesto"].includes(c.id));

const schema = {
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  name: "Calculadora de Hipoteca España",
  applicationCategory: "FinanceApplication",
  operatingSystem: "Web",
  browserRequirements: "Requires JavaScript",
  inLanguage: "es",
  offers: { "@type": "Offer", price: "0", priceCurrency: "EUR", availability: "https://schema.org/InStock" },
  description:
    "Simula la cuota mensual, intereses totales y tabla de amortización de tu hipoteca en España. Sistema francés de amortización.",
  url: `${SITE_CONFIG.url}/calculadoras/hipoteca`,
  author: { "@type": "Organization", name: SITE_CONFIG.name, url: SITE_CONFIG.url },
};

export default function HipotecaPage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Breadcrumb items={[
          { name: "Calculadoras", href: "/calculadoras" },
          { name: "Finanzas", href: "/calculadoras#finanzas" },
          { name: "Calculadora de Hipoteca", href: "/calculadoras/hipoteca" },
        ]} />
        <AdPlaceholder label="Publicidad — 728×90" height={90} />

        <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">

            <div className="mb-6">
              <div className="flex items-center gap-3 mb-3">
                <span className="text-4xl" aria-hidden="true">🏠</span>
                <div>
                  <h1 className="text-3xl sm:text-4xl font-bold text-neutral-900">Calculadora de Hipoteca</h1>
                  <p className="text-neutral-500 mt-0.5">España · Tipos actualizados 2025</p>
                </div>
              </div>
              <p className="text-neutral-600 leading-relaxed">
                Calcula la <strong>cuota mensual</strong> de tu hipoteca, el total de intereses y la{" "}
                <strong>tabla de amortización</strong> completa. Simulador con el sistema francés de
                amortización, el estándar en España. Incluye comparativa de escenarios por capital,
                plazo y tipo de interés.
              </p>
            </div>

            <HipotecaCalculator />

            {/* Fórmula */}
            <section className="mt-8 card p-6" aria-labelledby="formula-hip">
              <h2 id="formula-hip" className="text-xl font-bold text-neutral-900 mb-4">
                Fórmula del sistema francés de amortización
              </h2>
              <div className="bg-neutral-50 border border-neutral-200 rounded-xl p-4 font-mono text-sm overflow-x-auto mb-4">
                <p className="font-bold text-neutral-900 mb-1">Cuota = C × [r × (1+r)^n] / [(1+r)^n − 1]</p>
                <ul className="text-xs text-neutral-500 mt-2 space-y-1">
                  <li>C = Capital prestado (€)</li>
                  <li>r = Tipo de interés mensual (TIN anual ÷ 12 ÷ 100)</li>
                  <li>n = Número total de cuotas (años × 12)</li>
                </ul>
              </div>
              <div className="bg-brand-50 border border-brand-100 rounded-xl p-4 text-sm">
                <p className="font-semibold text-brand-800 mb-2">🧮 Ejemplo resuelto:</p>
                <ul className="space-y-1 text-brand-700">
                  <li>Capital: <strong>200.000€</strong> · TIN: <strong>3,5%</strong> · Plazo: <strong>30 años</strong></li>
                  <li>r = 3,5 ÷ 12 ÷ 100 = 0,002917</li>
                  <li>n = 30 × 12 = 360 cuotas</li>
                  <li className="font-bold pt-1 border-t border-brand-200">
                    Cuota mensual = <span className="text-brand-900 text-base">898,09€</span>
                  </li>
                  <li>Total pagado: 898,09 × 360 = 323.312€</li>
                  <li>Total intereses: 323.312 − 200.000 = <span className="text-accent-700 font-bold">123.312€</span></li>
                </ul>
              </div>
            </section>

            {/* Comparativa de escenarios */}
            <section className="mt-6 card p-6 overflow-x-auto" aria-labelledby="escenarios-hip">
              <h2 id="escenarios-hip" className="text-xl font-bold text-neutral-900 mb-1">
                Comparativa de cuotas según capital y plazo (TIN 3,5%)
              </h2>
              <p className="text-sm text-neutral-500 mb-4">A tipo fijo del 3,5% anual. Haz clic en la calculadora para simular tu caso exacto.</p>
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-neutral-50">
                    <th className="text-left p-3 font-semibold text-neutral-700">Capital</th>
                    <th className="text-right p-3 font-semibold text-neutral-700">15 años</th>
                    <th className="text-right p-3 font-semibold text-neutral-700">20 años</th>
                    <th className="text-right p-3 font-semibold text-neutral-700">25 años</th>
                    <th className="text-right p-3 font-semibold text-neutral-700">30 años</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {[
                    { cap: "100.000€", y15: "714€", y20: "580€", y25: "501€", y30: "449€" },
                    { cap: "150.000€", y15: "1.072€", y20: "870€", y25: "751€", y30: "674€" },
                    { cap: "200.000€", y15: "1.429€", y20: "1.160€", y25: "1.001€", y30: "898€" },
                    { cap: "250.000€", y15: "1.786€", y20: "1.449€", y25: "1.252€", y30: "1.123€" },
                    { cap: "300.000€", y15: "2.143€", y20: "1.739€", y25: "1.502€", y30: "1.347€" },
                  ].map((row) => (
                    <tr key={row.cap} className="hover:bg-neutral-50">
                      <td className="p-3 font-semibold text-neutral-800">{row.cap}</td>
                      <td className="p-3 text-right tabular-nums text-neutral-700">{row.y15}</td>
                      <td className="p-3 text-right tabular-nums text-neutral-700">{row.y20}</td>
                      <td className="p-3 text-right tabular-nums text-brand-700 font-semibold">{row.y25}</td>
                      <td className="p-3 text-right tabular-nums text-neutral-700">{row.y30}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <p className="text-xs text-neutral-400 mt-2">* Cuota mensual aproximada en sistema de amortización francés (cuota constante).</p>
            </section>

            {/* Fija vs Variable */}
            <section className="mt-6 card p-6" aria-labelledby="fija-variable">
              <h2 id="fija-variable" className="text-xl font-bold text-neutral-900 mb-4">
                Hipoteca fija vs variable vs mixta: ¿cuál elegir en 2025?
              </h2>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-neutral-50">
                      <th className="text-left p-3 font-semibold text-neutral-700">Tipo</th>
                      <th className="text-left p-3 font-semibold text-neutral-700">Tipo interés</th>
                      <th className="text-left p-3 font-semibold text-neutral-700">Ventaja</th>
                      <th className="text-left p-3 font-semibold text-neutral-700">Inconveniente</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100 text-xs">
                    {[
                      {
                        tipo: "Fija",
                        interes: "TIN fijo toda la vida (ej: 3,0-3,8%)",
                        ventaja: "Cuota constante, sin sorpresas. Ideal si quieres certeza total.",
                        incon: "Suele ser más cara al inicio. Comisión amortización anticipada (hasta 2% primeros 10 años).",
                      },
                      {
                        tipo: "Variable",
                        interes: "Euríbor + diferencial (ej: euríbor + 0,5-1%)",
                        ventaja: "Puede ser más barata si el euríbor baja. Mejor comisión amortización anticipada.",
                        incon: "Cuota fluctúa con el euríbor. Si sube, la cuota puede aumentar significativamente.",
                      },
                      {
                        tipo: "Mixta",
                        interes: "Fija los primeros años (5-15 años), luego variable",
                        ventaja: "Cuota estable al inicio (período más crítico). Tipo variable cuando ya has amortizado más.",
                        incon: "Menos oferta. Puede tener condicionantes (seguros vinculados) para mantener el tipo fijo inicial.",
                      },
                    ].map((row) => (
                      <tr key={row.tipo} className="hover:bg-neutral-50 align-top">
                        <td className="p-3 font-bold text-neutral-800">{row.tipo}</td>
                        <td className="p-3 text-neutral-600">{row.interes}</td>
                        <td className="p-3 text-green-700">{row.ventaja}</td>
                        <td className="p-3 text-red-700">{row.incon}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            {/* Gastos hipoteca */}
            <section className="mt-6 card p-6" aria-labelledby="gastos-hip">
              <h2 id="gastos-hip" className="text-xl font-bold text-neutral-900 mb-4">
                Gastos al contratar una hipoteca en España (2025)
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                <div>
                  <h3 className="font-semibold text-neutral-800 mb-2 text-xs uppercase tracking-wide">Paga el BANCO (desde Ley 2019)</h3>
                  {[
                    { item: "Notaría (escritura hipoteca)", importe: "Banco" },
                    { item: "Registro de la Propiedad", importe: "Banco" },
                    { item: "Gestoría", importe: "Banco" },
                    { item: "AJD (Impuesto Actos Jur. Doc.)", importe: "Banco" },
                    { item: "Tasación del banco", importe: "Banco" },
                  ].map((row) => (
                    <div key={row.item} className="flex justify-between py-1.5 border-b border-neutral-100">
                      <span className="text-neutral-600">{row.item}</span>
                      <span className="font-semibold text-green-700 text-xs">{row.importe}</span>
                    </div>
                  ))}
                </div>
                <div>
                  <h3 className="font-semibold text-neutral-800 mb-2 text-xs uppercase tracking-wide">Paga el COMPRADOR</h3>
                  {[
                    { item: "Tasación independiente", importe: "300–600€" },
                    { item: "Comisión de apertura", importe: "0–1% capital" },
                    { item: "ITP / IVA (compra del inmueble)", importe: "6–10% del precio" },
                    { item: "Notaría (escritura compra)", importe: "600–1.200€" },
                    { item: "Seguro de hogar (anual)", importe: "200–500€/año" },
                  ].map((row) => (
                    <div key={row.item} className="flex justify-between py-1.5 border-b border-neutral-100">
                      <span className="text-neutral-600">{row.item}</span>
                      <span className="font-semibold text-neutral-800 text-xs">{row.importe}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="mt-4 bg-amber-50 border border-amber-200 rounded-xl p-3 text-sm">
                <p className="font-semibold text-amber-800 mb-1">💡 Regla práctica</p>
                <p className="text-amber-700 text-xs leading-relaxed">
                  Necesitas aproximadamente un <strong>30-35% del precio del inmueble en ahorros</strong>:
                  20% que no financia el banco + 10-15% para gastos de compra e hipoteca. En una vivienda de 250.000€, necesitas entre 75.000€ y 87.500€ en ahorros previos.
                </p>
              </div>
            </section>

            {/* Amortización anticipada */}
            <section className="mt-6 card p-6" aria-labelledby="amort-anticipada">
              <h2 id="amort-anticipada" className="text-xl font-bold text-neutral-900 mb-4">
                Amortización anticipada: cómo ahorrar miles de euros
              </h2>
              <p className="text-sm text-neutral-600 leading-relaxed mb-4">
                Pagar cuotas extra reduce el capital pendiente y, con él, los intereses futuros. Es especialmente
                rentable en los primeros años del préstamo, cuando la proporción de intereses por cuota es mayor.
              </p>
              <div className="bg-neutral-50 border border-neutral-200 rounded-xl p-4 text-sm mb-4">
                <p className="font-semibold text-neutral-800 mb-2">Ejemplo: hipoteca de 200.000€ al 3,5% a 30 años</p>
                <div className="space-y-2 text-xs text-neutral-600">
                  <div className="flex justify-between">
                    <span>Sin amortización anticipada</span>
                    <span className="font-semibold text-red-600">Total intereses: 123.312€</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Aportando 5.000€ extra en el año 5</span>
                    <span className="font-semibold text-amber-600">Ahorro: ~8.000€ intereses · −13 meses</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Aportando 5.000€ extra cada año</span>
                    <span className="font-semibold text-green-600">Ahorro: ~45.000€ intereses · −9 años</span>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="bg-green-50 rounded-xl p-3">
                  <p className="font-semibold text-green-800 mb-1">¿Cuándo amortizar para reducir PLAZO?</p>
                  <p className="text-green-700">Si tu objetivo es pagar antes y tu cuota mensual ya es cómoda. Maximiza el ahorro en intereses totales.</p>
                </div>
                <div className="bg-blue-50 rounded-xl p-3">
                  <p className="font-semibold text-blue-800 mb-1">¿Cuándo amortizar para reducir CUOTA?</p>
                  <p className="text-blue-700">Si necesitas liberar liquidez mensual. Útil si han subido los tipos y quieres aliviar la carga mensual.</p>
                </div>
              </div>
            </section>

            <div className="mt-6">
              <FAQ items={FAQ_ITEMS} title="Preguntas frecuentes sobre hipotecas en España" />
            </div>

            {/* Internal link */}
            <div className="mt-6 bg-neutral-50 border border-neutral-200 rounded-2xl p-5">
              <p className="text-sm text-neutral-600">
                ¿Quieres comparar cuánto pagarías si en vez de una hipoteca invirtieras ese dinero?
                Usa nuestra{" "}
                <a href="/calculadoras/interes-compuesto" className="text-brand-600 hover:underline font-semibold">
                  calculadora de interés compuesto
                </a>{" "}
                para ver el crecimiento potencial de tu capital a largo plazo.
              </p>
            </div>
          </div>

          <aside className="space-y-5">
            <AdPlaceholder label="Publicidad — 300×250" height={250} />
            <AffiliateBlock
              icon="🏦"
              title="Compara hipotecas online"
              description="Encuentra la hipoteca con mejor tipo de interés para tu perfil. Comparador gratuito sin compromiso."
              cta="Comparar hipotecas"
              href="#"
            />
            <div className="card p-5">
              <h3 className="font-semibold text-neutral-900 mb-3">Euríbor 2025</h3>
              <div className="text-center py-3 bg-neutral-50 rounded-xl mb-3">
                <p className="text-3xl font-bold text-brand-700">~2,5%</p>
                <p className="text-xs text-neutral-500 mt-1">Euríbor 12 meses (referencial)</p>
              </div>
              <div className="space-y-1 text-xs text-neutral-600">
                <div className="flex justify-between">
                  <span>Máximo histórico</span>
                  <span className="font-semibold text-red-600">5,26% (oct. 2023)</span>
                </div>
                <div className="flex justify-between">
                  <span>Mínimo histórico</span>
                  <span className="font-semibold text-green-600">-0,50% (2021-2022)</span>
                </div>
                <div className="flex justify-between">
                  <span>Media 20 años</span>
                  <span className="font-semibold">~1,8%</span>
                </div>
              </div>
              <p className="text-xs text-neutral-400 mt-2">Fuente: BCE / Banco de España. Actualizar según mercado.</p>
            </div>
            <div className="card p-5">
              <h3 className="font-semibold text-neutral-900 mb-3">Tipos hipotecarios actuales</h3>
              <div className="space-y-2 text-xs">
                {[
                  { tipo: "Fija (25-30 años)", rate: "2,9-3,8% TIN" },
                  { tipo: "Variable (euríbor+)", rate: "E+0,5-1,0%" },
                  { tipo: "Mixta (10 años fija)", rate: "2,5-3,2% TIN" },
                ].map((row) => (
                  <div key={row.tipo} className="flex justify-between items-center">
                    <span className="text-neutral-600">{row.tipo}</span>
                    <span className="font-semibold text-brand-700">{row.rate}</span>
                  </div>
                ))}
              </div>
              <p className="text-xs text-neutral-400 mt-2">Tipos orientativos 2025. Consulta con tu banco.</p>
            </div>
            <div className="card p-5">
              <h3 className="font-semibold text-neutral-900 mb-3">Calculadoras relacionadas</h3>
              <div className="space-y-2">
                {RELATED.map((calc) => (
                  <CalculatorCard key={calc.id} icon={calc.icon} name={calc.name} description={calc.description} href={calc.href} />
                ))}
              </div>
            </div>
            <AdPlaceholder label="Publicidad — 300×600" height={300} />
          </aside>
        </div>
      </div>
    </>
  );
}
