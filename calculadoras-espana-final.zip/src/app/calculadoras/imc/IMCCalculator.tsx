"use client";

import { useState, useMemo } from "react";
import { formatNumber } from "@/lib/utils";

type Unit = "metric" | "imperial";

interface BMICategory {
  label: string;
  range: string;
  color: string;
  bg: string;
  advice: string;
}

const CATEGORIES: BMICategory[] = [
  { label: "Bajo peso", range: "< 18,5", color: "text-blue-700", bg: "bg-blue-100", advice: "Considera aumentar tu ingesta calórica con alimentos nutritivos. Consulta a un médico o dietista." },
  { label: "Normopeso", range: "18,5 – 24,9", color: "text-green-700", bg: "bg-green-100", advice: "¡Enhorabuena! Tu peso es saludable. Mantén una dieta equilibrada y ejercicio regular." },
  { label: "Sobrepeso", range: "25 – 29,9", color: "text-yellow-700", bg: "bg-yellow-100", advice: "Considera reducir ligeramente las calorías y aumentar la actividad física. Un pequeño cambio marca la diferencia." },
  { label: "Obesidad I", range: "30 – 34,9", color: "text-orange-700", bg: "bg-orange-100", advice: "Se recomienda consultar con un médico y adoptar hábitos más saludables de alimentación y ejercicio." },
  { label: "Obesidad II", range: "35 – 39,9", color: "text-red-700", bg: "bg-red-100", advice: "Consulta con un especialista en medicina interna o endocrinología. Puede haber riesgos para la salud." },
  { label: "Obesidad III (mórbida)", range: "≥ 40", color: "text-red-900", bg: "bg-red-200", advice: "Es importante buscar atención médica especializada. Existen programas de apoyo y tratamientos efectivos." },
];

function getBMICategory(bmi: number): BMICategory {
  if (bmi < 18.5) return CATEGORIES[0];
  if (bmi < 25) return CATEGORIES[1];
  if (bmi < 30) return CATEGORIES[2];
  if (bmi < 35) return CATEGORIES[3];
  if (bmi < 40) return CATEGORIES[4];
  return CATEGORIES[5];
}

export function IMCCalculator() {
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [unit, setUnit] = useState<Unit>("metric");
  const [gender, setGender] = useState<"male" | "female" | "">("");
  const [age, setAge] = useState("");

  const results = useMemo(() => {
    let w = parseFloat(weight.replace(",", "."));
    let h = parseFloat(height.replace(",", "."));

    if (isNaN(w) || isNaN(h) || w <= 0 || h <= 0) return null;

    if (unit === "imperial") {
      w = w * 0.453592; // lbs to kg
      h = h * 2.54; // inches to cm
    }

    const heightM = h / 100;
    const bmi = w / (heightM * heightM);

    // Ideal weight range (Quetelet)
    const idealMin = 18.5 * heightM * heightM;
    const idealMax = 24.9 * heightM * heightM;

    // Percentage of fat (Deurenberg formula)
    let bodyFat: number | null = null;
    const ageNum = parseInt(age);
    if (gender && ageNum > 0) {
      bodyFat = 1.2 * bmi + 0.23 * ageNum - 10.8 * (gender === "male" ? 1 : 0) - 5.4;
    }

    return { bmi, category: getBMICategory(bmi), idealMin, idealMax, bodyFat, weightKg: w };
  }, [weight, height, unit, gender, age]);

  const categoryIndex = results
    ? CATEGORIES.findIndex((c) => c.label === results.category.label)
    : -1;

  return (
    <div className="card p-6 space-y-5">
      {/* Unit toggle */}
      <div className="flex bg-neutral-100 rounded-xl p-1">
        <button onClick={() => setUnit("metric")}
          className={`flex-1 py-2 px-3 rounded-lg text-sm font-semibold transition-all ${unit === "metric" ? "bg-white text-brand-700 shadow-sm" : "text-neutral-500 hover:text-neutral-700"}`}>
          Métrico (kg / cm)
        </button>
        <button onClick={() => setUnit("imperial")}
          className={`flex-1 py-2 px-3 rounded-lg text-sm font-semibold transition-all ${unit === "imperial" ? "bg-white text-brand-700 shadow-sm" : "text-neutral-500 hover:text-neutral-700"}`}>
          Imperial (lb / in)
        </button>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="input-label">Peso ({unit === "metric" ? "kg" : "lb"})</label>
          <input type="number" inputMode="decimal" placeholder={unit === "metric" ? "70" : "154"}
            value={weight} onChange={(e) => setWeight(e.target.value)}
            className="input-field" min="1" step="0.5" />
        </div>
        <div>
          <label className="input-label">Altura ({unit === "metric" ? "cm" : "in"})</label>
          <input type="number" inputMode="decimal" placeholder={unit === "metric" ? "170" : "67"}
            value={height} onChange={(e) => setHeight(e.target.value)}
            className="input-field" min="50" step="1" />
        </div>
        <div>
          <label className="input-label">Sexo (opcional)</label>
          <select value={gender} onChange={(e) => setGender(e.target.value as "male" | "female" | "")} className="input-field">
            <option value="">No especificar</option>
            <option value="male">Masculino</option>
            <option value="female">Femenino</option>
          </select>
        </div>
        <div>
          <label className="input-label">Edad (opcional)</label>
          <input type="number" inputMode="numeric" placeholder="30"
            value={age} onChange={(e) => setAge(e.target.value)}
            className="input-field" min="15" max="100" />
        </div>
      </div>

      {results ? (
        <div className="space-y-4">
          {/* Main IMC result */}
          <div className={`${results.category.bg} rounded-2xl p-6 text-center`}>
            <p className={`text-6xl font-bold tabular-nums ${results.category.color}`}>
              {formatNumber(results.bmi, 1)}
            </p>
            <p className={`text-lg font-bold mt-1 ${results.category.color}`}>
              {results.category.label}
            </p>
            <p className="text-sm text-neutral-500 mt-0.5">IMC · {results.category.range} kg/m²</p>
          </div>

          {/* Scale */}
          <div className="bg-neutral-50 rounded-xl p-4">
            <p className="text-xs font-semibold text-neutral-500 mb-2 uppercase tracking-wide">Escala IMC</p>
            <div className="flex h-3 rounded-full overflow-hidden mb-2">
              {["bg-blue-400", "bg-green-400", "bg-yellow-400", "bg-orange-400", "bg-red-400", "bg-red-700"].map((color, i) => (
                <div key={i} className={`${color} flex-1 ${i === categoryIndex ? "ring-2 ring-neutral-900 ring-inset" : ""}`} />
              ))}
            </div>
            <div className="flex justify-between text-xs text-neutral-400">
              <span>16</span><span>18.5</span><span>25</span><span>30</span><span>35</span><span>40</span>
            </div>
          </div>

          {/* Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
            <div className="bg-white border border-neutral-200 rounded-xl p-3">
              <p className="text-neutral-500 text-xs">Peso ideal saludable</p>
              <p className="font-bold text-neutral-900">
                {formatNumber(results.idealMin, 1)} – {formatNumber(results.idealMax, 1)} kg
              </p>
            </div>
            {results.bodyFat !== null && (
              <div className="bg-white border border-neutral-200 rounded-xl p-3">
                <p className="text-neutral-500 text-xs">% Grasa corporal (est.)</p>
                <p className="font-bold text-neutral-900">{formatNumber(results.bodyFat, 1)}%</p>
              </div>
            )}
          </div>

          {/* Advice */}
          <div className={`${results.category.bg} rounded-xl p-4 text-sm ${results.category.color}`}>
            <p className="font-semibold mb-1">💡 Recomendación:</p>
            <p>{results.category.advice}</p>
          </div>

          <p className="text-xs text-neutral-400 text-center">
            El IMC es un indicador general. No reemplaza la valoración médica profesional.
          </p>
        </div>
      ) : (
        <div className="bg-neutral-50 rounded-2xl p-8 text-center">
          <p className="text-4xl mb-3">⚖️</p>
          <p className="text-neutral-500 text-sm">Introduce tu peso y altura para calcular tu IMC</p>
        </div>
      )}
    </div>
  );
}
