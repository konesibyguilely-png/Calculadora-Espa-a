import type { Metadata } from "next";
import { IMCCalculator } from "./IMCCalculator";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { FAQ } from "@/components/ui/FAQ";
import { AdPlaceholder } from "@/components/ui/AdSense";
import { CalculatorCard } from "@/components/ui/CalculatorCard";
import { CALCULATORS, SITE_CONFIG } from "@/lib/config";

export const metadata: Metadata = {
  title: "Calculadora IMC — Índice de Masa Corporal Online Gratis",
  description:
    "Calcula tu Índice de Masa Corporal (IMC) gratis. Descubre si tienes un peso saludable según la OMS. Incluye tabla de clasificación y recomendaciones.",
  twitter: {
    card: "summary_large_image",
    title: "Calculadora IMC — Índice de Masa Corporal",
    description: "Calcula tu IMC y descubre si tu peso es saludable según criterios de la OMS.",
    images: ["/og-image.png"],
  },
  alternates: { canonical: `${SITE_CONFIG.url}/calculadoras/imc` },
  openGraph: {
    title: "Calculadora IMC — Peso Saludable según la OMS",
    description: "Calcula tu Índice de Masa Corporal y descubre si tienes un peso saludable.",
    url: `${SITE_CONFIG.url}/calculadoras/imc`,
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "Calculadora IMC — Peso Saludable según la OMS",
      },
    ],
  },

};

const FAQ_ITEMS = [
  {
    question: "¿Qué es el IMC (Índice de Masa Corporal)?",
    answer: "El IMC es una medida que relaciona el peso y la altura de una persona para estimar si su peso es saludable. Se calcula dividiendo el peso en kilogramos entre el cuadrado de la altura en metros (kg/m²). Es una herramienta de cribado, no un diagnóstico médico definitivo.",
  },
  {
    question: "¿Cuál es el IMC normal según la OMS?",
    answer: "Según la Organización Mundial de la Salud (OMS): Bajo peso: IMC < 18,5; Normopeso (peso saludable): 18,5 – 24,9; Sobrepeso: 25 – 29,9; Obesidad tipo I: 30 – 34,9; Obesidad tipo II: 35 – 39,9; Obesidad tipo III (mórbida): ≥ 40.",
  },
  {
    question: "¿El IMC es fiable para todas las personas?",
    answer: "El IMC tiene limitaciones. No distingue entre masa muscular y grasa corporal, por lo que puede sobrestimar la obesidad en personas muy musculadas (atletas) y subestimarla en personas con poca masa muscular (ancianos). Tampoco considera la distribución de la grasa corporal. El perímetro abdominal es un complemento importante.",
  },
  {
    question: "¿Cómo puedo bajar mi IMC de forma saludable?",
    answer: "Para reducir el IMC de forma saludable se recomienda: 1) Reducir el déficit calórico moderadamente (300-500 kcal/día); 2) Hacer ejercicio aeróbico y de fuerza regularmente; 3) Priorizar alimentos integrales, proteínas magras, frutas y verduras; 4) Dormir 7-8 horas; 5) Controlar el estrés. Evita dietas muy restrictivas.",
  },
  {
    question: "¿Es diferente el IMC para hombres y mujeres?",
    answer: "Los rangos del IMC son los mismos para hombres y mujeres adultos. Sin embargo, a igual IMC, las mujeres suelen tener mayor porcentaje de grasa corporal que los hombres, lo cual es fisiológicamente normal. En la infancia y adolescencia sí se usan tablas específicas por edad y sexo.",
  },
];

const RELATED = CALCULATORS.filter((c) => ["edad", "diferencia-fechas"].includes(c.id));

const schema = {
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  name: "Calculadora IMC España",
  applicationCategory: "HealthApplication",
  operatingSystem: "Web",
  browserRequirements: "Requires JavaScript",
  inLanguage: "es",
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "EUR",
    availability: "https://schema.org/InStock",
  },
  description: metadata.description,
  url: `${SITE_CONFIG.url}/calculadoras/imc`,
  author: {
    "@type": "Organization",
    name: SITE_CONFIG.name,
    url: SITE_CONFIG.url,
  },
};

export default function IMCPage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Breadcrumb items={[
          { name: "Calculadoras", href: "/calculadoras" },
          { name: "Salud", href: "/calculadoras#salud" },
          { name: "Calculadora IMC", href: "/calculadoras/imc" },
        ]} />
        <AdPlaceholder label="Publicidad — 728×90" height={90} />

        <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="mb-6">
              <div className="flex items-center gap-3 mb-3">
                <span className="text-4xl">⚖️</span>
                <div>
                  <h1 className="text-3xl sm:text-4xl font-bold text-neutral-900">Calculadora IMC</h1>
                  <p className="text-neutral-500 mt-0.5">Índice de Masa Corporal · Criterios OMS</p>
                </div>
              </div>
              <p className="text-neutral-600 leading-relaxed">
                Calcula tu Índice de Masa Corporal (IMC) y descubre si tu peso es saludable según los criterios
                de la Organización Mundial de la Salud. Incluye estimación de grasa corporal y peso ideal.
              </p>
            </div>
            <IMCCalculator />

            <section className="mt-8 card p-6">
              <h2 className="text-xl font-bold text-neutral-900 mb-4">Fórmula del IMC</h2>
              <div className="bg-neutral-50 border border-neutral-200 rounded-xl p-4 font-mono text-sm mb-4">
                <p className="font-bold text-neutral-900">IMC = Peso (kg) / Altura² (m²)</p>
                <p className="text-neutral-500 mt-2">Ejemplo: 70 kg / (1,70)² = 70 / 2,89 = <strong>24,2 kg/m²</strong></p>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-neutral-50">
                      <th className="text-left p-3 font-semibold text-neutral-700">Clasificación</th>
                      <th className="text-center p-3 font-semibold text-neutral-700">IMC (kg/m²)</th>
                      <th className="text-left p-3 font-semibold text-neutral-700">Riesgo para la salud</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {[
                      { label: "Bajo peso", range: "< 18,5", risk: "Incrementado", color: "bg-blue-100 text-blue-800" },
                      { label: "Normopeso", range: "18,5 – 24,9", risk: "Promedio", color: "bg-green-100 text-green-800" },
                      { label: "Sobrepeso", range: "25 – 29,9", risk: "Incrementado", color: "bg-yellow-100 text-yellow-800" },
                      { label: "Obesidad tipo I", range: "30 – 34,9", risk: "Alto", color: "bg-orange-100 text-orange-800" },
                      { label: "Obesidad tipo II", range: "35 – 39,9", risk: "Muy alto", color: "bg-red-100 text-red-800" },
                      { label: "Obesidad tipo III", range: "≥ 40", risk: "Extremadamente alto", color: "bg-red-200 text-red-900" },
                    ].map((row) => (
                      <tr key={row.label} className="hover:bg-neutral-50">
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${row.color}`}>{row.label}</span>
                        </td>
                        <td className="p-3 text-center font-mono text-neutral-700">{row.range}</td>
                        <td className="p-3 text-neutral-600">{row.risk}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            {/* Tabla peso saludable por altura */}
            <section className="mt-6 card p-6 overflow-x-auto" aria-labelledby="peso-altura">
              <h2 id="peso-altura" className="text-xl font-bold text-neutral-900 mb-4">
                Peso saludable según la altura (IMC 18,5–24,9)
              </h2>
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-neutral-50">
                    <th className="text-left p-3 font-semibold text-neutral-700">Altura</th>
                    <th className="text-right p-3 font-semibold text-neutral-700">Peso mínimo</th>
                    <th className="text-right p-3 font-semibold text-neutral-700">Peso máximo</th>
                    <th className="text-right p-3 font-semibold text-neutral-700">IMC central</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {[
                    { h: "1,55 m", min: "44,5 kg", max: "59,9 kg", mid: "21,7" },
                    { h: "1,60 m", min: "47,4 kg", max: "63,7 kg", mid: "21,7" },
                    { h: "1,65 m", min: "50,3 kg", max: "67,8 kg", mid: "21,7" },
                    { h: "1,70 m", min: "53,5 kg", max: "71,9 kg", mid: "21,7" },
                    { h: "1,75 m", min: "56,7 kg", max: "76,3 kg", mid: "21,7" },
                    { h: "1,80 m", min: "59,9 kg", max: "80,8 kg", mid: "21,7" },
                    { h: "1,85 m", min: "63,3 kg", max: "85,2 kg", mid: "21,7" },
                    { h: "1,90 m", min: "66,8 kg", max: "89,9 kg", mid: "21,7" },
                  ].map((row) => (
                    <tr key={row.h} className="hover:bg-neutral-50">
                      <td className="p-3 font-semibold text-neutral-800">{row.h}</td>
                      <td className="p-3 text-right text-blue-700 font-medium">{row.min}</td>
                      <td className="p-3 text-right text-green-700 font-medium">{row.max}</td>
                      <td className="p-3 text-right text-neutral-500">{row.mid}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <p className="text-xs text-neutral-400 mt-2">Rangos calculados para IMC entre 18,5 y 24,9 (normopeso según la OMS).</p>
            </section>


            {/* Errores frecuentes */}
            <section className="mt-6 card p-6" aria-labelledby="errores-imc">
              <h2 id="errores-imc" className="text-xl font-bold text-neutral-900 mb-4">
                Errores frecuentes al interpretar el IMC
              </h2>
              <div className="space-y-3">
                {[
                  {
                    error: "Usar el IMC como único indicador de salud",
                    fix: "El IMC no mide directamente la grasa corporal ni su distribución. Complementa siempre con el perímetro abdominal (hombres: &lt;102 cm; mujeres: &lt;88 cm), el porcentaje de grasa corporal y otras métricas clínicas."
                  },
                  {
                    error: "Aplicar los mismos rangos a deportistas",
                    fix: "Un culturista con 90 kg y 1,75 m tiene un IMC de 29,4 (sobrepeso según tablas) pero puede tener un porcentaje de grasa corporal del 8%. El IMC falla con personas muy musculadas porque no distingue músculo de grasa."
                  },
                  {
                    error: "Ignorar la edad en adultos mayores",
                    fix: "En personas mayores de 65 años, un IMC ligeramente superior al rango normal (25-27) puede asociarse a menor mortalidad. Los rangos óptimos en mayores son distintos a los de adultos jóvenes. Consulta siempre con tu médico."
                  },
                ].map((item) => (
                  <div key={item.error} className="bg-red-50 border border-red-100 rounded-xl p-4">
                    <p className="font-semibold text-red-800 text-sm mb-1">❌ {item.error}</p>
                    <p className="text-red-700 text-sm leading-relaxed" dangerouslySetInnerHTML={{__html: `✅ ${item.fix}`}} />
                  </div>
                ))}
              </div>
            </section>

            {/* Guía práctica */}
            <section className="mt-6 card p-6" aria-labelledby="guia-imc">
              <h2 id="guia-imc" className="text-xl font-bold text-neutral-900 mb-4">
                Cómo mejorar tu IMC de forma saludable
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                {[
                  {
                    icon: "🥗",
                    title: "Alimentación",
                    tips: [
                      "Déficit calórico moderado (300-500 kcal/día para perder)",
                      "Priorizar proteínas magras, verduras y cereales integrales",
                      "Reducir ultraprocesados, azúcares añadidos y alcohol",
                      "No saltar comidas: genera ansiedad y peores elecciones",
                    ]
                  },
                  {
                    icon: "🏃",
                    title: "Ejercicio físico",
                    tips: [
                      "Combinar cardio (150-300 min/semana) y fuerza (2-3 sesiones/semana)",
                      "El músculo aumenta el metabolismo basal en reposo",
                      "Empezar gradualmente para evitar lesiones y abandono",
                      "Cualquier actividad cuenta: caminar, subir escaleras, bailar",
                    ]
                  },
                  {
                    icon: "😴",
                    title: "Hábitos de vida",
                    tips: [
                      "Dormir 7-8 horas regula las hormonas del apetito (leptina/grelina)",
                      "El estrés crónico aumenta el cortisol, que favorece el almacenamiento de grasa",
                      "La hidratación adecuada (1,5-2 L/día) mejora el metabolismo",
                      "Reducir el tiempo sentado: levantarse cada hora",
                    ]
                  },
                  {
                    icon: "⚕️",
                    title: "Seguimiento médico",
                    tips: [
                      "Revisión anual con tu médico de cabecera: analítica completa",
                      "Si IMC &gt; 30, consultar con endocrinólogo o nutricionista titulado",
                      "No hacer dietas de &lt;800 kcal sin supervisión médica",
                      "Los cambios sostenibles son mejores que los rápidos",
                    ]
                  },
                ].map((item) => (
                  <div key={item.title} className="bg-neutral-50 rounded-xl p-4">
                    <p className="text-2xl mb-2" aria-hidden="true">{item.icon}</p>
                    <p className="font-semibold text-neutral-800 mb-2 text-sm">{item.title}</p>
                    <ul className="space-y-1">
                      {item.tips.map((tip) => (
                        <li key={tip} className="flex items-start gap-1.5 text-xs text-neutral-600">
                          <span className="mt-0.5 flex-shrink-0 text-brand-500">•</span>
                          <span dangerouslySetInnerHTML={{__html: tip}} />
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
              <p className="text-xs text-neutral-400 mt-4">
                ⚕️ Esta información es educativa. Consulta siempre con un profesional sanitario antes de realizar cambios significativos en tu dieta o rutina de ejercicio.
              </p>
            </section>


            <div className="mt-6">
              <FAQ items={FAQ_ITEMS} title="Preguntas sobre el IMC y el peso saludable" />

            {/* Enlace interno contextual */}
            <div className="mt-6 bg-neutral-50 border border-neutral-200 rounded-2xl p-5">
              <p className="text-sm text-neutral-600">
                Para seguimientos de salud y plazos médicos, usa también nuestra{" "}
                <a href="/calculadoras/edad" className="text-brand-600 hover:underline font-semibold">calculadora de edad exacta</a>
                {" "}y la{" "}
                <a href="/calculadoras/diferencia-fechas" className="text-brand-600 hover:underline font-semibold">calculadora de diferencia entre fechas</a>
                {" "}para calcular días entre consultas o revisiones.
              </p>
            </div>
            </div>
            <p className="text-xs text-neutral-400 mt-4 p-4 bg-neutral-50 rounded-xl">
              ⚕️ Esta calculadora es solo para uso informativo. No reemplaza el consejo médico profesional. Consulta siempre con tu médico antes de iniciar cualquier cambio en tu dieta o rutina de ejercicios.
            </p>
          </div>

          <aside className="space-y-5">
            <AdPlaceholder label="Publicidad — 300×250" height={250} />
            <div className="card p-5">
              <h3 className="font-semibold text-neutral-900 mb-3">Calculadoras relacionadas</h3>
              <div className="space-y-2">
                {RELATED.map((calc) => (
                  <CalculatorCard key={calc.id} icon={calc.icon} name={calc.name} description={calc.description} href={calc.href} />
                ))}
              </div>
            </div>
            <AdPlaceholder label="Publicidad — 300×600" height={300} />
          </aside>
        </div>
      </div>
    </>
  );
}
