import type { Metadata } from "next";
import { DiferenciaFechasCalculator } from "./DiferenciaFechasCalculator";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { FAQ } from "@/components/ui/FAQ";
import { AdPlaceholder } from "@/components/ui/AdSense";
import { CalculatorCard } from "@/components/ui/CalculatorCard";
import { CALCULATORS, SITE_CONFIG } from "@/lib/config";

export const metadata: Metadata = {
  title: "Calculadora de Diferencia entre Fechas — Días, Semanas, Meses",
  description:
    "Calcula los días, semanas, meses y años exactos entre dos fechas. Incluye días laborables y fines de semana. Útil para plazos, contratos, proyectos y aniversarios.",
  alternates: { canonical: `${SITE_CONFIG.url}/calculadoras/diferencia-fechas` },
  openGraph: {
    title: "Calculadora de Diferencia entre Fechas — Días y Semanas",
    description:
      "Calcula exactamente cuántos días, semanas, meses y años hay entre dos fechas. Con días laborables y festivos.",
    url: `${SITE_CONFIG.url}/calculadoras/diferencia-fechas`,
    images: [{ url: "/og-image.png", width: 1200, height: 630, alt: "Calculadora Diferencia entre Fechas — Calculadoras España" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Diferencia entre Fechas — Calculadora Gratuita",
    description: "Días, semanas, meses y años entre dos fechas. Con días laborables incluidos.",
    images: ["/og-image.png"],
  },
};

const FAQ_ITEMS = [
  {
    question: "¿Cómo se calcula la diferencia en días entre dos fechas?",
    answer:
      "La diferencia en días entre dos fechas se obtiene convirtiendo ambas fechas a un número de milisegundos (timestamp Unix) y restando el menor al mayor. El resultado en milisegundos se divide entre 86.400.000 (ms/día) para obtener los días exactos. Esta operación tiene en cuenta automáticamente los años bisiestos y los diferentes números de días de cada mes.",
  },
  {
    question: "¿Qué son los días laborables y cómo se calculan?",
    answer:
      "Los días laborables son los días de lunes a viernes, excluyendo sábados y domingos. Para calcularlos entre dos fechas, se itera por cada día del período contando únicamente los que no sean fin de semana. En España, además existen 14 festivos nacionales anuales (como el 1 de enero, 6 de enero, 1 de mayo, 25 de diciembre…) que varían según comunidad autónoma. Nuestra calculadora excluye solo los fines de semana, ya que los festivos son locales y variables.",
  },
  {
    question: "¿Para qué casos es útil calcular la diferencia entre fechas?",
    answer:
      "Esta calculadora es muy útil para: calcular el tiempo que falta hasta un evento (boda, viaje, examen); determinar plazos legales o administrativos (recursos, prescripciones, contratos); calcular la duración de un proyecto o contrato laboral; saber el tiempo transcurrido desde un acontecimiento histórico; calcular aniversarios y efemérides; y para cualquier situación donde necesites saber exactamente cuánto tiempo media entre dos fechas.",
  },
  {
    question: "¿Cómo se cuentan los meses cuando estos tienen diferente número de días?",
    answer:
      "Para contar meses completos entre dos fechas, se avanza mes a mes desde la fecha inicial hasta que el siguiente mes completo superaría la fecha final. Por ejemplo, del 31 de enero al 28 de febrero es 1 mes completo (porque febrero no tiene día 31). Del 1 de enero al 31 de marzo son 2 meses y 30 días (no exactamente 3 meses, ya que el 1 de abril supera la fecha final). Nuestra calculadora usa el método estándar de diferencia de calendarios.",
  },
  {
    question: "¿Puedo calcular fechas en el pasado o en el futuro?",
    answer:
      "Sí, completamente. Puedes calcular la diferencia entre cualquier par de fechas, tanto si la fecha de inicio es anterior a hoy como si ambas son fechas futuras. El botón de intercambio invierte automáticamente el orden si la fecha de inicio es posterior a la de fin. Así puedes calcular, por ejemplo, cuántos días faltan para un evento futuro o cuánto tiempo ha pasado desde uno histórico.",
  },
  {
    question: "¿Cómo afectan los años bisiestos al cálculo?",
    answer:
      "Los años bisiestos (2024, 2028, 2032…) tienen 366 días en lugar de 365, porque febrero tiene 29 días en lugar de 28. Si el período calculado incluye un 29 de febrero de un año bisiesto, ese día se cuenta normalmente. Por eso la diferencia entre, por ejemplo, el 1 de enero de 2024 y el 1 de enero de 2025 es de 366 días (2024 fue bisiesto), mientras que del 1 de enero de 2025 al 1 de enero de 2026 son 365 días.",
  },
];

const RELATED = CALCULATORS.filter((c) => ["edad", "imc"].includes(c.id));

const schema = {
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  name: "Calculadora de Diferencia entre Fechas",
  applicationCategory: "UtilitiesApplication",
  operatingSystem: "Web",
  browserRequirements: "Requires JavaScript",
  inLanguage: "es",
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "EUR",
    availability: "https://schema.org/InStock",
  },
  description:
    "Calcula los días, semanas, meses y años exactos entre dos fechas. Incluye días laborables y fines de semana.",
  url: `${SITE_CONFIG.url}/calculadoras/diferencia-fechas`,
  author: {
    "@type": "Organization",
    name: SITE_CONFIG.name,
    url: SITE_CONFIG.url,
  },
};

export default function DiferenciaFechasPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
      />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Breadcrumb
          items={[
            { name: "Calculadoras", href: "/calculadoras" },
            { name: "Utilidades", href: "/calculadoras#utilidades" },
            { name: "Diferencia entre Fechas", href: "/calculadoras/diferencia-fechas" },
          ]}
        />
        <AdPlaceholder label="Publicidad — 728×90" height={90} />

        <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="mb-6">
              <div className="flex items-center gap-3 mb-3">
                <span className="text-4xl" aria-hidden="true">📅</span>
                <div>
                  <h1 className="text-3xl sm:text-4xl font-bold text-neutral-900">
                    Diferencia entre Fechas
                  </h1>
                  <p className="text-neutral-500 mt-0.5">
                    Días, semanas, meses y años exactos
                  </p>
                </div>
              </div>
              <p className="text-neutral-600 leading-relaxed">
                Calcula la <strong>diferencia exacta entre dos fechas</strong>: días totales, semanas,
                meses, años, horas, <strong>días laborables</strong> y fines de semana. Útil para
                plazos legales, proyectos, contratos y cualquier cálculo de tiempo.
              </p>
            </div>

            <DiferenciaFechasCalculator />

            {/* How it works */}
            <section className="mt-8 card p-6" aria-labelledby="como-funciona">
              <h2 id="como-funciona" className="text-xl font-bold text-neutral-900 mb-4">
                ¿Cómo funciona el cálculo de diferencia entre fechas?
              </h2>
              <div className="space-y-3 text-sm text-neutral-600 leading-relaxed">
                <div className="bg-neutral-50 border border-neutral-200 rounded-xl p-4 font-mono text-xs">
                  <p className="font-bold text-neutral-900 mb-1">Fórmula básica:</p>
                  <p>Días = (timestamp_fin − timestamp_inicio) ÷ 86.400.000 ms</p>
                  <p className="mt-2 text-neutral-500">Donde 1 día = 24h × 60min × 60s × 1000ms = 86.400.000 ms</p>
                </div>
                <p>
                  Para días <strong>laborables</strong>, la calculadora recorre cada día del período
                  y excluye sábados (día 6) y domingos (día 0) del resultado.
                </p>
                <p>
                  Los <strong>años bisiestos</strong> se manejan automáticamente: el año 2024 tiene
                  366 días (febrero con 29 días), mientras que 2025 tiene 365.
                </p>
              </div>
            </section>

            {/* Ejemplos de uso */}
            <section className="mt-6 card p-6" aria-labelledby="ejemplos">
              <h2 id="ejemplos" className="text-xl font-bold text-neutral-900 mb-4">
                Ejemplos de diferencias entre fechas
              </h2>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-neutral-50">
                      <th className="text-left p-3 font-semibold text-neutral-700">Período</th>
                      <th className="text-right p-3 font-semibold text-neutral-700">Días</th>
                      <th className="text-right p-3 font-semibold text-neutral-700">Semanas</th>
                      <th className="text-right p-3 font-semibold text-neutral-700">Laborables</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {[
                      { period: "1 semana", days: "7", weeks: "1", working: "5" },
                      { period: "1 mes (enero)", days: "31", weeks: "4,4", working: "23" },
                      { period: "1 trimestre", days: "90–92", weeks: "13", working: "~65" },
                      { period: "1 año (2025)", days: "365", weeks: "52", working: "261" },
                      { period: "1 año bisiesto (2024)", days: "366", weeks: "52,3", working: "262" },
                      { period: "Contrato 6 meses", days: "181–184", weeks: "26", working: "~130" },
                      { period: "Período prueba (2 meses)", days: "59–62", weeks: "~9", working: "~43" },
                    ].map((row) => (
                      <tr key={row.period} className="hover:bg-neutral-50">
                        <td className="p-3 text-neutral-800 font-medium">{row.period}</td>
                        <td className="p-3 text-right tabular-nums text-neutral-700">{row.days}</td>
                        <td className="p-3 text-right tabular-nums text-neutral-700">{row.weeks}</td>
                        <td className="p-3 text-right tabular-nums text-brand-700 font-semibold">{row.working}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <p className="text-xs text-neutral-400 mt-2">* Los días laborables excluyen sábados y domingos. No incluye festivos nacionales ni locales.</p>
              </div>
            </section>

            {/* Plazos legales */}
            <section className="mt-6 card p-6" aria-labelledby="plazos">
              <h2 id="plazos" className="text-xl font-bold text-neutral-900 mb-4">
                Plazos legales relevantes en España
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                {[
                  { label: "Período de prueba máximo (técnico)", value: "6 meses" },
                  { label: "Período de prueba (resto)", value: "2 meses" },
                  { label: "Preaviso despido (> 1 año)", value: "15 días" },
                  { label: "Plazo reclamación laboral", value: "20 días hábiles" },
                  { label: "Recurso alzada (Adm. Pública)", value: "1 mes" },
                  { label: "Recurso contencioso administrativo", value: "2 meses" },
                  { label: "Prescripción deuda civil general", value: "5 años" },
                  { label: "Garantía producto nuevo", value: "3 años (desde 2022)" },
                ].map((item) => (
                  <div key={item.label} className="flex justify-between items-center bg-neutral-50 rounded-lg p-3">
                    <span className="text-neutral-600 text-xs">{item.label}</span>
                    <span className="font-semibold text-brand-700 text-xs whitespace-nowrap ml-2">{item.value}</span>
                  </div>
                ))}
              </div>
              <p className="text-xs text-neutral-400 mt-3">
                ⚠️ Esta información es orientativa. Consulta siempre con un profesional legal para tu caso concreto.
              </p>
            </section>

            <div className="mt-6">
              <FAQ items={FAQ_ITEMS} title="Preguntas frecuentes sobre diferencia entre fechas" />

            {/* Enlace interno contextual */}
            <div className="mt-6 bg-neutral-50 border border-neutral-200 rounded-2xl p-5">
              <p className="text-sm text-neutral-600">
                Para calcular tu edad exacta desde tu fecha de nacimiento, visita la{" "}
                <a href="/calculadoras/edad" className="text-brand-600 hover:underline font-semibold">calculadora de edad</a>
                , con signo zodiacal y cuenta atrás hasta tu cumpleaños incluidos.
              </p>
            </div>
            </div>
          </div>

          <aside className="space-y-5">
            <AdPlaceholder label="Publicidad — 300×250" height={250} />
            <div className="card p-5">
              <h3 className="font-semibold text-neutral-900 mb-3">Conversiones rápidas</h3>
              <div className="space-y-2 text-sm">
                {[
                  { from: "1 semana", to: "7 días · 168 horas" },
                  { from: "1 mes (aprox.)", to: "30,4 días · 4,3 semanas" },
                  { from: "1 trimestre", to: "91,25 días · 13 semanas" },
                  { from: "1 año", to: "365 días · 52,14 semanas" },
                  { from: "1 lustro", to: "5 años · 1.826 días" },
                  { from: "1 década", to: "10 años · 3.652 días" },
                ].map((item) => (
                  <div key={item.from} className="flex flex-col border-b border-neutral-100 pb-2">
                    <span className="font-semibold text-neutral-800">{item.from}</span>
                    <span className="text-neutral-500 text-xs">{item.to}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="card p-5">
              <h3 className="font-semibold text-neutral-900 mb-3">Calculadoras relacionadas</h3>
              <div className="space-y-2">
                {RELATED.map((calc) => (
                  <CalculatorCard key={calc.id} icon={calc.icon} name={calc.name} description={calc.description} href={calc.href} />
                ))}
              </div>
            </div>
            <AdPlaceholder label="Publicidad — 300×600" height={300} />
          </aside>
        </div>
      </div>
    </>
  );
}
