"use client";

import { useState, useMemo } from "react";

export function DiferenciaFechasCalculator() {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  const results = useMemo(() => {
    if (!startDate || !endDate) return null;
    let start = new Date(startDate);
    let end = new Date(endDate);

    if (isNaN(start.getTime()) || isNaN(end.getTime())) return null;
    if (start > end) [start, end] = [end, start];

    const msPerDay = 1000 * 60 * 60 * 24;
    const totalDays = Math.round((end.getTime() - start.getTime()) / msPerDay);

    // Counting weekdays
    let businessDays = 0;
    const cursor = new Date(start);
    while (cursor <= end) {
      const dow = cursor.getDay();
      if (dow !== 0 && dow !== 6) businessDays++;
      cursor.setDate(cursor.getDate() + 1);
    }
    const weekendDays = totalDays - businessDays + 1;

    const years = Math.floor(totalDays / 365.25);
    const remainingDays = totalDays - Math.floor(years * 365.25);
    const months = Math.floor(remainingDays / 30.44);
    const days = Math.round(remainingDays - months * 30.44);

    const weeks = Math.floor(totalDays / 7);
    const hours = totalDays * 24;
    const minutes = hours * 60;

    const dayNames = ["domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"];

    return {
      totalDays,
      years, months, days,
      weeks,
      hours,
      minutes,
      businessDays,
      weekendDays: weekendDays - 1,
      startDay: dayNames[new Date(startDate).getDay()],
      endDay: dayNames[new Date(endDate).getDay()],
    };
  }, [startDate, endDate]);

  const swap = () => {
    const tmp = startDate;
    setStartDate(endDate);
    setEndDate(tmp);
  };

  return (
    <div className="card p-6 space-y-5">
      <div className="flex flex-col sm:flex-row items-end gap-3">
        <div className="flex-1">
          <label className="input-label">Fecha de inicio</label>
          <input type="date" value={startDate}
            onChange={(e) => setStartDate(e.target.value)} className="input-field" />
        </div>
        <button onClick={swap} className="btn-ghost px-3 py-3 mb-0.5 flex-shrink-0" title="Intercambiar fechas">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
          </svg>
        </button>
        <div className="flex-1">
          <label className="input-label">Fecha de fin</label>
          <input type="date" value={endDate}
            onChange={(e) => setEndDate(e.target.value)} className="input-field" />
        </div>
      </div>

      {results ? (
        <div className="space-y-4">
          {/* Main result */}
          <div className="result-box py-6 text-center">
            <p className="result-label text-sm mb-3">Diferencia total</p>
            <div className="flex items-center justify-center gap-3 flex-wrap">
              {results.years > 0 && (
                <div className="text-center">
                  <p className="text-4xl font-bold text-brand-700 tabular-nums">{results.years}</p>
                  <p className="text-sm text-brand-500">años</p>
                </div>
              )}
              {results.months > 0 && (
                <div className="text-center">
                  <p className="text-4xl font-bold text-brand-600 tabular-nums">{results.months}</p>
                  <p className="text-sm text-brand-500">meses</p>
                </div>
              )}
              <div className="text-center">
                <p className="text-4xl font-bold text-brand-500 tabular-nums">{results.days}</p>
                <p className="text-sm text-brand-400">días</p>
              </div>
            </div>
          </div>

          {/* Stats grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {[
              { label: "Total días", value: results.totalDays.toLocaleString("es-ES"), icon: "📅" },
              { label: "Semanas completas", value: results.weeks.toLocaleString("es-ES"), icon: "📆" },
              { label: "Horas totales", value: results.hours.toLocaleString("es-ES"), icon: "⏰" },
              { label: "Días laborables", value: results.businessDays.toLocaleString("es-ES"), icon: "💼" },
              { label: "Fines de semana", value: results.weekendDays.toLocaleString("es-ES"), icon: "🏖️" },
              { label: "Minutos totales", value: (results.minutes).toLocaleString("es-ES"), icon: "⏱️" },
            ].map((item) => (
              <div key={item.label} className="bg-neutral-50 rounded-xl p-3 text-center">
                <p className="text-lg mb-0.5">{item.icon}</p>
                <p className="text-xl font-bold text-neutral-800 tabular-nums">{item.value}</p>
                <p className="text-xs text-neutral-500 mt-0.5">{item.label}</p>
              </div>
            ))}
          </div>

          {/* Day names */}
          <div className="bg-neutral-50 rounded-xl p-4 text-sm flex justify-around">
            <div className="text-center">
              <p className="text-xs text-neutral-400 mb-0.5">Inicio</p>
              <p className="font-semibold text-neutral-700 capitalize">{results.startDay}</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-neutral-400 mb-0.5">Fin</p>
              <p className="font-semibold text-neutral-700 capitalize">{results.endDay}</p>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-neutral-50 rounded-2xl p-8 text-center">
          <p className="text-4xl mb-3">📅</p>
          <p className="text-neutral-500 text-sm">Selecciona dos fechas para calcular la diferencia</p>
        </div>
      )}
    </div>
  );
}
