import type { Metadata } from "next";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { CalculatorCard } from "@/components/ui/CalculatorCard";
import { AdPlaceholder } from "@/components/ui/AdSense";
import { CALCULATORS, CATEGORIES, SITE_CONFIG } from "@/lib/config";

export const metadata: Metadata = {
  title: "Todas las Calculadoras Gratuitas en Español",
  description:
    "Explora todas nuestras calculadoras gratuitas en español: IVA, hipoteca, IMC, EVAU, interés compuesto y más. Resultados instantáneos, sin registro.",
  alternates: { canonical: `${SITE_CONFIG.url}/calculadoras` },
  openGraph: {
    title: "Todas las Calculadoras Gratuitas en Español",
    description: "Explora todas nuestras calculadoras gratuitas: finanzas, educación, salud y utilidades.",
    url: `${SITE_CONFIG.url}/calculadoras`,
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "Todas las Calculadoras Gratuitas — Calculadoras España",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Todas las Calculadoras — Calculadoras España",
    description: "Listado completo de calculadoras gratuitas en español.",
    images: ["/og-image.png"],
  },
};

const schema = {
  "@context": "https://schema.org",
  "@type": "CollectionPage",
  name: "Todas las Calculadoras — Calculadoras España",
  description: "Listado completo de calculadoras gratuitas en español",
  url: `${SITE_CONFIG.url}/calculadoras`,
  inLanguage: "es",
  hasPart: CALCULATORS.map((calc) => ({
    "@type": "SoftwareApplication",
    name: calc.name,
    url: `${SITE_CONFIG.url}${calc.href}`,
    applicationCategory: "UtilityApplication",
    offers: { "@type": "Offer", price: "0", priceCurrency: "EUR" },
  })),
};

// Accepts optional ?q= search param from the hero form
export default async function CalculadorasIndexPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const params = await searchParams;
  const query = params.q?.toLowerCase().trim() ?? "";

  const filteredCalcs = query
    ? CALCULATORS.filter(
        (c) =>
          c.name.toLowerCase().includes(query) ||
          c.description.toLowerCase().includes(query) ||
          c.keywords.some((k) => k.includes(query))
      )
    : null;

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
      />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Breadcrumb items={[{ name: "Calculadoras", href: "/calculadoras" }]} />

        <div className="mt-4 mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold text-neutral-900 mb-3">
            {query ? `Resultados para "${params.q}"` : "Todas las Calculadoras"}
          </h1>
          <p className="text-neutral-600 leading-relaxed max-w-2xl">
            {query
              ? `${filteredCalcs?.length ?? 0} calculadoras encontradas.`
              : `${CALCULATORS.length} calculadoras gratuitas en español, organizadas por categoría.`}
          </p>
        </div>

        <AdPlaceholder label="Publicidad — 728×90" height={90} />

        {/* Search results */}
        {filteredCalcs !== null ? (
          <section aria-label="Resultados de búsqueda" className="py-6">
            {filteredCalcs.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {filteredCalcs.map((calc) => (
                  <CalculatorCard
                    key={calc.id}
                    icon={calc.icon}
                    name={calc.name}
                    description={calc.description}
                    href={calc.href}
                    featured={calc.featured}
                    popular={calc.popular}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <p className="text-5xl mb-4">🔍</p>
                <p className="text-neutral-500">
                  No se encontraron calculadoras para &ldquo;{params.q}&rdquo;.
                </p>
                <a href="/calculadoras" className="mt-4 inline-block text-brand-600 hover:underline text-sm font-medium">
                  Ver todas las calculadoras →
                </a>
              </div>
            )}
          </section>
        ) : (
          /* Default: all calculators by category */
          CATEGORIES.map((category) => {
            const calcs = CALCULATORS.filter((c) => c.category === category.id);
            if (calcs.length === 0) return null;
            return (
              <section
                key={category.id}
                id={category.id}
                className="py-8 scroll-mt-20"
                aria-labelledby={`cat-index-${category.id}`}
              >
                <div className="flex items-center gap-3 mb-5">
                  <span className="text-3xl" aria-hidden="true">{category.icon}</span>
                  <div>
                    <h2 id={`cat-index-${category.id}`} className="text-xl font-bold text-neutral-900">
                      {category.name}
                    </h2>
                    <p className="text-sm text-neutral-500">{category.description}</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {calcs.map((calc) => (
                    <CalculatorCard
                      key={calc.id}
                      icon={calc.icon}
                      name={calc.name}
                      description={calc.description}
                      href={calc.href}
                      featured={calc.featured}
                      popular={calc.popular}
                    />
                  ))}
                </div>
              </section>
            );
          })
        )}

        <AdPlaceholder label="Publicidad — 728×90" height={90} />
      </div>
    </>
  );
}
