import type { Metadata } from "next";
import { EdadCalculator } from "./EdadCalculator";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { FAQ } from "@/components/ui/FAQ";
import { AdPlaceholder, AffiliateBlock } from "@/components/ui/AdSense";
import { CalculatorCard } from "@/components/ui/CalculatorCard";
import { CALCULATORS, SITE_CONFIG } from "@/lib/config";

export const metadata: Metadata = {
  title: "Calculadora de Edad — Años, Meses y Días Exactos Gratis",
  description:
    "Calcula tu edad exacta en años, meses, días y horas desde tu fecha de nacimiento. Incluye signo del zodiaco, día de la semana y cuenta atrás hasta tu próximo cumpleaños.",
  alternates: { canonical: `${SITE_CONFIG.url}/calculadoras/edad` },
  openGraph: {
    title: "Calculadora de Edad Exacta — Años, Meses y Días",
    description:
      "Calcula tu edad exacta al instante. Incluye total en días, semanas, horas, signo zodiacal y cuenta atrás hasta tu próximo cumpleaños.",
    url: `${SITE_CONFIG.url}/calculadoras/edad`,
    images: [{ url: "/og-image.png", width: 1200, height: 630, alt: "Calculadora de Edad — Calculadoras España" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Calculadora de Edad Exacta",
    description: "Calcula cuántos años, meses, días y horas tienes exactamente. Con signo zodiacal y próximo cumpleaños.",
    images: ["/og-image.png"],
  },
};

const FAQ_ITEMS = [
  {
    question: "¿Cómo calculo mi edad exacta en años, meses y días?",
    answer:
      "Para calcular la edad exacta, resta la fecha de nacimiento a la fecha actual. Primero calcula los años cumplidos, luego los meses completos transcurridos en el año actual y finalmente los días restantes. Ten en cuenta los años bisiestos (febrero tiene 29 días) y que cada mes tiene un número diferente de días. Nuestra calculadora lo hace automáticamente con total precisión.",
  },
  {
    question: "¿Para qué sirve saber la edad exacta en días?",
    answer:
      "Conocer la edad en días es útil en múltiples situaciones: saber si cumples requisitos de edad mínima para votar, jubilarte o acceder a prestaciones; calcular la antigüedad exacta en un empleo; determinar plazos legales o administrativos; o simplemente por curiosidad personal. También se usa en pediatría para el seguimiento del desarrollo infantil (edad en semanas y meses).",
  },
  {
    question: "¿Qué es un año bisiesto y cómo afecta al cálculo de la edad?",
    answer:
      "Un año bisiesto tiene 366 días en lugar de 365. Ocurre cada 4 años, excepto en años centenales no divisibles por 400 (ej: 1900 no fue bisiesto, 2000 sí lo fue). Si naciste el 29 de febrero, tu cumpleaños solo existe en años bisiestos; el resto de años, se celebra el 28 de febrero o el 1 de marzo según convenio. Nuestra calculadora tiene en cuenta todos estos casos automáticamente.",
  },
  {
    question: "¿Cómo se determina el signo del zodiaco según la fecha de nacimiento?",
    answer:
      "El zodiaco occidental divide el año en 12 periodos. Los signos y sus fechas aproximadas son: Capricornio (22 dic–19 ene), Acuario (20 ene–18 feb), Piscis (19 feb–20 mar), Aries (21 mar–19 abr), Tauro (20 abr–20 may), Géminis (21 may–20 jun), Cáncer (21 jun–22 jul), Leo (23 jul–22 ago), Virgo (23 ago–22 sep), Libra (23 sep–22 oct), Escorpio (23 oct–21 nov), Sagitario (22 nov–21 dic). Las fechas de corte exactas varían ligeramente cada año por la posición real del Sol.",
  },
  {
    question: "¿Cuántos días tiene cada mes?",
    answer:
      "Enero: 31, Febrero: 28 (29 en bisiesto), Marzo: 31, Abril: 30, Mayo: 31, Junio: 30, Julio: 31, Agosto: 31, Septiembre: 30, Octubre: 31, Noviembre: 30, Diciembre: 31. Un truco para recordarlo: los meses que caen en los nudillos de la mano cerrada tienen 31 días; los que caen entre los nudillos tienen 30 (o 28/29 en el caso de febrero).",
  },
  {
    question: "¿Puedo calcular la edad de otra persona o una fecha futura?",
    answer:
      "Sí. Puedes cambiar la 'Fecha de referencia' a cualquier fecha pasada o futura. Por ejemplo, para calcular cuántos años tendrá alguien el 1 de enero de 2030, pon su fecha de nacimiento y como fecha de referencia el 01/01/2030. También sirve para calcular la edad que tenías en un evento histórico concreto.",
  },
];

const RELATED = CALCULATORS.filter((c) => ["diferencia-fechas", "imc"].includes(c.id));

const schema = {
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  name: "Calculadora de Edad",
  applicationCategory: "UtilitiesApplication",
  operatingSystem: "Web",
  browserRequirements: "Requires JavaScript",
  inLanguage: "es",
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "EUR",
    availability: "https://schema.org/InStock",
  },
  description:
    "Calcula tu edad exacta en años, meses, días y horas. Incluye signo del zodiaco, día de la semana de nacimiento y días hasta el próximo cumpleaños.",
  url: `${SITE_CONFIG.url}/calculadoras/edad`,
  author: {
    "@type": "Organization",
    name: SITE_CONFIG.name,
    url: SITE_CONFIG.url,
  },
};

export default function EdadPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
      />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Breadcrumb
          items={[
            { name: "Calculadoras", href: "/calculadoras" },
            { name: "Utilidades", href: "/calculadoras#utilidades" },
            { name: "Calculadora de Edad", href: "/calculadoras/edad" },
          ]}
        />
        <AdPlaceholder label="Publicidad — 728×90" height={90} />

        <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="mb-6">
              <div className="flex items-center gap-3 mb-3">
                <span className="text-4xl" aria-hidden="true">🎂</span>
                <div>
                  <h1 className="text-3xl sm:text-4xl font-bold text-neutral-900">
                    Calculadora de Edad
                  </h1>
                  <p className="text-neutral-500 mt-0.5">
                    Años, meses, días y horas exactos
                  </p>
                </div>
              </div>
              <p className="text-neutral-600 leading-relaxed">
                Calcula tu <strong>edad exacta</strong> al instante: años, meses, días y horas transcurridos
                desde tu fecha de nacimiento. También obtendrás el total en semanas y días, tu{" "}
                <strong>signo del zodiaco</strong>, el día de la semana en que naciste y cuántos días
                faltan para tu <strong>próximo cumpleaños</strong>.
              </p>
            </div>

            <EdadCalculator />

            {/* Formula / how it works */}
            <section className="mt-8 card p-6" aria-labelledby="como-calcular">
              <h2 id="como-calcular" className="text-xl font-bold text-neutral-900 mb-4">
                ¿Cómo se calcula la edad exacta?
              </h2>
              <div className="space-y-4 text-neutral-600 text-sm leading-relaxed">
                <p>
                  El cálculo de la edad exacta sigue estos tres pasos:
                </p>
                <ol className="list-decimal list-inside space-y-3 marker:font-bold marker:text-brand-600">
                  <li>
                    <strong>Años cumplidos:</strong> Resta el año de nacimiento al año de referencia.
                    Si el mes/día actuales son anteriores al mes/día de nacimiento, resta un año más
                    (todavía no has cumplido el siguiente aniversario este año).
                  </li>
                  <li>
                    <strong>Meses completos:</strong> Resta el mes de nacimiento al mes actual. Si el
                    día actual es menor que el día de nacimiento, resta un mes (no ha concluido ese mes
                    completo). Si el resultado es negativo, suma 12 y resta un año.
                  </li>
                  <li>
                    <strong>Días restantes:</strong> Resta el día de nacimiento al día actual. Si es
                    negativo, suma el número de días del mes anterior al mes actual.
                  </li>
                </ol>
                <div className="bg-brand-50 border border-brand-100 rounded-xl p-4 mt-4">
                  <p className="font-semibold text-brand-800 mb-2">Ejemplo:</p>
                  <p className="text-brand-700">
                    Nacido el <strong>15 de marzo de 1990</strong>, fecha actual <strong>10 de junio de 2025</strong>:
                  </p>
                  <ul className="mt-2 space-y-1 text-brand-700">
                    <li>Años: 2025 − 1990 = 35 (pero en marzo ya cumpliste, así que son 35 años).</li>
                    <li>Meses: junio (6) − marzo (3) = 3 meses. Pero el día 10 &lt; 15, entonces 2 meses.</li>
                    <li>Días: 10 + (días de mayo − 15) = 10 + 16 = 26 días.</li>
                    <li className="font-bold">Resultado: <span className="text-brand-900">35 años, 2 meses y 26 días</span>.</li>
                  </ul>
                </div>
              </div>
            </section>

            {/* Tabla conversiones rápidas */}
            <section className="mt-6 card p-6 overflow-x-auto" aria-labelledby="conversiones">
              <h2 id="conversiones" className="text-xl font-bold text-neutral-900 mb-4">
                Edades comunes en días y semanas
              </h2>
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-neutral-50">
                    <th className="text-left p-3 font-semibold text-neutral-700">Edad</th>
                    <th className="text-right p-3 font-semibold text-neutral-700">Días</th>
                    <th className="text-right p-3 font-semibold text-neutral-700">Semanas</th>
                    <th className="text-right p-3 font-semibold text-neutral-700">Horas</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {[
                    { age: "1 año", days: "365", weeks: "52", hours: "8.760" },
                    { age: "5 años", days: "1.826", weeks: "260", hours: "43.824" },
                    { age: "10 años", days: "3.652", weeks: "521", hours: "87.648" },
                    { age: "18 años", days: "6.570", weeks: "938", hours: "157.680" },
                    { age: "25 años", days: "9.131", weeks: "1.304", hours: "219.144" },
                    { age: "30 años", days: "10.957", weeks: "1.565", hours: "262.968" },
                    { age: "40 años", days: "14.610", weeks: "2.087", hours: "350.640" },
                    { age: "50 años", days: "18.262", weeks: "2.609", hours: "438.288" },
                    { age: "65 años", days: "23.741", weeks: "3.391", hours: "569.784" },
                  ].map((row) => (
                    <tr key={row.age} className="hover:bg-neutral-50">
                      <td className="p-3 font-semibold text-neutral-800">{row.age}</td>
                      <td className="p-3 text-right text-neutral-700 tabular-nums">{row.days}</td>
                      <td className="p-3 text-right text-neutral-700 tabular-nums">{row.weeks}</td>
                      <td className="p-3 text-right text-neutral-700 tabular-nums">{row.hours}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <p className="text-xs text-neutral-400 mt-2">* Valores aproximados. Los años bisiestos añaden un día extra cada 4 años.</p>
            </section>

            {/* Curiosidades */}
            <section className="mt-6 card p-6" aria-labelledby="curiosidades">
              <h2 id="curiosidades" className="text-xl font-bold text-neutral-900 mb-4">
                Curiosidades sobre la edad y el tiempo
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm text-neutral-600">
                {[
                  { icon: "⏰", title: "El corazón late ~3.100 millones de veces en 80 años", desc: "A un ritmo de ~70 latidos por minuto, en una vida de 80 años el corazón late más de 3.000 millones de veces." },
                  { icon: "😴", title: "Dormimos ~26 años de 80", desc: "Si dormimos 8 horas al día, pasamos aproximadamente un tercio de nuestra vida durmiendo — unos 26 años en una vida de 80." },
                  { icon: "📚", title: "La esperanza de vida en España", desc: "España tiene una de las esperanzas de vida más altas del mundo: 83,3 años de media (85,7 mujeres, 80,7 hombres) según el INE 2023." },
                  { icon: "🎂", title: "Personas con la misma edad exacta", desc: "Cada día nacen unas 385.000 personas en el mundo. El día de tu cumpleaños comparten fecha aproximadamente 21 millones de personas (1/365 de la población mundial)." },
                ].map((item) => (
                  <div key={item.title} className="bg-neutral-50 rounded-xl p-4">
                    <p className="text-2xl mb-2" aria-hidden="true">{item.icon}</p>
                    <p className="font-semibold text-neutral-800 mb-1 text-xs uppercase tracking-wide">{item.title}</p>
                    <p className="text-xs leading-relaxed">{item.desc}</p>
                  </div>
                ))}
              </div>
            </section>

            <div className="mt-6">
              <FAQ items={FAQ_ITEMS} title="Preguntas frecuentes sobre el cálculo de edad" />

            {/* Enlace interno contextual */}
            <div className="mt-6 bg-neutral-50 border border-neutral-200 rounded-2xl p-5">
              <p className="text-sm text-neutral-600">
                ¿Necesitas el tiempo exacto entre dos fechas concretas? La{" "}
                <a href="/calculadoras/diferencia-fechas" className="text-brand-600 hover:underline font-semibold">calculadora de diferencia entre fechas</a>
                {" "}incluye días laborables, semanas y plazos legales.
              </p>
            </div>
            </div>
          </div>

          <aside className="space-y-5">
            <AdPlaceholder label="Publicidad — 300×250" height={250} />
            <AffiliateBlock
              icon="🎁"
              title="Regala experiencias para su cumpleaños"
              description="Encuentra el regalo perfecto para cualquier edad. Experiencias únicas desde 25€."
              cta="Ver experiencias"
              href="#"
            />
            <div className="card p-5">
              <h3 className="font-semibold text-neutral-900 mb-3">Hitos de edad en España</h3>
              <div className="space-y-2 text-sm">
                {[
                  { age: "14 años", milestone: "DNI obligatorio" },
                  { age: "16 años", milestone: "Edad mínima laboral" },
                  { age: "18 años", milestone: "Mayoría de edad, voto" },
                  { age: "25 años", milestone: "Alquiler: fin de prorroga forzosa" },
                  { age: "65 años", milestone: "Jubilación ordinaria (referencia)" },
                  { age: "67 años", milestone: "Jubilación ordinaria 2027+" },
                ].map((item) => (
                  <div key={item.age} className="flex justify-between items-center">
                    <span className="font-semibold text-brand-700">{item.age}</span>
                    <span className="text-neutral-500 text-xs text-right">{item.milestone}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="card p-5">
              <h3 className="font-semibold text-neutral-900 mb-3">Calculadoras relacionadas</h3>
              <div className="space-y-2">
                {RELATED.map((calc) => (
                  <CalculatorCard key={calc.id} icon={calc.icon} name={calc.name} description={calc.description} href={calc.href} />
                ))}
              </div>
            </div>
            <AdPlaceholder label="Publicidad — 300×600" height={300} />
          </aside>
        </div>
      </div>
    </>
  );
}
