"use client";

import { useState, useMemo } from "react";

export function EdadCalculator() {
  const [birthDate, setBirthDate] = useState("");
  const [referenceDate, setReferenceDate] = useState(
    new Date().toISOString().split("T")[0]
  );

  const results = useMemo(() => {
    if (!birthDate || !referenceDate) return null;
    const birth = new Date(birthDate);
    const ref = new Date(referenceDate);
    if (isNaN(birth.getTime()) || isNaN(ref.getTime())) return null;
    if (birth > ref) return null;

    let years = ref.getFullYear() - birth.getFullYear();
    let months = ref.getMonth() - birth.getMonth();
    let days = ref.getDate() - birth.getDate();

    if (days < 0) {
      months--;
      const lastMonth = new Date(ref.getFullYear(), ref.getMonth(), 0);
      days += lastMonth.getDate();
    }
    if (months < 0) {
      years--;
      months += 12;
    }

    const totalDays = Math.floor((ref.getTime() - birth.getTime()) / (1000 * 60 * 60 * 24));
    const totalWeeks = Math.floor(totalDays / 7);
    const totalMonths = years * 12 + months;
    const totalHours = totalDays * 24;

    // Next birthday
    const nextBirthday = new Date(ref.getFullYear(), birth.getMonth(), birth.getDate());
    if (nextBirthday <= ref) nextBirthday.setFullYear(ref.getFullYear() + 1);
    const daysToNext = Math.floor((nextBirthday.getTime() - ref.getTime()) / (1000 * 60 * 60 * 24));

    // Zodiac sign
    const month = birth.getMonth() + 1;
    const day = birth.getDate();
    const zodiacSigns = [
      { sign: "Capricornio", emoji: "♑" },
      { sign: "Acuario", emoji: "♒" },
      { sign: "Piscis", emoji: "♓" },
      { sign: "Aries", emoji: "♈" },
      { sign: "Tauro", emoji: "♉" },
      { sign: "Géminis", emoji: "♊" },
      { sign: "Cáncer", emoji: "♋" },
      { sign: "Leo", emoji: "♌" },
      { sign: "Virgo", emoji: "♍" },
      { sign: "Libra", emoji: "♎" },
      { sign: "Escorpio", emoji: "♏" },
      { sign: "Sagitario", emoji: "♐" },
    ];
    const cutoffs = [20, 19, 21, 20, 21, 21, 23, 23, 23, 23, 22, 22];
    let zodiacIndex = month - 1;
    if (day <= cutoffs[zodiacIndex]) {
      zodiacIndex = (zodiacIndex - 1 + 12) % 12;
    }

    const dayOfWeek = ["domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"][birth.getDay()];

    return {
      years, months, days, totalDays, totalWeeks, totalMonths, totalHours,
      daysToNext, nextBirthday,
      zodiac: zodiacSigns[zodiacIndex],
      dayOfWeek,
    };
  }, [birthDate, referenceDate]);

  return (
    <div className="card p-6 space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="input-label">Fecha de nacimiento</label>
          <input
            type="date"
            value={birthDate}
            onChange={(e) => setBirthDate(e.target.value)}
            max={referenceDate}
            className="input-field"
          />
        </div>
        <div>
          <label className="input-label">Fecha de referencia</label>
          <input
            type="date"
            value={referenceDate}
            onChange={(e) => setReferenceDate(e.target.value)}
            className="input-field"
          />
          <p className="text-xs text-neutral-400 mt-1">Por defecto: hoy</p>
        </div>
      </div>

      {results ? (
        <div className="space-y-4">
          {/* Main result */}
          <div className="result-box text-center py-6">
            <p className="result-label text-sm mb-2">Tu edad exacta</p>
            <div className="flex items-center justify-center gap-4">
              <div>
                <p className="text-5xl font-bold text-brand-700 tabular-nums">{results.years}</p>
                <p className="text-sm text-brand-500 font-medium">años</p>
              </div>
              <div className="text-2xl font-bold text-brand-400">·</div>
              <div>
                <p className="text-3xl font-bold text-brand-600 tabular-nums">{results.months}</p>
                <p className="text-sm text-brand-400 font-medium">meses</p>
              </div>
              <div className="text-2xl font-bold text-brand-400">·</div>
              <div>
                <p className="text-3xl font-bold text-brand-500 tabular-nums">{results.days}</p>
                <p className="text-sm text-brand-400 font-medium">días</p>
              </div>
            </div>
          </div>

          {/* Detailed stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: "Total días", value: results.totalDays.toLocaleString("es-ES") },
              { label: "Total semanas", value: results.totalWeeks.toLocaleString("es-ES") },
              { label: "Total meses", value: results.totalMonths.toLocaleString("es-ES") },
              { label: "Total horas", value: results.totalHours.toLocaleString("es-ES") },
            ].map((item) => (
              <div key={item.label} className="bg-neutral-50 rounded-xl p-3 text-center">
                <p className="text-xl font-bold text-neutral-800 tabular-nums">{item.value}</p>
                <p className="text-xs text-neutral-500 mt-0.5">{item.label}</p>
              </div>
            ))}
          </div>

          {/* Extra info */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm">
            <div className="bg-purple-50 border border-purple-100 rounded-xl p-3 text-center">
              <p className="text-2xl mb-1">{results.zodiac.emoji}</p>
              <p className="font-semibold text-purple-800">{results.zodiac.sign}</p>
              <p className="text-xs text-purple-500">Signo zodiacal</p>
            </div>
            <div className="bg-blue-50 border border-blue-100 rounded-xl p-3 text-center">
              <p className="font-bold text-blue-800 text-lg capitalize">{results.dayOfWeek}</p>
              <p className="text-xs text-blue-500 mt-1">Naciste en</p>
            </div>
            <div className="bg-pink-50 border border-pink-100 rounded-xl p-3 text-center">
              <p className="font-bold text-pink-800 text-lg">{results.daysToNext === 0 ? "¡Hoy! 🎉" : `${results.daysToNext} días`}</p>
              <p className="text-xs text-pink-500 mt-1">Para tu cumpleaños</p>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-neutral-50 rounded-2xl p-8 text-center">
          <p className="text-4xl mb-3">🎂</p>
          <p className="text-neutral-500 text-sm">Introduce tu fecha de nacimiento para calcular tu edad exacta</p>
        </div>
      )}
    </div>
  );
}
