import type { Metadata } from "next";
import { InteresCompuestoCalculator } from "./InteresCompuestoCalculator";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { FAQ } from "@/components/ui/FAQ";
import { AdPlaceholder, AffiliateBlock } from "@/components/ui/AdSense";
import { CalculatorCard } from "@/components/ui/CalculatorCard";
import { CALCULATORS, SITE_CONFIG } from "@/lib/config";

export const metadata: Metadata = {
  title: "Calculadora de Interés Compuesto 2025 — Inversión y Ahorro",
  description:
    "Calcula el crecimiento de tus inversiones con interés compuesto y aportaciones mensuales. Descubre cuánto crecerá tu dinero en el tiempo. Incluye comparativa de escenarios y guía de productos de inversión en España.",
  alternates: { canonical: `${SITE_CONFIG.url}/calculadoras/interes-compuesto` },
  openGraph: {
    title: "Calculadora de Interés Compuesto 2025 — Inversión y Ahorro",
    description:
      "Descubre el poder del interés compuesto. Calcula el crecimiento de tus inversiones con aportaciones mensuales.",
    url: `${SITE_CONFIG.url}/calculadoras/interes-compuesto`,
    images: [{ url: "/og-image.png", width: 1200, height: 630, alt: "Calculadora Interés Compuesto — Calculadoras España" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Calculadora Interés Compuesto 2025",
    description: "Calcula cuánto crecerá tu inversión con el interés compuesto. Incluye aportaciones mensuales.",
    images: ["/og-image.png"],
  },
};

const FAQ_ITEMS = [
  {
    question: "¿Qué es el interés compuesto?",
    answer:
      "El interés compuesto es aquel que se calcula no solo sobre el capital inicial, sino también sobre los intereses acumulados en períodos anteriores. Einstein lo llamó 'la octava maravilla del mundo': los intereses generan más intereses, creando un efecto exponencial. A diferencia del interés simple (que solo crece linealmente sobre el capital inicial), el compuesto crece de forma acelerada con el tiempo.",
  },
  {
    question: "¿Cuál es la fórmula del interés compuesto?",
    answer:
      "La fórmula básica sin aportaciones es: VF = C × (1 + r)^n, donde VF es el valor futuro, C es el capital inicial, r es la tasa de interés por período y n el número de períodos. Con aportaciones periódicas: VF = C × (1+r)^n + A × [(1+r)^n - 1] / r, donde A es la aportación por período. Nuestra calculadora usa interés compuesto mensual, que es el estándar para calcular inversiones con aportaciones mensuales.",
  },
  {
    question: "¿Cuál es la regla del 72?",
    answer:
      "La regla del 72 es un atajo mental para calcular en cuántos años se duplica una inversión: divide 72 entre la rentabilidad anual. Con un 6% anual: 72/6 = 12 años para duplicar. Con un 8%: 72/8 = 9 años. Con un 10%: 72/10 = 7,2 años. Es una aproximación muy útil para comparar inversiones rápidamente sin calculadora.",
  },
  {
    question: "¿Qué rentabilidad histórica han tenido las inversiones en España?",
    answer:
      "El índice global MSCI World ha dado una rentabilidad histórica de aproximadamente 9-10% nominal anual (7% real ajustado por inflación) desde 1970. El S&P 500 americano ha rendido ~10% nominal. El IBEX 35 español ha tenido un rendimiento más modesto, alrededor del 5-7% nominal histórico con alta volatilidad. Los bonos del Estado español a 10 años rinden actualmente en torno al 3-3,5%. Recuerda: rentabilidades pasadas no garantizan resultados futuros.",
  },
  {
    question: "¿Cómo puedo aprovechar el interés compuesto en España?",
    answer:
      "Los vehículos más eficientes en España son: (1) Fondos de inversión indexados (MSCI World, S&P 500) disponibles en myInvestor, Indexa Capital o Trade Republic desde 1€; la ventaja fiscal española permite traspasar entre fondos sin tributar. (2) ETFs cotizados en plataformas como Trade Republic o Degiro. (3) Planes de pensiones: deducción fiscal en IRPF hasta 1.500€/año. (4) Cuentas de ahorro remuneradas (actualmente 2-3%). La clave es empezar pronto y mantener la inversión a largo plazo.",
  },
  {
    question: "¿Cuándo empezar a invertir: con 25 o con 45 años?",
    answer:
      "Cuanto antes, mejor. El tiempo es el factor más poderoso del interés compuesto. Ejemplo: invirtiendo 200€/mes desde los 25 años al 7% anual, a los 65 tienes ~530.000€. Si empiezas a los 35, solo llegas a ~240.000€. Esperar 10 años te cuesta más de 290.000€ en capital acumulado, a pesar de invertir la misma cantidad mensual. La diferencia se llama 'coste de oportunidad del tiempo'.",
  },
  {
    question: "¿Es lo mismo interés compuesto mensual que anual?",
    answer:
      "No. El interés compuesto mensual genera más rendimiento que el anual con la misma tasa nominal, porque los intereses se capitalizan más frecuentemente. Para convertir una tasa anual a mensual: r_mensual = (1 + r_anual)^(1/12) - 1. Con un 7% anual, la tasa mensual equivalente es aproximadamente 0,565%. Este cálculo es el que utiliza nuestra calculadora para mayor precisión cuando hay aportaciones mensuales.",
  },
];

const RELATED = CALCULATORS.filter((c) => ["hipoteca", "iva"].includes(c.id));

const schema = {
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  name: "Calculadora de Interés Compuesto",
  applicationCategory: "FinanceApplication",
  operatingSystem: "Web",
  browserRequirements: "Requires JavaScript",
  inLanguage: "es",
  offers: { "@type": "Offer", price: "0", priceCurrency: "EUR", availability: "https://schema.org/InStock" },
  description:
    "Calcula el crecimiento de tus inversiones con interés compuesto y aportaciones mensuales regulares.",
  url: `${SITE_CONFIG.url}/calculadoras/interes-compuesto`,
  author: { "@type": "Organization", name: SITE_CONFIG.name, url: SITE_CONFIG.url },
};

export default function InteresCompuestoPage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Breadcrumb items={[
          { name: "Calculadoras", href: "/calculadoras" },
          { name: "Finanzas", href: "/calculadoras#finanzas" },
          { name: "Interés Compuesto", href: "/calculadoras/interes-compuesto" },
        ]} />
        <AdPlaceholder label="Publicidad — 728×90" height={90} />

        <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">

            <div className="mb-6">
              <div className="flex items-center gap-3 mb-3">
                <span className="text-4xl" aria-hidden="true">📈</span>
                <div>
                  <h1 className="text-3xl sm:text-4xl font-bold text-neutral-900">Calculadora de Interés Compuesto</h1>
                  <p className="text-neutral-500 mt-0.5">La herramienta del inversor inteligente · 2025</p>
                </div>
              </div>
              <p className="text-neutral-600 leading-relaxed">
                Descubre el poder del <strong>interés compuesto</strong> en tus inversiones. Calcula cuánto crecerá
                tu dinero con <strong>aportaciones mensuales</strong> regulares a lo largo del tiempo. Incluye
                comparativa de escenarios, guía de productos en España y ejemplos resueltos.
              </p>
            </div>

            <InteresCompuestoCalculator />

            {/* Fórmula */}
            <section className="mt-8 card p-6" aria-labelledby="formula-ic">
              <h2 id="formula-ic" className="text-xl font-bold text-neutral-900 mb-4">La fórmula del interés compuesto</h2>
              <div className="bg-neutral-50 border border-neutral-200 rounded-xl p-4 font-mono text-sm mb-4 overflow-x-auto">
                <p className="font-bold text-neutral-900">VF = C × (1 + r)^n + A × [(1+r)^n − 1] / r</p>
                <ul className="text-xs text-neutral-500 mt-2 space-y-1">
                  <li>VF = Valor futuro de la inversión</li>
                  <li>C = Capital inicial</li>
                  <li>r = Tasa de interés mensual (tasa anual ÷ 12)</li>
                  <li>n = Número de meses (años × 12)</li>
                  <li>A = Aportación mensual</li>
                </ul>
              </div>
              <div className="bg-brand-50 border border-brand-100 rounded-xl p-4 text-sm">
                <p className="font-semibold text-brand-800 mb-2">🧮 Ejemplo resuelto:</p>
                <ul className="space-y-1 text-brand-700">
                  <li>Capital inicial: <strong>10.000€</strong>, aportación: <strong>200€/mes</strong>, rentabilidad: <strong>7% anual</strong>, plazo: <strong>20 años</strong></li>
                  <li>r mensual = 7% ÷ 12 = 0,5833%</li>
                  <li>Crecimiento del capital: 10.000 × (1,005833)^240 = <strong>40.988€</strong></li>
                  <li>Crecimiento aportaciones: 200 × [(1,005833)^240 − 1] / 0,005833 = <strong>104.185€</strong></li>
                  <li className="font-bold pt-1 border-t border-brand-200">
                    Total = <span className="text-brand-900 text-base">145.173€</span> (invertiste 58.000€, ganaste 87.173€)
                  </li>
                </ul>
              </div>
            </section>

            {/* Tabla comparativa de escenarios */}
            <section className="mt-6 card p-6 overflow-x-auto" aria-labelledby="escenarios-ic">
              <h2 id="escenarios-ic" className="text-xl font-bold text-neutral-900 mb-1">
                Comparativa de escenarios: cuánto genera cada estrategia
              </h2>
              <p className="text-sm text-neutral-500 mb-4">Capital inicial: 10.000€ · Rentabilidad: 7% anual compuesto mensual</p>
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-neutral-50">
                    <th className="text-left p-3 font-semibold text-neutral-700">Aportación/mes</th>
                    <th className="text-right p-3 font-semibold text-neutral-700">10 años</th>
                    <th className="text-right p-3 font-semibold text-neutral-700">20 años</th>
                    <th className="text-right p-3 font-semibold text-neutral-700">30 años</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {[
                    { aport: "0€ (solo capital inicial)", y10: "20.097€", y20: "40.388€", y30: "81.165€" },
                    { aport: "100€/mes", y10: "37.499€", y20: "92.538€", y30: "203.382€" },
                    { aport: "200€/mes", y10: "54.901€", y20: "144.688€", y30: "325.599€" },
                    { aport: "300€/mes", y10: "72.303€", y20: "196.839€", y30: "447.816€" },
                    { aport: "500€/mes", y10: "107.107€", y20: "301.139€", y30: "692.249€" },
                  ].map((row) => (
                    <tr key={row.aport} className="hover:bg-neutral-50">
                      <td className="p-3 font-medium text-neutral-800">{row.aport}</td>
                      <td className="p-3 text-right tabular-nums text-neutral-700">{row.y10}</td>
                      <td className="p-3 text-right tabular-nums text-brand-700 font-semibold">{row.y20}</td>
                      <td className="p-3 text-right tabular-nums text-green-700 font-bold">{row.y30}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <p className="text-xs text-neutral-400 mt-2">* Cálculo orientativo. No incluye inflación, impuestos ni comisiones. Rentabilidades pasadas no garantizan resultados futuros.</p>
            </section>

            {/* Productos en España */}
            <section className="mt-6 card p-6" aria-labelledby="productos-esp">
              <h2 id="productos-esp" className="text-xl font-bold text-neutral-900 mb-4">
                Dónde invertir con interés compuesto en España (2025)
              </h2>
              <div className="space-y-3">
                {[
                  {
                    tipo: "Fondos indexados (ETFs/UCITS)",
                    rentabilidad: "~7-10% histórico anual",
                    riesgo: "Medio-alto",
                    fiscal: "Ventaja fiscal: traspaso sin tributar",
                    desc: "Replican índices como MSCI World o S&P 500. Disponibles en myInvestor, Indexa Capital, Finizens, Openbank. Comisiones muy bajas (0,1-0,3% TER).",
                    color: "border-green-200 bg-green-50",
                  },
                  {
                    tipo: "ETFs en bolsa",
                    rentabilidad: "~7-10% histórico anual",
                    riesgo: "Medio-alto",
                    fiscal: "Tributan al vender (19-28% plusvalías)",
                    desc: "Trade Republic, eToro, Degiro, Interactive Brokers. Comisión por operación mínima (1€ en Trade Republic). Más flexibles pero sin ventaja fiscal de traspaso.",
                    color: "border-blue-200 bg-blue-50",
                  },
                  {
                    tipo: "Planes de pensiones",
                    rentabilidad: "Variable según perfil",
                    riesgo: "Variable",
                    fiscal: "Deducción IRPF hasta 1.500€/año",
                    desc: "Ventaja fiscal al aportar pero rescate tributa como rendimiento del trabajo. Iliquidez hasta jubilación (con excepciones). Idóneo como complemento, no como única inversión.",
                    color: "border-purple-200 bg-purple-50",
                  },
                  {
                    tipo: "Cuentas remuneradas / depósitos",
                    rentabilidad: "2-3% anual (2025)",
                    riesgo: "Muy bajo",
                    fiscal: "Retención 19% en origen",
                    desc: "Trade Republic 4% (limitado), Bunq, ING, EVO Banco. Rentabilidad baja pero sin riesgo de capital. Útil para el fondo de emergencia o dinero a corto plazo.",
                    color: "border-amber-200 bg-amber-50",
                  },
                ].map((item) => (
                  <div key={item.tipo} className={`rounded-xl p-4 border ${item.color}`}>
                    <div className="flex flex-wrap items-start justify-between gap-2 mb-2">
                      <p className="font-semibold text-neutral-900">{item.tipo}</p>
                      <div className="flex gap-2 flex-wrap">
                        <span className="px-2 py-0.5 bg-white/80 rounded-full text-xs font-semibold text-neutral-700">{item.rentabilidad}</span>
                        <span className="px-2 py-0.5 bg-white/80 rounded-full text-xs text-neutral-500">{item.fiscal}</span>
                      </div>
                    </div>
                    <p className="text-sm text-neutral-600 leading-relaxed">{item.desc}</p>
                  </div>
                ))}
              </div>
              <p className="text-xs text-neutral-400 mt-3">
                ⚠️ Esta información es educativa. Consulta con un asesor financiero certificado (CNMV) antes de invertir.
              </p>
            </section>

            {/* Errores frecuentes */}
            <section className="mt-6 card p-6" aria-labelledby="errores-ic">
              <h2 id="errores-ic" className="text-xl font-bold text-neutral-900 mb-4">
                Errores frecuentes al calcular el interés compuesto
              </h2>
              <div className="space-y-3 text-sm">
                {[
                  {
                    error: "Confundir rentabilidad nominal y real (ajustada por inflación)",
                    fix: "Un 7% nominal con inflación del 2,5% da solo un 4,4% real. Para saber cuánto ganarás en términos de poder adquisitivo, resta la inflación esperada a la rentabilidad nominal."
                  },
                  {
                    error: "No tener en cuenta los impuestos sobre plusvalías",
                    fix: "En España, las ganancias al reembolsar una inversión tributan entre el 19% y el 28% según el importe. Esto reduce la rentabilidad final. Los fondos indexados permiten diferir este pago hasta el reembolso mediante traspasos exentos."
                  },
                  {
                    error: "Subestimar el impacto de las comisiones",
                    fix: "Una comisión del 1,5% anual vs 0,2% en un fondo indexado puede suponer una diferencia de decenas de miles de euros en 30 años. Las comisiones también se capitalizan: aplican el 'interés compuesto inverso' en tu contra."
                  },
                ].map((item) => (
                  <div key={item.error} className="bg-red-50 border border-red-100 rounded-xl p-4">
                    <p className="font-semibold text-red-800 mb-1">❌ {item.error}</p>
                    <p className="text-red-700 leading-relaxed">✅ {item.fix}</p>
                  </div>
                ))}
              </div>
            </section>

            <div className="mt-6">
              <FAQ items={FAQ_ITEMS} title="Preguntas sobre interés compuesto e inversión" />
            </div>

            {/* Internal link to hipoteca */}
            <div className="mt-6 bg-neutral-50 border border-neutral-200 rounded-2xl p-5">
              <p className="text-sm text-neutral-600">
                ¿Tienes una hipoteca o piensas contratar una? Calcula cuánto pagarás en total y cómo
                afecta el tipo de interés al coste final con nuestra{" "}
                <a href="/calculadoras/hipoteca" className="text-brand-600 hover:underline font-semibold">
                  calculadora de hipoteca
                </a>.
              </p>
            </div>
          </div>

          <aside className="space-y-5">
            <AdPlaceholder label="Publicidad — 300×250" height={250} />
            <AffiliateBlock
              icon="📊"
              title="Invierte desde 1€ en ETFs"
              description="Trade Republic: fondos indexados con comisión de 1€ por operación e interés del 4% en efectivo no invertido."
              cta="Abrir cuenta gratuita"
              href="#"
            />
            <div className="card p-5">
              <h3 className="font-semibold text-neutral-900 mb-3">Rentabilidades históricas de referencia</h3>
              <div className="space-y-2 text-sm">
                {[
                  { label: "MSCI World (desde 1970)", value: "~9% anual" },
                  { label: "S&P 500 (desde 1957)", value: "~10% anual" },
                  { label: "IBEX 35 (desde 1991)", value: "~6% anual" },
                  { label: "Bono español 10 años (2025)", value: "~3,2% anual" },
                  { label: "Cuentas remuneradas (2025)", value: "2-4% anual" },
                  { label: "Inflación España (media 20 años)", value: "~2-3% anual" },
                ].map((item) => (
                  <div key={item.label} className="flex justify-between">
                    <span className="text-neutral-500 text-xs">{item.label}</span>
                    <span className="font-semibold text-brand-700 text-xs">{item.value}</span>
                  </div>
                ))}
              </div>
              <p className="text-xs text-neutral-400 mt-3">Rentabilidades pasadas no garantizan resultados futuros.</p>
            </div>
            <div className="card p-5">
              <h3 className="font-semibold text-neutral-900 mb-3">La regla del 72</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="bg-neutral-50">
                      <th className="p-2 text-left text-neutral-600">Rentabilidad</th>
                      <th className="p-2 text-right text-neutral-600">Años para doblar</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {[
                      { rate: "3%", years: "24 años" },
                      { rate: "5%", years: "14,4 años" },
                      { rate: "7%", years: "10,3 años" },
                      { rate: "10%", years: "7,2 años" },
                      { rate: "12%", years: "6 años" },
                    ].map((row) => (
                      <tr key={row.rate}>
                        <td className="p-2 font-semibold text-brand-700">{row.rate}</td>
                        <td className="p-2 text-right text-neutral-600">{row.years}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            <div className="card p-5">
              <h3 className="font-semibold text-neutral-900 mb-3">Calculadoras relacionadas</h3>
              <div className="space-y-2">
                {RELATED.map((calc) => (
                  <CalculatorCard key={calc.id} icon={calc.icon} name={calc.name} description={calc.description} href={calc.href} />
                ))}
              </div>
            </div>
            <AdPlaceholder label="Publicidad — 300×600" height={300} />
          </aside>
        </div>
      </div>
    </>
  );
}
