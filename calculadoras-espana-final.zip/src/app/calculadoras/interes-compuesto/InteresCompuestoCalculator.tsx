"use client";

import { useState, useMemo } from "react";
import { formatCurrency, formatNumber } from "@/lib/utils";

export function InteresCompuestoCalculator() {
  const [capital, setCapital] = useState("10000");
  const [monthly, setMonthly] = useState("200");
  const [rate, setRate] = useState("7");
  const [years, setYears] = useState("20");

  const results = useMemo(() => {
    const P = parseFloat(capital.replace(",", ".")) || 0;
    const m = parseFloat(monthly.replace(",", ".")) || 0;
    const r = (parseFloat(rate.replace(",", ".")) || 0) / 100 / 12;
    const n = (parseInt(years) || 0) * 12;

    if (n <= 0 || r < 0) return null;

    // Future value with compound interest + monthly contributions
    const futureCapital = P * Math.pow(1 + r, n);
    const futureMonthly = m > 0 && r > 0
      ? m * ((Math.pow(1 + r, n) - 1) / r)
      : m * n;
    const total = futureCapital + futureMonthly;
    const totalInvested = P + m * n;
    const totalInterest = total - totalInvested;

    // Year by year breakdown
    const yearlyData: { year: number; value: number; invested: number }[] = [];
    for (let y = 0; y <= parseInt(years); y++) {
      const ny = y * 12;
      const fv = P * Math.pow(1 + r, ny) +
        (m > 0 && r > 0 ? m * ((Math.pow(1 + r, ny) - 1) / r) : m * ny);
      yearlyData.push({ year: y, value: fv, invested: P + m * ny });
    }

    return { total, totalInvested, totalInterest, yearlyData };
  }, [capital, monthly, rate, years]);

  return (
    <div className="card p-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        <div>
          <label className="input-label">Capital inicial (€)</label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400 text-sm">€</span>
            <input type="number" inputMode="numeric" value={capital}
              onChange={(e) => setCapital(e.target.value)}
              className="input-field pl-8" min="0" step="100" />
          </div>
        </div>
        <div>
          <label className="input-label">Aportación mensual (€)</label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400 text-sm">€</span>
            <input type="number" inputMode="numeric" value={monthly}
              onChange={(e) => setMonthly(e.target.value)}
              className="input-field pl-8" min="0" step="50" />
          </div>
        </div>
        <div>
          <label className="input-label">Rentabilidad anual (%)</label>
          <div className="relative">
            <input type="number" inputMode="decimal" value={rate}
              onChange={(e) => setRate(e.target.value)}
              className="input-field pr-8" min="0.1" max="30" step="0.5" />
            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-neutral-400 text-sm">%</span>
          </div>
          <p className="text-xs text-neutral-400 mt-1">Histórico S&P 500: ~7% anual real</p>
        </div>
        <div>
          <label className="input-label">Plazo de inversión (años)</label>
          <select value={years} onChange={(e) => setYears(e.target.value)} className="input-field">
            {[1, 2, 3, 5, 10, 15, 20, 25, 30, 40].map((y) => (
              <option key={y} value={y}>{y} {y === 1 ? "año" : "años"}</option>
            ))}
          </select>
        </div>
      </div>

      {results ? (
        <>
          <div className="grid grid-cols-3 gap-3 mb-5">
            <div className="result-box text-center">
              <p className="result-label text-xs">Capital final</p>
              <p className="text-xl sm:text-2xl font-bold text-brand-700 tabular-nums">
                {formatCurrency(results.total)}
              </p>
            </div>
            <div className="bg-gradient-to-br from-neutral-50 to-slate-50 border border-neutral-200 rounded-2xl p-4 text-center">
              <p className="text-xs font-medium text-neutral-500">Total invertido</p>
              <p className="text-xl sm:text-2xl font-bold text-neutral-700 tabular-nums">
                {formatCurrency(results.totalInvested)}
              </p>
            </div>
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200 rounded-2xl p-4 text-center">
              <p className="text-xs font-medium text-green-500">Beneficio</p>
              <p className="text-xl sm:text-2xl font-bold text-green-700 tabular-nums">
                {formatCurrency(results.totalInterest)}
              </p>
            </div>
          </div>

          {/* Progress bar */}
          <div className="bg-neutral-50 rounded-xl p-4 mb-5">
            <div className="flex justify-between text-xs font-semibold mb-2">
              <span className="text-neutral-600">Invertido: {formatCurrency(results.totalInvested)}</span>
              <span className="text-green-600">Beneficio: {formatCurrency(results.totalInterest)}</span>
            </div>
            <div className="h-4 bg-neutral-200 rounded-full overflow-hidden flex">
              <div
                className="bg-brand-500 h-full transition-all duration-700"
                style={{ width: `${(results.totalInvested / results.total) * 100}%` }}
              />
              <div
                className="bg-green-400 h-full"
                style={{ width: `${(results.totalInterest / results.total) * 100}%` }}
              />
            </div>
            <p className="text-xs text-neutral-500 mt-2 text-center">
              El interés compuesto genera un{" "}
              <span className="font-bold text-green-600">
                {formatNumber((results.totalInterest / results.totalInvested) * 100, 0)}%
              </span>{" "}
              de rentabilidad sobre lo invertido
            </p>
          </div>

          {/* Mini chart (CSS only) */}
          <div className="card p-4">
            <p className="text-xs font-semibold text-neutral-500 mb-3 uppercase tracking-wide">Evolución del capital</p>
            <div className="flex items-end gap-1 h-24">
              {results.yearlyData
                .filter((_, i) => i % Math.max(1, Math.floor(results.yearlyData.length / 12)) === 0)
                .map((d, i, arr) => {
                  const maxVal = arr[arr.length - 1].value;
                  const heightPct = (d.value / maxVal) * 100;
                  const investedPct = (d.invested / maxVal) * 100;
                  return (
                    <div key={d.year} className="flex-1 flex flex-col items-center justify-end gap-px group">
                      <div className="w-full flex flex-col justify-end" style={{ height: `${heightPct}%` }}>
                        <div
                          className="w-full bg-green-400 rounded-t-sm"
                          style={{ height: `${((d.value - d.invested) / d.value) * 100}%` }}
                        />
                        <div
                          className="w-full bg-brand-500"
                          style={{ height: `${(d.invested / d.value) * 100}%` }}
                        />
                      </div>
                      <span className="text-xs text-neutral-400 mt-1">{d.year}a</span>
                    </div>
                  );
                })}
            </div>
            <div className="flex gap-4 mt-2 justify-center">
              <span className="flex items-center gap-1.5 text-xs text-neutral-500">
                <span className="w-3 h-3 rounded-sm bg-brand-500 inline-block" /> Invertido
              </span>
              <span className="flex items-center gap-1.5 text-xs text-neutral-500">
                <span className="w-3 h-3 rounded-sm bg-green-400 inline-block" /> Beneficio
              </span>
            </div>
          </div>
        </>
      ) : (
        <div className="bg-neutral-50 rounded-2xl p-8 text-center">
          <p className="text-4xl mb-3">📈</p>
          <p className="text-neutral-500 text-sm">Introduce los datos para ver el poder del interés compuesto</p>
        </div>
      )}
    </div>
  );
}
