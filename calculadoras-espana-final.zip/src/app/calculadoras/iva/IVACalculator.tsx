"use client";

import { useState } from "react";
import { formatCurrency } from "@/lib/utils";

type IVAType = 21 | 10 | 4;
type Mode = "base-to-total" | "total-to-base";

export function IVACalculator() {
  const [mode, setMode] = useState<Mode>("base-to-total");
  const [amount, setAmount] = useState("");
  const [ivaType, setIvaType] = useState<IVAType>(21);

  const numAmount = parseFloat(amount.replace(",", ".")) || 0;

  const ivaAmount =
    mode === "base-to-total"
      ? numAmount * (ivaType / 100)
      : numAmount - numAmount / (1 + ivaType / 100);

  const baseAmount =
    mode === "base-to-total"
      ? numAmount
      : numAmount / (1 + ivaType / 100);

  const totalAmount =
    mode === "base-to-total"
      ? numAmount * (1 + ivaType / 100)
      : numAmount;

  const hasResult = numAmount > 0;

  return (
    <div className="card p-6">
      {/* Mode toggle */}
      <div className="flex bg-neutral-100 rounded-xl p-1 mb-6">
        <button
          onClick={() => setMode("base-to-total")}
          className={`flex-1 py-2.5 px-3 rounded-lg text-sm font-semibold transition-all ${
            mode === "base-to-total"
              ? "bg-white text-brand-700 shadow-sm"
              : "text-neutral-500 hover:text-neutral-700"
          }`}
        >
          Precio base → Con IVA
        </button>
        <button
          onClick={() => setMode("total-to-base")}
          className={`flex-1 py-2.5 px-3 rounded-lg text-sm font-semibold transition-all ${
            mode === "total-to-base"
              ? "bg-white text-brand-700 shadow-sm"
              : "text-neutral-500 hover:text-neutral-700"
          }`}
        >
          Precio con IVA → Base
        </button>
      </div>

      {/* Inputs */}
      <div className="space-y-4 mb-6">
        <div>
          <label className="input-label">
            {mode === "base-to-total"
              ? "Precio sin IVA (€)"
              : "Precio con IVA (€)"}
          </label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400 font-medium">€</span>
            <input
              type="number"
              inputMode="decimal"
              placeholder="0,00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="input-field pl-8"
              min="0"
              step="0.01"
            />
          </div>
        </div>

        <div>
          <label className="input-label">Tipo de IVA</label>
          <div className="grid grid-cols-3 gap-2">
            {([21, 10, 4] as IVAType[]).map((type) => (
              <button
                key={type}
                onClick={() => setIvaType(type)}
                className={`py-3 rounded-xl text-sm font-semibold border-2 transition-all ${
                  ivaType === type
                    ? "border-brand-500 bg-brand-50 text-brand-700"
                    : "border-neutral-200 bg-white text-neutral-600 hover:border-brand-300 hover:bg-brand-50/50"
                }`}
              >
                <span className="block text-lg font-bold">{type}%</span>
                <span className="block text-xs mt-0.5">
                  {type === 21 ? "General" : type === 10 ? "Reducido" : "Superreducido"}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Results */}
      {hasResult ? (
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-3">
            <div className="result-box">
              <p className="result-label">Precio base</p>
              <p className="result-value text-xl sm:text-2xl">
                {formatCurrency(baseAmount)}
              </p>
            </div>
            <div className="bg-gradient-to-br from-accent-50 to-orange-50 border border-accent-200 rounded-2xl p-4 text-center">
              <p className="text-xs font-medium text-accent-500 mt-0.5">Cuota IVA ({ivaType}%)</p>
              <p className="text-xl sm:text-2xl font-bold text-accent-700 tabular-nums">
                {formatCurrency(ivaAmount)}
              </p>
            </div>
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200 rounded-2xl p-4 text-center">
              <p className="text-xs font-medium text-green-500 mt-0.5">Precio total</p>
              <p className="text-xl sm:text-2xl font-bold text-green-700 tabular-nums">
                {formatCurrency(totalAmount)}
              </p>
            </div>
          </div>

          {/* Breakdown */}
          <div className="bg-neutral-50 rounded-xl p-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-neutral-500">Precio base (sin IVA)</span>
              <span className="font-semibold text-neutral-800">{formatCurrency(baseAmount)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-500">+ IVA al {ivaType}%</span>
              <span className="font-semibold text-accent-600">+ {formatCurrency(ivaAmount)}</span>
            </div>
            <div className="flex justify-between pt-2 border-t border-neutral-200">
              <span className="font-semibold text-neutral-800">Total con IVA</span>
              <span className="font-bold text-neutral-900 text-base">{formatCurrency(totalAmount)}</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-neutral-50 rounded-2xl p-8 text-center">
          <p className="text-4xl mb-3">💶</p>
          <p className="text-neutral-500 text-sm">
            Introduce un importe para ver el cálculo del IVA
          </p>
        </div>
      )}

      {/* Reset */}
      {hasResult && (
        <button
          onClick={() => setAmount("")}
          className="mt-4 w-full btn-ghost text-sm py-2"
        >
          Limpiar
        </button>
      )}
    </div>
  );
}
