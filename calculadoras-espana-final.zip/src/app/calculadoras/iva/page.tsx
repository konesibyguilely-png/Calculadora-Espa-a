import type { Metadata } from "next";
import { IVACalculator } from "./IVACalculator";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { FAQ } from "@/components/ui/FAQ";
import { AdPlaceholder, AffiliateBlock } from "@/components/ui/AdSense";
import { CalculatorCard } from "@/components/ui/CalculatorCard";
import { CALCULATORS, SITE_CONFIG } from "@/lib/config";

export const metadata: Metadata = {
  title: "Calculadora de IVA Online Gratis 2025 — España | Precio con y sin IVA",
  description:
    "Calcula el IVA de cualquier producto o servicio al instante. Tipos general 21%, reducido 10% y superreducido 4%. Precio con IVA, sin IVA y cuota exacta. Con tabla de ejemplos y guía completa para autónomos y empresas.",
  alternates: { canonical: `${SITE_CONFIG.url}/calculadoras/iva` },
  openGraph: {
    title: "Calculadora de IVA 2025 — Precio con y sin IVA en España",
    description:
      "Calcula el IVA al instante: tipos 21%, 10% y 4%. Obtén precio con IVA, sin IVA y cuota de IVA. Con guía completa.",
    url: `${SITE_CONFIG.url}/calculadoras/iva`,
    images: [{ url: "/og-image.png", width: 1200, height: 630, alt: "Calculadora de IVA 2025 — Calculadoras España" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Calculadora de IVA 2025 — España",
    description: "IVA al 21%, 10% y 4%. Calcula precio con IVA, sin IVA y cuota. Gratis y sin registro.",
    images: ["/og-image.png"],
  },
};

const FAQ_ITEMS = [
  {
    question: "¿Cuáles son los tipos de IVA en España en 2025?",
    answer:
      "En España existen tres tipos de IVA vigentes en 2025: el tipo general del 21% (aplicado a la mayoría de bienes y servicios), el tipo reducido del 10% (alimentación en general no básica, transporte de viajeros, hostelería, viviendas de protección oficial, etc.) y el tipo superreducido del 4% (pan, leche, frutas, verduras, cereales, medicamentos, libros físicos, periódicos). También existe el 0% de IVA para determinados productos de primera necesidad que se establecieron de forma temporal (aceite, pasta, etc.), aunque estos porcentajes varían por medidas gubernamentales.",
  },
  {
    question: "¿Cómo se calcula el IVA de un precio base?",
    answer:
      "Para obtener el precio con IVA a partir del precio base (sin IVA): multiplica el precio base por (1 + tipo de IVA / 100). Ejemplo: un producto de 100€ con IVA al 21% → 100 × 1,21 = 121€. La cuota de IVA (lo que va a Hacienda) es simplemente 121€ − 100€ = 21€.",
  },
  {
    question: "¿Cómo extraer el IVA de un precio que ya lo incluye?",
    answer:
      "Para obtener el precio base a partir de un precio con IVA ya incluido: divide el precio total entre (1 + tipo de IVA / 100). Ejemplo: tienes un precio de 121€ con IVA al 21% → 121 / 1,21 = 100€ de base imponible. La cuota de IVA es 121€ − 100€ = 21€. Este cálculo es esencial para autónomos y empresas que necesitan desglosar el IVA en sus facturas.",
  },
  {
    question: "¿Qué productos tienen IVA reducido del 10%?",
    answer:
      "El tipo reducido del 10% se aplica a: alimentos en general (no básicos), agua envasada, transporte de viajeros (autobús, tren, avión), hostelería y restauración, productos farmacéuticos (excepto medicamentos con receta), servicios de limpieza de hogares, entrada a espectáculos culturales y deportivos, viviendas de protección oficial, servicios de peluquería, flores y plantas ornamentales, entre otros.",
  },
  {
    question: "¿Qué productos tienen IVA superreducido del 4%?",
    answer:
      "El tipo superreducido del 4% se aplica a: pan, harinas panificables, leche (natural, certificada, pasterizada, concentrada, desnatada, esterilizada, UHT), quesos, huevos, frutas, verduras, hortalizas y cereales, aceite de oliva y semillas, pasta alimenticia, medicamentos de uso humano y productos sanitarios que no tengan otro tipo asignado, libros físicos, periódicos y revistas, y material escolar. También se aplica a vehículos para personas con discapacidad y prótesis.",
  },
  {
    question: "¿Qué operaciones están exentas de IVA en España?",
    answer:
      "Están exentos de IVA (no hay que repercutirlo ni declararlo): servicios médicos y sanitarios (médicos, hospitales, dentistas), enseñanza reglada (colegios, universidades), servicios financieros y bancarios (préstamos, depósitos, seguros), arrendamiento de vivienda para uso residencial habitual, servicios postales de Correos, y entrega de inmuebles de segunda mano (tributan por ITP, no IVA). Estar exento de IVA no significa que la actividad no tribute; simplemente no genera IVA repercutido.",
  },
  {
    question: "¿Cuándo tiene que declarar el IVA un autónomo?",
    answer:
      "Los autónomos en régimen general de IVA deben presentar el modelo 303 de forma trimestral (en enero, abril, julio y octubre) y el resumen anual modelo 390 en enero. El importe a pagar es la diferencia entre el IVA cobrado a clientes (IVA repercutido) y el IVA pagado a proveedores (IVA soportado deducible). Si el IVA soportado es mayor al repercutido, Hacienda devuelve la diferencia (o compensa en siguientes trimestres). Los autónomos en recargo de equivalencia no presentan el 303.",
  },
  {
    question: "¿Puede un autónomo deducir siempre el IVA de sus gastos?",
    answer:
      "No siempre. Para que el IVA de un gasto sea deducible, debe cumplir varias condiciones: (1) estar vinculado a la actividad económica (no a uso personal), (2) estar correctamente documentado con factura completa, (3) el gasto debe estar registrado en los libros contables, y (4) la actividad no debe estar exenta de IVA. Gastos como el alquiler del local sí es deducible al 100%, pero el coche solo se puede deducir parcialmente salvo que sea de uso exclusivo profesional.",
  },
];

const RELATED = CALCULATORS.filter((c) => ["hipoteca", "interes-compuesto"].includes(c.id));

const schema = {
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  name: "Calculadora de IVA España",
  applicationCategory: "FinanceApplication",
  operatingSystem: "Web",
  browserRequirements: "Requires JavaScript",
  inLanguage: "es",
  offers: { "@type": "Offer", price: "0", priceCurrency: "EUR", availability: "https://schema.org/InStock" },
  description:
    "Calcula el IVA de cualquier producto o servicio con los tipos vigentes en España: 21%, 10% y 4%. Precio con IVA, sin IVA y cuota exacta.",
  url: `${SITE_CONFIG.url}/calculadoras/iva`,
  author: { "@type": "Organization", name: SITE_CONFIG.name, url: SITE_CONFIG.url },
};

export default function IVAPage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Breadcrumb items={[
          { name: "Calculadoras", href: "/calculadoras" },
          { name: "Finanzas", href: "/calculadoras#finanzas" },
          { name: "Calculadora de IVA", href: "/calculadoras/iva" },
        ]} />
        <AdPlaceholder label="Publicidad — 728×90" height={90} />

        <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">

            <div className="mb-6">
              <div className="flex items-center gap-3 mb-3">
                <span className="text-4xl" aria-hidden="true">💶</span>
                <div>
                  <h1 className="text-3xl sm:text-4xl font-bold text-neutral-900">Calculadora de IVA</h1>
                  <p className="text-neutral-500 mt-0.5">España · Tipos vigentes 2025</p>
                </div>
              </div>
              <p className="text-neutral-600 leading-relaxed">
                Calcula el <strong>IVA de cualquier producto o servicio</strong> con los tipos vigentes en
                España: general (21%), reducido (10%) y superreducido (4%). Obtén el precio con IVA
                o extrae el IVA de un precio final al instante. Incluye tabla de ejemplos, errores frecuentes
                y guía para autónomos.
              </p>
            </div>

            <IVACalculator />

            {/* Fórmulas */}
            <section className="mt-8 card p-6" aria-labelledby="formulas-iva">
              <h2 id="formulas-iva" className="text-xl font-bold text-neutral-900 mb-4">
                Fórmulas para calcular el IVA
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-neutral-50 border border-neutral-200 rounded-xl p-4">
                  <p className="text-xs font-bold text-neutral-500 uppercase tracking-wide mb-2">Precio base → Con IVA</p>
                  <p className="font-mono font-bold text-neutral-900 text-sm mb-2">Precio final = Base × (1 + tipo/100)</p>
                  <p className="text-xs text-neutral-500">Ej: 100€ × 1,21 = <strong>121€</strong></p>
                  <p className="text-xs text-neutral-500 mt-1">Cuota IVA = 121€ − 100€ = <strong>21€</strong></p>
                </div>
                <div className="bg-neutral-50 border border-neutral-200 rounded-xl p-4">
                  <p className="text-xs font-bold text-neutral-500 uppercase tracking-wide mb-2">Precio con IVA → Base</p>
                  <p className="font-mono font-bold text-neutral-900 text-sm mb-2">Base = Precio final / (1 + tipo/100)</p>
                  <p className="text-xs text-neutral-500">Ej: 121€ / 1,21 = <strong>100€</strong></p>
                  <p className="text-xs text-neutral-500 mt-1">Cuota IVA = 121€ − 100€ = <strong>21€</strong></p>
                </div>
              </div>
            </section>

            {/* Qué tiene cada tipo */}
            <section className="mt-6 card p-6" aria-labelledby="tipos-iva">
              <h2 id="tipos-iva" className="text-xl font-bold text-neutral-900 mb-4">
                ¿Qué IVA se aplica a cada producto o servicio?
              </h2>
              <div className="space-y-4">
                {[
                  {
                    tipo: "21% — Tipo general",
                    color: "border-red-200 bg-red-50",
                    badge: "bg-red-100 text-red-700",
                    items: [
                      "Electrónica: ordenadores, móviles, televisores, electrodomésticos",
                      "Ropa, calzado y complementos",
                      "Vehículos: coches, motos, bicicletas",
                      "Servicios profesionales: abogados, consultores, diseñadores",
                      "Bebidas alcohólicas y tabaco",
                      "Cosméticos y productos de higiene",
                      "Servicios de telecomunicaciones (teléfono, internet)",
                      "Entradas a discotecas y clubes nocturnos",
                      "Obras de arte, antigüedades y coleccionables",
                    ],
                  },
                  {
                    tipo: "10% — Tipo reducido",
                    color: "border-amber-200 bg-amber-50",
                    badge: "bg-amber-100 text-amber-700",
                    items: [
                      "Alimentos en general no básicos (conservas, refrescos, etc.)",
                      "Agua envasada y bebidas no alcohólicas",
                      "Transporte de viajeros: AVE, bus, avión, barco",
                      "Hostelería y restauración: bares, restaurantes, hoteles",
                      "Servicios de peluquería y estética",
                      "Entrada a museos, zoológicos, parques de atracciones",
                      "Entradas a espectáculos deportivos (fútbol, tenis...)",
                      "Viviendas de protección oficial (VPO) de nueva construcción",
                      "Semillas y plantas para producción agrícola",
                    ],
                  },
                  {
                    tipo: "4% — Tipo superreducido",
                    color: "border-green-200 bg-green-50",
                    badge: "bg-green-100 text-green-700",
                    items: [
                      "Pan, harinas panificables y cereales",
                      "Leche, quesos, huevos",
                      "Frutas, verduras y hortalizas",
                      "Aceite de oliva y de semillas",
                      "Pasta alimenticia",
                      "Medicamentos de uso humano con receta",
                      "Libros físicos (no ebooks), revistas y periódicos",
                      "Material escolar: cuadernos, bolígrafos, libros de texto",
                      "Vehículos para personas con movilidad reducida",
                    ],
                  },
                ].map((group) => (
                  <div key={group.tipo} className={`rounded-xl border p-4 ${group.color}`}>
                    <p className={`inline-block px-3 py-1 rounded-full text-sm font-bold mb-3 ${group.badge}`}>{group.tipo}</p>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1">
                      {group.items.map((item) => (
                        <li key={item} className="flex items-start gap-1.5 text-xs text-neutral-700">
                          <span className="mt-0.5 flex-shrink-0">•</span>
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </section>

            {/* Tabla de ejemplos */}
            <section className="mt-6 card p-6 overflow-x-auto" aria-labelledby="tabla-ejemplos-iva">
              <h2 id="tabla-ejemplos-iva" className="text-xl font-bold text-neutral-900 mb-4">
                Ejemplos resueltos de cálculo de IVA
              </h2>
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-neutral-50">
                    <th className="text-left p-3 font-semibold text-neutral-700">Producto / Servicio</th>
                    <th className="text-center p-3 font-semibold text-neutral-700">Tipo</th>
                    <th className="text-right p-3 font-semibold text-neutral-700">Precio base</th>
                    <th className="text-right p-3 font-semibold text-neutral-700">Cuota IVA</th>
                    <th className="text-right p-3 font-semibold text-neutral-700">Precio final</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {[
                    { item: "Ordenador portátil", tipo: "21%", base: "826,45€", cuota: "173,55€", final: "1.000€" },
                    { item: "Factura de consultoría", tipo: "21%", base: "2.000€", cuota: "420€", final: "2.420€" },
                    { item: "Menú restaurante", tipo: "10%", base: "13,64€", cuota: "1,36€", final: "15€" },
                    { item: "Billete de tren AVE", tipo: "10%", base: "90,91€", cuota: "9,09€", final: "100€" },
                    { item: "Pan de molde (500g)", tipo: "4%", base: "1,92€", cuota: "0,08€", final: "2€" },
                    { item: "Medicamento receta", tipo: "4%", base: "9,62€", cuota: "0,38€", final: "10€" },
                    { item: "Suscripción Netflix", tipo: "21%", base: "14,88€", cuota: "3,12€", final: "18€" },
                    { item: "Noche de hotel (3★)", tipo: "10%", base: "81,82€", cuota: "8,18€", final: "90€" },
                  ].map((row) => (
                    <tr key={row.item} className="hover:bg-neutral-50">
                      <td className="p-3 text-neutral-800">{row.item}</td>
                      <td className="p-3 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${
                          row.tipo === "21%" ? "bg-red-100 text-red-700" :
                          row.tipo === "10%" ? "bg-amber-100 text-amber-700" :
                          "bg-green-100 text-green-700"
                        }`}>{row.tipo}</span>
                      </td>
                      <td className="p-3 text-right tabular-nums text-neutral-600">{row.base}</td>
                      <td className="p-3 text-right tabular-nums text-accent-600 font-medium">{row.cuota}</td>
                      <td className="p-3 text-right tabular-nums font-bold text-neutral-900">{row.final}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </section>

            {/* Errores frecuentes */}
            <section className="mt-6 card p-6" aria-labelledby="errores-iva">
              <h2 id="errores-iva" className="text-xl font-bold text-neutral-900 mb-4">
                Errores frecuentes con el IVA
              </h2>
              <div className="space-y-3">
                {[
                  {
                    error: "Aplicar el tipo equivocado a un producto",
                    fix: "Un restaurante aplica el 10% a las consumiciones, pero si vende alcohol para llevar, ese alcohol tributa al 21%. La clave es el contexto de la venta, no solo el producto. En caso de duda, consulta la AEAT o un asesor fiscal.",
                  },
                  {
                    error: "Confundir precio con IVA y precio sin IVA al hacer facturas",
                    fix: "En las facturas a otras empresas siempre se indica el precio BASE (sin IVA) y se detalla el IVA por separado. El IVA no es un coste para las empresas (se recupera), pero sí para los consumidores finales. Indicar un precio con IVA incluido sin especificarlo puede generar problemas legales.",
                  },
                  {
                    error: "Creer que los autónomos exentos no emiten facturas con IVA",
                    fix: "Los autónomos cuyas actividades están exentas de IVA (médicos, profesores, etc.) no incluyen IVA en sus facturas NI lo declaran. Pero los autónomos en régimen general SÍ deben incluir IVA en todas sus facturas, aunque luego lo compensen con el IVA soportado en sus gastos.",
                  },
                ].map((item) => (
                  <div key={item.error} className="bg-red-50 border border-red-100 rounded-xl p-4">
                    <p className="font-semibold text-red-800 text-sm mb-1">❌ Error: {item.error}</p>
                    <p className="text-red-700 text-sm leading-relaxed">✅ {item.fix}</p>
                  </div>
                ))}
              </div>
            </section>

            {/* IVA para autónomos */}
            <section className="mt-6 card p-6" aria-labelledby="iva-autonomos">
              <h2 id="iva-autonomos" className="text-xl font-bold text-neutral-900 mb-4">
                Guía de IVA para autónomos y empresas
              </h2>
              <div className="space-y-3 text-sm text-neutral-600 leading-relaxed">
                <p>
                  Como autónomo en régimen general, actúas como <strong>recaudador de IVA</strong> para Hacienda:
                  cobras el IVA a tus clientes (IVA repercutido) y pagas IVA en tus gastos profesionales
                  (IVA soportado). La diferencia la ingresas trimestralmente a través del <strong>modelo 303</strong>.
                </p>
                <div className="bg-brand-50 border border-brand-100 rounded-xl p-4">
                  <p className="font-semibold text-brand-800 mb-2">📋 Ejemplo modelo 303 trimestral:</p>
                  <ul className="space-y-1 text-brand-700 text-xs">
                    <li>IVA facturado a clientes (repercutido): <strong>3.000€</strong></li>
                    <li>IVA pagado en gastos deducibles (soportado): <strong>−800€</strong></li>
                    <li className="font-bold border-t border-brand-200 pt-1">A ingresar a Hacienda: <span className="text-brand-900">2.200€</span></li>
                  </ul>
                </div>
                <p>
                  Los plazos de presentación del modelo 303 son: <strong>enero</strong> (4.º trimestre),
                  <strong>abril</strong> (1.er trimestre), <strong>julio</strong> (2.º trimestre) y{" "}
                  <strong>octubre</strong> (3.er trimestre). El <strong>modelo 390</strong> (resumen anual)
                  se presenta en enero.
                </p>
              </div>
            </section>

            <div className="mt-6">
              <FAQ items={FAQ_ITEMS} title="Preguntas frecuentes sobre el IVA en España" />

            {/* Enlace interno contextual */}
            <div className="mt-6 bg-neutral-50 border border-neutral-200 rounded-2xl p-5">
              <p className="text-sm text-neutral-600">
                Si financias un local o vivienda para tu negocio, calcula los costes totales con la{" "}
                <a href="/calculadoras/hipoteca" className="text-brand-600 hover:underline font-semibold">calculadora de hipoteca</a>
                {" "}y descubre si invertir ese capital genera más rentabilidad con la{" "}
                <a href="/calculadoras/interes-compuesto" className="text-brand-600 hover:underline font-semibold">calculadora de interés compuesto</a>.
              </p>
            </div>
            </div>
          </div>

          <aside className="space-y-5">
            <AdPlaceholder label="Publicidad — 300×250" height={250} />
            <AffiliateBlock
              icon="💼"
              title="Factura con IVA en segundos"
              description="Crea facturas profesionales con IVA desglosado. Presentación del modelo 303 integrada. Prueba gratis 30 días."
              cta="Ver programa de facturación"
              href="#"
            />
            <div className="card p-5">
              <h3 className="font-semibold text-neutral-900 mb-3">Tipos de IVA en España 2025</h3>
              <div className="space-y-3">
                {[
                  {
                    tipo: "21%", label: "General",
                    color: "bg-red-100 text-red-700",
                    examples: "Electrónica, ropa, servicios profesionales",
                  },
                  {
                    tipo: "10%", label: "Reducido",
                    color: "bg-amber-100 text-amber-700",
                    examples: "Hostelería, transporte, alimentos generales",
                  },
                  {
                    tipo: "4%", label: "Superreducido",
                    color: "bg-green-100 text-green-700",
                    examples: "Pan, leche, medicamentos, libros",
                  },
                  {
                    tipo: "0%", label: "Tipo cero (temporal)",
                    color: "bg-neutral-100 text-neutral-700",
                    examples: "Según medidas del Gobierno (varía)",
                  },
                ].map((item) => (
                  <div key={item.tipo} className="flex items-start gap-2.5">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-bold flex-shrink-0 ${item.color}`}>{item.tipo}</span>
                    <div>
                      <p className="text-xs font-semibold text-neutral-700">{item.label}</p>
                      <p className="text-xs text-neutral-500">{item.examples}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="card p-5">
              <h3 className="font-semibold text-neutral-900 mb-3">Plazos modelo 303</h3>
              <div className="space-y-2 text-xs">
                {[
                  { trim: "1.er trimestre", deadline: "Hasta 20 abril" },
                  { trim: "2.º trimestre", deadline: "Hasta 20 julio" },
                  { trim: "3.er trimestre", deadline: "Hasta 20 octubre" },
                  { trim: "4.º trimestre", deadline: "Hasta 30 enero" },
                ].map((row) => (
                  <div key={row.trim} className="flex justify-between items-center">
                    <span className="text-neutral-600">{row.trim}</span>
                    <span className="font-semibold text-brand-700">{row.deadline}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="card p-5">
              <h3 className="font-semibold text-neutral-900 mb-3">Calculadoras relacionadas</h3>
              <div className="space-y-2">
                {RELATED.map((calc) => (
                  <CalculatorCard key={calc.id} icon={calc.icon} name={calc.name} description={calc.description} href={calc.href} />
                ))}
              </div>
            </div>
            <AdPlaceholder label="Publicidad — 300×600" height={300} />
          </aside>
        </div>
      </div>
    </>
  );
}
