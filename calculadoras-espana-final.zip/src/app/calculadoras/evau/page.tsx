import type { Metadata } from "next";
import { EVAUCalculator } from "./EVAUCalculator";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { FAQ } from "@/components/ui/FAQ";
import { AdPlaceholder, AffiliateBlock } from "@/components/ui/AdSense";
import { CalculatorCard } from "@/components/ui/CalculatorCard";
import { CALCULATORS, SITE_CONFIG } from "@/lib/config";

export const metadata: Metadata = {
  title: "Calculadora EVAU / Selectividad 2025 — Nota de Acceso y Admisión",
  description:
    "Calcula tu nota de acceso a la universidad (EVAU/Selectividad) con las ponderaciones reales de la fase general y específica. Incluye notas de corte orientativas por carrera.",
  alternates: { canonical: `${SITE_CONFIG.url}/calculadoras/evau` },
  openGraph: {
    title: "Calculadora EVAU/Selectividad 2025 — Nota de Acceso y Admisión",
    description:
      "Calcula tu nota de acceso y admisión a la universidad. Fase general + específica con ponderaciones reales.",
    url: `${SITE_CONFIG.url}/calculadoras/evau`,
    images: [{ url: "/og-image.png", width: 1200, height: 630, alt: "Calculadora EVAU 2025 — Calculadoras España" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Calculadora EVAU 2025 — Nota de Acceso a la Universidad",
    description: "Calcula tu nota de selectividad: fase general y específica. Ponderaciones actualizadas 2025.",
    images: ["/og-image.png"],
  },
};

const FAQ_ITEMS = [
  {
    question: "¿Cómo se calcula la nota de acceso a la universidad?",
    answer:
      "La nota de acceso se calcula como: Nota de Bachillerato × 0,6 + Suma de las materias de la Fase General. La nota de Bachillerato pondera el 60% y las cuatro materias de la fase general (Historia de España, Lengua, Idioma y materia de modalidad) aportan hasta 4 puntos (10% cada una). El máximo de la nota de acceso es 10 puntos.",
  },
  {
    question: "¿Qué es la Fase Específica de la EVAU y cómo sube la nota?",
    answer:
      "La Fase Específica es voluntaria y permite subir la nota de admisión hasta 14 puntos en total. Se examinan materias vinculadas a la carrera deseada, que ponderan 0,1 o 0,2 según la asignación de cada universidad. Solo se cuentan las dos mejores notas ponderadas. Con dos materias calificadas con 10 y ponderación 0,2, se suman 4 puntos extra a la nota de acceso.",
  },
  {
    question: "¿Cuándo se celebra la EVAU 2025 en España?",
    answer:
      "La convocatoria ordinaria de la EVAU 2025 se celebra generalmente a principios de junio (entre el 3 y el 6 de junio aproximadamente, aunque varía por comunidad autónoma). La convocatoria extraordinaria suele ser en julio. Las fechas exactas las publica cada comunidad autónoma a través de su consejería de educación.",
  },
  {
    question: "¿Cuál es la nota mínima para acceder a la universidad?",
    answer:
      "Para acceder a la universidad es necesario obtener al menos una nota de acceso de 5 puntos. Sin embargo, la mayoría de grados universitarios tienen notas de corte superiores. Grados muy demandados como Medicina (12-13 pts), Arquitectura (10-12 pts) o Derecho en universidades top (10-11 pts) requieren notas muy altas. La nota de corte varía cada año según la demanda y la oferta de plazas.",
  },
  {
    question: "¿Es la misma selectividad en todas las comunidades autónomas?",
    answer:
      "No exactamente. Aunque la estructura es común, la prueba se denomina de forma diferente según la comunidad: EVAU (Madrid, Castilla), EBAU (Cataluña, Aragón), PAU (Baleares, Canarias) o PAEG (Galicia). Los contenidos y la corrección los gestiona cada comunidad autónoma. Esto implica que el nivel de dificultad puede variar entre comunidades, aunque las notas son válidas en todo el territorio nacional.",
  },
  {
    question: "¿Qué ponderación aplica cada universidad a la Fase Específica?",
    answer:
      "Cada universidad publica anualmente su tabla de ponderaciones para la Fase Específica. La ponderación puede ser 0,1 o 0,2 según si la materia está directamente relacionada con el grado o no. Por ejemplo, Biología puede ponderar 0,2 para Medicina en una universidad y 0,1 en otra. Puedes consultar las ponderaciones exactas en el portal de acceso de cada universidad o en el simulador de la UNED.",
  },
  {
    question: "¿Puedo mejorar mi nota de la EVAU en convocatorias posteriores?",
    answer:
      "Sí. Puedes presentarte a la EVAU tantas veces como desees para mejorar la nota. Se conserva siempre la nota más alta obtenida en cada materia. Sin embargo, la nota de Bachillerato (el 60% de la nota de acceso) no se puede modificar una vez obtenido el título. La estrategia más eficaz es centrarse en mejorar las materias de la Fase Específica con mayor ponderación para el grado deseado.",
  },
];

const RELATED = CALCULATORS.filter((c) => ["bachillerato", "edad"].includes(c.id));

const schema = {
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  name: "Calculadora EVAU España 2025",
  applicationCategory: "EducationApplication",
  operatingSystem: "Web",
  browserRequirements: "Requires JavaScript",
  inLanguage: "es",
  offers: { "@type": "Offer", price: "0", priceCurrency: "EUR", availability: "https://schema.org/InStock" },
  description:
    "Calcula tu nota de acceso y admisión a la universidad con la EVAU/Selectividad española 2025. Incluye fase general y específica con ponderaciones reales.",
  url: `${SITE_CONFIG.url}/calculadoras/evau`,
  author: { "@type": "Organization", name: SITE_CONFIG.name, url: SITE_CONFIG.url },
};

export default function EVAUPage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Breadcrumb items={[
          { name: "Calculadoras", href: "/calculadoras" },
          { name: "Educación", href: "/calculadoras#educacion" },
          { name: "Calculadora EVAU", href: "/calculadoras/evau" },
        ]} />
        <AdPlaceholder label="Publicidad — 728×90" height={90} />

        <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">

            <div className="mb-6">
              <div className="flex items-center gap-3 mb-3">
                <span className="text-4xl" aria-hidden="true">🎓</span>
                <div>
                  <h1 className="text-3xl sm:text-4xl font-bold text-neutral-900">Calculadora EVAU 2025</h1>
                  <p className="text-neutral-500 mt-0.5">Selectividad · Nota de Acceso y Admisión</p>
                </div>
              </div>
              <p className="text-neutral-600 leading-relaxed">
                Calcula tu <strong>nota de acceso a la universidad</strong> (máx. 10) y tu{" "}
                <strong>nota de admisión</strong> con la Fase Específica (máx. 14).
                Compatible con EVAU, EBAU, PAU y PAEG de todas las comunidades autónomas.
                Incluye ejemplos resueltos y tabla de notas de corte orientativas.
              </p>
            </div>

            <EVAUCalculator />

            {/* Cómo se calcula */}
            <section className="mt-8 card p-6" aria-labelledby="como-calcula-evau">
              <h2 id="como-calcula-evau" className="text-xl font-bold text-neutral-900 mb-4">
                Fórmula y sistema de calificación EVAU
              </h2>
              <div className="overflow-x-auto mb-5">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-brand-50">
                      <th className="text-left p-3 font-semibold text-brand-800 rounded-tl-lg">Componente</th>
                      <th className="text-center p-3 font-semibold text-brand-800">Ponderación</th>
                      <th className="text-center p-3 font-semibold text-brand-800 rounded-tr-lg">Puntos máx.</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {[
                      { comp: "Nota media de Bachillerato", pond: "60%", max: "6 pts", bg: "" },
                      { comp: "Historia de España (Fase General)", pond: "10%", max: "1 pt", bg: "" },
                      { comp: "Lengua Castellana y Lit. II (Fase General)", pond: "10%", max: "1 pt", bg: "" },
                      { comp: "Lengua Extranjera II (Fase General)", pond: "10%", max: "1 pt", bg: "" },
                      { comp: "Materia troncal de modalidad (Fase General)", pond: "10%", max: "1 pt", bg: "" },
                      { comp: "Fase Específica (hasta 2 materias, voluntaria)", pond: "0,1 ó 0,2", max: "+4 pts", bg: "bg-green-50" },
                    ].map((row) => (
                      <tr key={row.comp} className={`hover:bg-neutral-50 ${row.bg}`}>
                        <td className="p-3 text-neutral-700">{row.comp}</td>
                        <td className="p-3 text-center font-semibold text-brand-600">{row.pond}</td>
                        <td className="p-3 text-center font-bold text-neutral-900">{row.max}</td>
                      </tr>
                    ))}
                    <tr className="bg-neutral-50 font-bold">
                      <td className="p-3 text-neutral-900">TOTAL MÁXIMO</td>
                      <td className="p-3 text-center text-neutral-900">—</td>
                      <td className="p-3 text-center text-neutral-900 text-base">14 pts</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="bg-brand-50 border border-brand-100 rounded-xl p-4 text-sm">
                <p className="font-semibold text-brand-800 mb-2">🧮 Ejemplo resuelto:</p>
                <ul className="space-y-1 text-brand-700">
                  <li>Nota Bachillerato: <strong>8,5</strong> → 8,5 × 0,6 = <strong>5,1</strong></li>
                  <li>Historia España: <strong>7,0</strong> → 7,0 × 0,1 = <strong>0,7</strong></li>
                  <li>Lengua: <strong>8,0</strong> → 8,0 × 0,1 = <strong>0,8</strong></li>
                  <li>Inglés: <strong>9,0</strong> → 9,0 × 0,1 = <strong>0,9</strong></li>
                  <li>Matemáticas (troncal): <strong>7,5</strong> → 7,5 × 0,1 = <strong>0,75</strong></li>
                  <li className="font-bold pt-1 border-t border-brand-200">
                    Nota de Acceso = 5,1 + 0,7 + 0,8 + 0,9 + 0,75 = <span className="text-brand-900 text-base">8,25 / 10</span>
                  </li>
                  <li>Fase Específica: Química 9,5 × 0,2 + Biología 9,0 × 0,1 = 1,9 + 0,9 = 2,8</li>
                  <li className="font-bold">
                    Nota de Admisión (para Medicina) = 8,25 + 2,8 = <span className="text-green-700 text-base">11,05 / 14</span>
                  </li>
                </ul>
              </div>
            </section>

            {/* Notas de corte */}
            <section className="mt-6 card p-6 overflow-x-auto" aria-labelledby="notas-corte">
              <h2 id="notas-corte" className="text-xl font-bold text-neutral-900 mb-1">
                Notas de corte orientativas 2024 (universidades públicas)
              </h2>
              <p className="text-sm text-neutral-500 mb-4">Datos de convocatoria ordinaria 2024. Las notas varían cada año según la demanda.</p>
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-neutral-50">
                    <th className="text-left p-3 font-semibold text-neutral-700">Grado</th>
                    <th className="text-left p-3 font-semibold text-neutral-700">Universidad</th>
                    <th className="text-right p-3 font-semibold text-neutral-700">Nota corte</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {[
                    { grado: "Medicina", uni: "UCM / UAM / UB", corte: "13,2–13,8" },
                    { grado: "Ingeniería Aeronáutica", uni: "UPM", corte: "12,5–13,0" },
                    { grado: "Odontología", uni: "UCM / UB", corte: "12,0–12,8" },
                    { grado: "Arquitectura", uni: "ETSAM (UPM)", corte: "11,5–12,0" },
                    { grado: "Biotecnología", uni: "UAM / UCM", corte: "11,0–12,0" },
                    { grado: "Derecho (top)", uni: "UAM / UAB", corte: "10,5–11,5" },
                    { grado: "ADE / Economía", uni: "UAM / UPF", corte: "10,0–11,0" },
                    { grado: "Psicología", uni: "UAM / UCM", corte: "9,5–10,5" },
                    { grado: "Periodismo / Comunicación", uni: "UCM / UPF", corte: "9,0–10,5" },
                    { grado: "Magisterio Ed. Primaria", uni: "Varias", corte: "8,0–9,0" },
                    { grado: "Trabajo Social", uni: "Varias", corte: "6,0–7,5" },
                    { grado: "Turismo", uni: "Varias", corte: "5,5–7,0" },
                  ].map((row) => (
                    <tr key={row.grado} className="hover:bg-neutral-50">
                      <td className="p-3 font-medium text-neutral-800">{row.grado}</td>
                      <td className="p-3 text-neutral-500 text-xs">{row.uni}</td>
                      <td className="p-3 text-right">
                        <span className={`font-bold tabular-nums ${parseFloat(row.corte) >= 12 ? "text-red-600" : parseFloat(row.corte) >= 10 ? "text-amber-600" : "text-green-600"}`}>
                          {row.corte}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <p className="text-xs text-neutral-400 mt-3">
                ⚠️ Datos orientativos. Consulta la nota oficial en la web de la universidad y en{" "}
                <a href="https://www.uned.es" target="_blank" rel="noopener noreferrer" className="text-brand-600 hover:underline">UNED</a> o el portal de acceso de tu comunidad autónoma.
              </p>
            </section>

            {/* Estrategia para subir nota */}
            <section className="mt-6 card p-6" aria-labelledby="estrategia-evau">
              <h2 id="estrategia-evau" className="text-xl font-bold text-neutral-900 mb-4">
                Cómo maximizar tu nota de admisión: estrategia práctica
              </h2>
              <div className="space-y-4 text-sm text-neutral-600">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {[
                    {
                      icon: "🎯",
                      title: "Elige bien las materias de la Fase Específica",
                      desc: "Consulta la tabla de ponderaciones de la universidad que te interesa. Una materia con ponderación 0,2 en el grado deseado aporta el doble que una con 0,1. Prioriza las materias donde tengas mejor nota Y mayor ponderación.",
                    },
                    {
                      icon: "📊",
                      title: "El Bachillerato vale el 60%",
                      desc: "Una décima de nota media en Bachillerato equivale a 0,06 puntos en la nota de acceso. Es difícil de cambiar, pero si estás en 2.º y tienes margen, cada décima cuenta. Una nota de Bachillerato de 9,0 vs 8,0 supone 0,6 puntos de diferencia.",
                    },
                    {
                      icon: "🔄",
                      title: "Puedes repetir la EVAU para subir",
                      desc: "Si no alcanzas la nota de corte, puedes repetir la EVAU en convocatorias siguientes. Solo necesitas mejorar las materias de la Fase Específica, ya que la nota de Bachillerato no varía. Se guardan las mejores notas.",
                    },
                    {
                      icon: "🏫",
                      title: "Considera universidades de otras comunidades",
                      desc: "Una misma carrera puede tener notas de corte muy diferentes según la universidad y la ciudad. Medicina en universidades de provincias pequeñas puede tener corte 0,5-1 punto menor que en Madrid o Barcelona.",
                    },
                  ].map((item) => (
                    <div key={item.title} className="bg-neutral-50 rounded-xl p-4">
                      <p className="text-xl mb-2" aria-hidden="true">{item.icon}</p>
                      <p className="font-semibold text-neutral-800 mb-1 text-xs uppercase tracking-wide">{item.title}</p>
                      <p className="text-xs text-neutral-600 leading-relaxed">{item.desc}</p>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* EVAU por CC.AA. */}
            <section className="mt-6 card p-6" aria-labelledby="ccaa-evau">
              <h2 id="ccaa-evau" className="text-xl font-bold text-neutral-900 mb-4">
                La EVAU en cada comunidad autónoma
              </h2>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-neutral-50">
                      <th className="text-left p-3 font-semibold text-neutral-700">Comunidad</th>
                      <th className="text-left p-3 font-semibold text-neutral-700">Nombre</th>
                      <th className="text-left p-3 font-semibold text-neutral-700">Convocatoria ordinaria</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {[
                      { ccaa: "Madrid, Castilla y León, Castilla-La Mancha", name: "EVAU", fecha: "Junio (días 3–6 aprox.)" },
                      { ccaa: "Cataluña, Aragón, La Rioja", name: "PAU / EBAU", fecha: "Junio (primera semana)" },
                      { ccaa: "Andalucía, Extremadura", name: "EVAU", fecha: "Junio (primera quincena)" },
                      { ccaa: "País Vasco", name: "EBAU", fecha: "Junio (segunda semana)" },
                      { ccaa: "Galicia", name: "PAEG", fecha: "Junio (segunda semana)" },
                      { ccaa: "Comunidad Valenciana", name: "PAU", fecha: "Junio (primera semana)" },
                      { ccaa: "Canarias, Baleares", name: "PAU", fecha: "Junio (primera semana)" },
                    ].map((row) => (
                      <tr key={row.ccaa} className="hover:bg-neutral-50">
                        <td className="p-3 text-neutral-700 text-xs">{row.ccaa}</td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 bg-brand-100 text-brand-700 rounded-full text-xs font-semibold">{row.name}</span>
                        </td>
                        <td className="p-3 text-neutral-500 text-xs">{row.fecha}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            {/* Errores frecuentes */}
            <section className="mt-6 card p-6" aria-labelledby="errores-evau">
              <h2 id="errores-evau" className="text-xl font-bold text-neutral-900 mb-4">
                Errores frecuentes al calcular la nota de la EVAU
              </h2>
              <div className="space-y-3">
                {[
                  {
                    error: "Confundir nota de acceso con nota de admisión",
                    fix: "La nota de acceso (máx. 10) solo incluye Bachillerato + Fase General. La nota de admisión (máx. 14) añade la Fase Específica. Para entrar en una carrera se usa la nota de ADMISIÓN, no la de acceso.",
                  },
                  {
                    error: "No conocer las ponderaciones correctas para su carrera",
                    fix: "Cada universidad publica sus ponderaciones anualmente. Una materia puede ponderar 0,2 para Medicina en la UCM y 0,1 en la UAB. Comprueba siempre las ponderaciones específicas de TU carrera en TU universidad antes de calcular.",
                  },
                  {
                    error: "Asumir que el 5 en la EVAU es suficiente para cualquier carrera",
                    fix: "El 5 solo es el mínimo para acceder a la universidad. La mayoría de grados tienen notas de corte entre 7 y 13. Siempre comprueba la nota de corte del año anterior de la carrera que te interesa.",
                  },
                  {
                    error: "Calcular mal la media de Bachillerato",
                    fix: "La nota de Bachillerato es la media ponderada por horas semanales de TODAS las asignaturas de 1.º y 2.º. No es una simple media aritmética. Usa nuestra calculadora de nota media de Bachillerato para obtener el valor exacto.",
                  },
                ].map((item) => (
                  <div key={item.error} className="bg-red-50 border border-red-100 rounded-xl p-4">
                    <p className="font-semibold text-red-800 text-sm mb-1">❌ Error: {item.error}</p>
                    <p className="text-red-700 text-sm leading-relaxed">✅ {item.fix}</p>
                  </div>
                ))}
              </div>
            </section>

            <div className="mt-6">
              <FAQ items={FAQ_ITEMS} title="Preguntas frecuentes sobre la EVAU y acceso a la universidad" />
            </div>
          </div>

          <aside className="space-y-5">
            <AdPlaceholder label="Publicidad — 300×250" height={250} />
            <AffiliateBlock
              icon="📖"
              title="Prepárate para la EVAU"
              description="Accede a los mejores recursos de preparación: exámenes anteriores, ejercicios resueltos y materiales por comunidad."
              cta="Ver recursos EVAU"
              href="#"
            />
            <div className="card p-5">
              <h3 className="font-semibold text-neutral-900 mb-3">Simulación rápida</h3>
              <div className="space-y-2 text-sm">
                <p className="text-xs text-neutral-500 mb-3">¿Cuánto necesitas en la EVAU si tu nota de Bachillerato es…?</p>
                {[
                  { bach: "9,5", needed: "0 pts", color: "text-green-600" },
                  { bach: "9,0", needed: "0,6 pts más", color: "text-green-600" },
                  { bach: "8,5", needed: "1,1 pts más", color: "text-brand-600" },
                  { bach: "8,0", needed: "1,6 pts más", color: "text-amber-600" },
                  { bach: "7,5", needed: "2,1 pts más", color: "text-amber-600" },
                  { bach: "7,0", needed: "2,6 pts más", color: "text-red-600" },
                ].map((row) => (
                  <div key={row.bach} className="flex justify-between items-center">
                    <span className="text-neutral-600">Bachillerato {row.bach}</span>
                    <span className={`font-semibold text-xs ${row.color}`}>{row.needed} en EVAU para 10</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="card p-5">
              <h3 className="font-semibold text-neutral-900 mb-3">Calculadoras relacionadas</h3>
              <div className="space-y-2">
                {RELATED.map((calc) => (
                  <CalculatorCard key={calc.id} icon={calc.icon} name={calc.name} description={calc.description} href={calc.href} />
                ))}
              </div>
            </div>
            <AdPlaceholder label="Publicidad — 300×600" height={300} />
          </aside>
        </div>
      </div>
    </>
  );
}
