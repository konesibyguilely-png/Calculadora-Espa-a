"use client";

import { useState, useMemo } from "react";
import { formatNumber } from "@/lib/utils";

interface Subject {
  name: string;
  grade: string;
  weight: number;
}

const PHASE1_SUBJECTS: Subject[] = [
  { name: "Historia de España", grade: "", weight: 0.1 },
  { name: "Lengua Castellana y Literatura II", grade: "", weight: 0.1 },
  { name: "Lengua Extranjera II", grade: "", weight: 0.1 },
  { name: "Materia troncal de modalidad", grade: "", weight: 0.1 },
];

export function EVAUCalculator() {
  const [bachNote, setBachNote] = useState("");
  const [phase1, setPhase1] = useState<Subject[]>(PHASE1_SUBJECTS);
  const [phase2Subjects, setPhase2Subjects] = useState([
    { name: "Materia optativa 1", grade: "", weight: 0.1 },
    { name: "Materia optativa 2", grade: "", weight: 0.2 },
  ]);
  const [usePhase2, setUsePhase2] = useState(false);

  const results = useMemo(() => {
    const bach = parseFloat(bachNote.replace(",", "."));
    if (isNaN(bach) || bach < 0 || bach > 10) return null;

    const validPhase1 = phase1.filter((s) => {
      const g = parseFloat(s.grade.replace(",", "."));
      return !isNaN(g) && g >= 0 && g <= 10;
    });

    if (validPhase1.length < 4) {
      const partial = bach * 0.6;
      return { acceso: partial, admisionMax: partial, needMore: true };
    }

    const phase1Sum = validPhase1.reduce((acc, s) => {
      const g = parseFloat(s.grade.replace(",", "."));
      return acc + g * s.weight;
    }, 0);

    const acceso = bach * 0.6 + phase1Sum;

    let admisionMax = acceso;
    if (usePhase2) {
      const validPhase2 = phase2Subjects.filter((s) => {
        const g = parseFloat(s.grade.replace(",", "."));
        return !isNaN(g) && g >= 0 && g <= 10;
      });
      const phase2Sum = validPhase2.reduce((acc, s) => {
        const g = parseFloat(s.grade.replace(",", "."));
        return acc + g * s.weight;
      }, 0);
      admisionMax = acceso + phase2Sum;
    }

    return { acceso: Math.min(acceso, 10), admisionMax: Math.min(admisionMax, 14), needMore: false };
  }, [bachNote, phase1, phase2Subjects, usePhase2]);

  const updatePhase1Grade = (index: number, value: string) => {
    setPhase1((prev) => prev.map((s, i) => (i === index ? { ...s, grade: value } : s)));
  };

  const updatePhase2Grade = (index: number, value: string) => {
    setPhase2Subjects((prev) => prev.map((s, i) => (i === index ? { ...s, grade: value } : s)));
  };

  const gradeColor = (note: number) => {
    if (note >= 9) return "text-green-700";
    if (note >= 7) return "text-brand-700";
    if (note >= 5) return "text-accent-700";
    return "text-red-700";
  };

  return (
    <div className="card p-6 space-y-6">
      {/* Nota de Bachillerato */}
      <div>
        <label className="input-label">Nota media de Bachillerato (0-10)</label>
        <input
          type="number"
          inputMode="decimal"
          placeholder="Ej: 8,5"
          value={bachNote}
          onChange={(e) => setBachNote(e.target.value)}
          className="input-field max-w-xs"
          min="0"
          max="10"
          step="0.01"
        />
        <p className="text-xs text-neutral-400 mt-1">Pondera al 60% en la nota de acceso</p>
      </div>

      {/* Fase General */}
      <div>
        <h3 className="font-semibold text-neutral-800 mb-1">Fase General (obligatoria)</h3>
        <p className="text-xs text-neutral-400 mb-3">Cada materia pondera al 10% (máx. 4 puntos)</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {phase1.map((subject, index) => (
            <div key={index}>
              <label className="input-label text-xs">{subject.name}</label>
              <input
                type="number"
                inputMode="decimal"
                placeholder="0-10"
                value={subject.grade}
                onChange={(e) => updatePhase1Grade(index, e.target.value)}
                className="input-field text-sm py-2.5"
                min="0"
                max="10"
                step="0.01"
              />
            </div>
          ))}
        </div>
      </div>

      {/* Fase Específica */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <input
            type="checkbox"
            id="phase2"
            checked={usePhase2}
            onChange={(e) => setUsePhase2(e.target.checked)}
            className="w-4 h-4 accent-brand-600 rounded"
          />
          <label htmlFor="phase2" className="font-semibold text-neutral-800 cursor-pointer">
            Incluir Fase Específica (voluntaria)
          </label>
        </div>
        <p className="text-xs text-neutral-400 mb-3">Las 2 mejores materias ponderan 0,1 o 0,2 según la carrera. Máximo +4 puntos.</p>
        {usePhase2 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {phase2Subjects.map((subject, index) => (
              <div key={index}>
                <label className="input-label text-xs">
                  {subject.name} — pondera {subject.weight === 0.2 ? "0,2" : "0,1"}
                </label>
                <input
                  type="number"
                  inputMode="decimal"
                  placeholder="0-10"
                  value={subject.grade}
                  onChange={(e) => updatePhase2Grade(index, e.target.value)}
                  className="input-field text-sm py-2.5"
                  min="0"
                  max="10"
                  step="0.01"
                />
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Results */}
      {results && !results.needMore && (
        <div className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="result-box text-center p-5">
              <p className="result-label text-sm">Nota de Acceso</p>
              <p className={`text-4xl font-bold tabular-nums ${gradeColor(results.acceso)}`}>
                {formatNumber(results.acceso, 3)}
              </p>
              <p className="text-xs text-neutral-500 mt-1">Máximo 10 puntos</p>
            </div>
            {usePhase2 && (
              <div className="bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200 rounded-2xl p-5 text-center">
                <p className="text-sm font-medium text-green-500">Nota de Admisión</p>
                <p className={`text-4xl font-bold tabular-nums ${gradeColor(results.admisionMax / 1.4)}`}>
                  {formatNumber(results.admisionMax, 3)}
                </p>
                <p className="text-xs text-neutral-500 mt-1">Máximo 14 puntos</p>
              </div>
            )}
          </div>

          {/* Desglose */}
          <div className="bg-neutral-50 rounded-xl p-4 text-sm space-y-1.5">
            <p className="font-semibold text-neutral-700 mb-2">Desglose del cálculo:</p>
            <div className="flex justify-between">
              <span className="text-neutral-500">Nota Bachillerato × 0,6</span>
              <span className="font-medium">{formatNumber((parseFloat(bachNote) || 0) * 0.6, 3)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-500">Fase General (máx. 4 pts)</span>
              <span className="font-medium">{formatNumber(results.acceso - (parseFloat(bachNote) || 0) * 0.6, 3)}</span>
            </div>
            {usePhase2 && (
              <div className="flex justify-between">
                <span className="text-neutral-500">Fase Específica (máx. 4 pts)</span>
                <span className="font-medium text-green-600">+{formatNumber(results.admisionMax - results.acceso, 3)}</span>
              </div>
            )}
            <div className="flex justify-between font-bold pt-2 border-t border-neutral-200 text-base">
              <span>Nota {usePhase2 ? "Admisión" : "Acceso"}</span>
              <span className="text-brand-700">
                {formatNumber(usePhase2 ? results.admisionMax : results.acceso, 3)}
              </span>
            </div>
          </div>
        </div>
      )}

      {results?.needMore && bachNote && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-700">
          Introduce las 4 notas de la Fase General para calcular tu nota de acceso.
        </div>
      )}

      {!bachNote && (
        <div className="bg-neutral-50 rounded-2xl p-8 text-center">
          <p className="text-4xl mb-3">🎓</p>
          <p className="text-neutral-500 text-sm">Introduce tu nota de Bachillerato para empezar</p>
        </div>
      )}
    </div>
  );
}
