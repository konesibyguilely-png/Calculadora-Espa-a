import type { Metadata } from "next";
import Link from "next/link";
import { CALCULATORS } from "@/lib/config";

export const metadata: Metadata = {
  title: "Página no encontrada (404)",
  description: "Lo sentimos, la página que buscas no existe. Encuentra la calculadora que necesitas en Calculadoras España.",
  robots: {
    index: false,
    follow: true,
  },
};

export default function NotFound() {
  const popular = CALCULATORS.filter((c) => c.popular).slice(0, 4);

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4">
      <div className="text-center max-w-lg">
        <p className="text-8xl font-bold gradient-text mb-4" aria-hidden="true">404</p>
        <h1 className="text-2xl font-bold text-neutral-900 mb-3">
          Página no encontrada
        </h1>
        <p className="text-neutral-500 mb-8">
          Lo sentimos, la página que buscas no existe o ha sido movida.
          Prueba a buscar la calculadora que necesitas.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 justify-center mb-10">
          <Link href="/" className="btn-primary">
            Ir al inicio
          </Link>
          <Link href="/calculadoras" className="btn-secondary">
            Ver todas las calculadoras
          </Link>
        </div>

        <nav aria-label="Calculadoras populares">
          <p className="text-sm font-semibold text-neutral-400 mb-4 uppercase tracking-wide">
            Calculadoras populares
          </p>
          <div className="grid grid-cols-2 gap-2">
            {popular.map((calc) => (
              <Link
                key={calc.id}
                href={calc.href}
                className="flex items-center gap-2 p-3 bg-white border border-neutral-200 hover:border-brand-300 hover:bg-brand-50 rounded-xl text-sm font-medium text-neutral-700 hover:text-brand-700 transition-all"
              >
                <span aria-hidden="true">{calc.icon}</span>
                <span className="truncate">
                  {calc.name.replace("Calculadora de ", "").replace("Calculadora ", "")}
                </span>
              </Link>
            ))}
          </div>
        </nav>
      </div>
    </div>
  );
}
