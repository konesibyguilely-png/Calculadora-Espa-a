import type { Metadata } from "next";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { ContactForm } from "./ContactForm";
import { SITE_CONFIG } from "@/lib/config";

export const metadata: Metadata = {
  title: "Contacto — Calculadoras España",
  description: "Contacta con el equipo de Calculadoras España. Sugerencias, errores o colaboraciones.",
  openGraph: {
    title: "Contacto — Calculadoras España",
    description: "Contacta con el equipo de Calculadoras España para sugerencias, errores o consultas.",
    url: `${SITE_CONFIG.url}/contacto`,
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "Contacto — Calculadoras España",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Contacto — Calculadoras España",
    description: "Contacta con el equipo de Calculadoras España para sugerencias, errores o consultas.",
    images: ["/og-image.png"],
  },
  alternates: { canonical: `${SITE_CONFIG.url}/contacto` },
};


const schema = {
  "@context": "https://schema.org",
  "@type": "ContactPage",
  name: "Contacto — Calculadoras España",
  url: `${SITE_CONFIG.url}/contacto`,
  description: "Página de contacto de Calculadoras España. Sugerencias, errores o colaboraciones.",
  inLanguage: "es",
  mainEntity: {
    "@type": "Organization",
    name: SITE_CONFIG.name,
    url: SITE_CONFIG.url,
    email: SITE_CONFIG.email,
    contactPoint: {
      "@type": "ContactPoint",
      contactType: "customer support",
      email: SITE_CONFIG.email,
      availableLanguage: "Spanish",
    },
  },
};

export default function ContactoPage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Breadcrumb items={[{ name: "Contacto", href: "/contacto" }]} />

      <div className="mt-6 grid grid-cols-1 lg:grid-cols-5 gap-8">
        {/* Info */}
        <div className="lg:col-span-2 space-y-6">
          <div>
            <h1 className="text-3xl font-bold text-neutral-900 mb-3">Contacto</h1>
            <p className="text-neutral-600 leading-relaxed">
              ¿Tienes alguna sugerencia, has encontrado un error en una calculadora, o quieres
              proponer una nueva? Nos encanta recibir feedback de nuestros usuarios.
            </p>
          </div>

          <div className="space-y-4">
            {[
              {
                icon: "📧",
                title: "Email",
                value: SITE_CONFIG.email,
                href: `mailto:${SITE_CONFIG.email}`,
              },
              {
                icon: "⏱️",
                title: "Tiempo de respuesta",
                value: "24-48 horas laborables",
                href: null,
              },
              {
                icon: "🌍",
                title: "Idioma",
                value: "Español",
                href: null,
              },
            ].map((item) => (
              <div key={item.title} className="flex items-start gap-3 card p-4">
                <span className="text-2xl">{item.icon}</span>
                <div>
                  <p className="text-xs text-neutral-400 font-medium uppercase tracking-wide">{item.title}</p>
                  {item.href ? (
                    <a href={item.href} className="font-semibold text-brand-600 hover:underline">
                      {item.value}
                    </a>
                  ) : (
                    <p className="font-semibold text-neutral-800">{item.value}</p>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="card p-5">
            <h3 className="font-semibold text-neutral-900 mb-3">¿En qué podemos ayudarte?</h3>
            <ul className="space-y-2 text-sm text-neutral-600">
              {[
                "🐛 Reportar un error en una calculadora",
                "💡 Sugerir una nueva calculadora",
                "🤝 Propuestas de colaboración o patrocinio",
                "📢 Consultas sobre publicidad (AdSense)",
                "⚖️ Consultas legales o de privacidad",
                "✏️ Correcciones de contenido",
              ].map((item) => (
                <li key={item} className="flex items-center gap-2">
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Form */}
        <div className="lg:col-span-3">
          <div className="card p-6 sm:p-8">
            <h2 className="text-xl font-bold text-neutral-900 mb-6">Envíanos un mensaje</h2>
            <ContactForm />
          </div>
        </div>
      </div>
    </div>
    </>
  );
}
