"use client";

import { useState, useId } from "react";

type Status = "idle" | "sending" | "success" | "error";

const SUBJECTS = [
  "Error en una calculadora",
  "Sugerencia de nueva calculadora",
  "Propuesta de colaboración",
  "Consulta sobre publicidad",
  "Consulta legal o privacidad",
  "Corrección de contenido",
  "Otro",
];

export function ContactForm() {
  const id = useId();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState<Status>("idle");
  const [errors, setErrors] = useState<Record<string, string>>({});

  function validate() {
    const errs: Record<string, string> = {};
    if (!name.trim()) errs.name = "El nombre es obligatorio.";
    if (!email.trim()) errs.email = "El email es obligatorio.";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errs.email = "Introduce un email válido.";
    if (!message.trim()) errs.message = "El mensaje es obligatorio.";
    else if (message.trim().length < 10) errs.message = "El mensaje debe tener al menos 10 caracteres.";
    return errs;
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    setErrors({});
    setStatus("sending");

    // TODO: connect to real backend (Resend, Formspree, API route, etc.)
    await new Promise((resolve) => setTimeout(resolve, 1200));
    setStatus("success");
    setName(""); setEmail(""); setSubject(""); setMessage("");
  };

  if (status === "success") {
    return (
      <div className="text-center py-10" role="status" aria-live="polite">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4" aria-hidden="true">
          <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h3 className="text-xl font-bold text-neutral-900 mb-2">¡Mensaje enviado!</h3>
        <p className="text-neutral-500 mb-6">
          Gracias por contactarnos. Te responderemos en un plazo de 24-48 horas laborables.
        </p>
        <button onClick={() => setStatus("idle")} className="btn-secondary text-sm">
          Enviar otro mensaje
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5" noValidate aria-label="Formulario de contacto">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="input-label" htmlFor={`${id}-name`}>
            Nombre <span className="text-red-500" aria-hidden="true">*</span>
            <span className="sr-only">(obligatorio)</span>
          </label>
          <input
            id={`${id}-name`}
            type="text"
            autoComplete="name"
            placeholder="Tu nombre"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            aria-required="true"
            aria-describedby={errors.name ? `${id}-name-error` : undefined}
            aria-invalid={!!errors.name}
            className={`input-field ${errors.name ? "border-red-400 focus:ring-red-400" : ""}`}
          />
          {errors.name && (
            <p id={`${id}-name-error`} className="text-xs text-red-600 mt-1" role="alert">{errors.name}</p>
          )}
        </div>

        <div>
          <label className="input-label" htmlFor={`${id}-email`}>
            Email <span className="text-red-500" aria-hidden="true">*</span>
            <span className="sr-only">(obligatorio)</span>
          </label>
          <input
            id={`${id}-email`}
            type="email"
            autoComplete="email"
            placeholder="tu@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            aria-required="true"
            aria-describedby={errors.email ? `${id}-email-error` : undefined}
            aria-invalid={!!errors.email}
            className={`input-field ${errors.email ? "border-red-400 focus:ring-red-400" : ""}`}
          />
          {errors.email && (
            <p id={`${id}-email-error`} className="text-xs text-red-600 mt-1" role="alert">{errors.email}</p>
          )}
        </div>
      </div>

      <div>
        <label className="input-label" htmlFor={`${id}-subject`}>Asunto</label>
        <select
          id={`${id}-subject`}
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          className="input-field"
        >
          <option value="">Selecciona un asunto...</option>
          {SUBJECTS.map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
      </div>

      <div>
        <label className="input-label" htmlFor={`${id}-message`}>
          Mensaje <span className="text-red-500" aria-hidden="true">*</span>
          <span className="sr-only">(obligatorio)</span>
        </label>
        <textarea
          id={`${id}-message`}
          placeholder="Describe tu consulta con el mayor detalle posible..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          required
          aria-required="true"
          aria-describedby={errors.message ? `${id}-message-error` : `${id}-message-hint`}
          aria-invalid={!!errors.message}
          rows={5}
          maxLength={500}
          className={`input-field resize-none ${errors.message ? "border-red-400 focus:ring-red-400" : ""}`}
        />
        <p id={`${id}-message-hint`} className="text-xs text-neutral-400 mt-1">
          {message.length}/500 caracteres
        </p>
        {errors.message && (
          <p id={`${id}-message-error`} className="text-xs text-red-600 mt-1" role="alert">{errors.message}</p>
        )}
      </div>

      <div className="flex items-start gap-2.5">
        <input
          type="checkbox"
          id={`${id}-privacy`}
          required
          aria-required="true"
          className="w-4 h-4 mt-0.5 accent-brand-600 rounded flex-shrink-0"
        />
        <label htmlFor={`${id}-privacy`} className="text-sm text-neutral-600 cursor-pointer">
          He leído y acepto la{" "}
          <a href="/legal/privacidad" className="text-brand-600 hover:underline">
            Política de Privacidad
          </a>{" "}
          y el tratamiento de mis datos para responder a mi consulta.
        </label>
      </div>

      {status === "error" && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-700" role="alert">
          Ha ocurrido un error al enviar el mensaje. Por favor, inténtalo de nuevo o escríbenos
          directamente a <a href="mailto:contacto@calculadoras-espana.es" className="underline">contacto@calculadoras-espana.es</a>.
        </div>
      )}

      <button
        type="submit"
        disabled={status === "sending"}
        className="btn-primary w-full disabled:opacity-50 disabled:cursor-not-allowed"
        aria-busy={status === "sending"}
      >
        {status === "sending" ? (
          <span className="flex items-center gap-2">
            <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24" aria-hidden="true">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
            </svg>
            Enviando...
          </span>
        ) : (
          <span className="flex items-center gap-2">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
            </svg>
            Enviar mensaje
          </span>
        )}
      </button>
    </form>
  );
}
