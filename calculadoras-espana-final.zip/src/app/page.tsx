import type { Metadata } from "next";
import Link from "next/link";
import { CalculatorCard } from "@/components/ui/CalculatorCard";
import { FAQ } from "@/components/ui/FAQ";
import { AdPlaceholder } from "@/components/ui/AdSense";
import { CALCULATORS, CATEGORIES, SITE_CONFIG } from "@/lib/config";

const OG_IMAGE = {
  url: "/og-image.png",
  width: 1200,
  height: 630,
  alt: "Calculadoras España — Calculadoras gratuitas online en español",
};

export const metadata: Metadata = {
  title: "Calculadoras España — Calculadoras Gratis Online en Español",
  description:
    "Más de 8 calculadoras gratuitas: IVA, hipoteca, IMC, EVAU, interés compuesto, edad y más. Resultados instantáneos, sin registro. La mejor plataforma de calculadoras en España.",
  alternates: { canonical: `${SITE_CONFIG.url}/` },
  openGraph: {
    title: "Calculadoras España — Calculadoras Gratis Online en Español",
    description:
      "Más de 8 calculadoras gratuitas: IVA, hipoteca, IMC, EVAU, interés compuesto y más.",
    url: `${SITE_CONFIG.url}/`,
    images: [OG_IMAGE],
  },
  twitter: {
    card: "summary_large_image",
    title: "Calculadoras España — Calculadoras Gratis Online en Español",
    description: "Más de 8 calculadoras gratuitas en español. Resultados instantáneos.",
    images: ["/og-image.png"],
  },
};

const HOME_FAQS = [
  {
    question: "¿Son gratuitas todas las calculadoras?",
    answer:
      "Sí, todas las calculadoras de Calculadoras España son completamente gratuitas y no requieren registro. Puedes usarlas tantas veces como necesites sin ningún coste.",
  },
  {
    question: "¿Son precisos los resultados de las calculadoras?",
    answer:
      "Nuestras calculadoras utilizan las fórmulas matemáticas y financieras estándar actualizadas. Sin embargo, los resultados son orientativos. Para decisiones financieras o médicas importantes, siempre consulta con un profesional cualificado.",
  },
  {
    question: "¿Guardan mis datos personales?",
    answer:
      "No. Todos los cálculos se realizan directamente en tu navegador. No almacenamos ningún dato que introduzcas en las calculadoras en nuestros servidores.",
  },
  {
    question: "¿Están adaptadas a la normativa española?",
    answer:
      "Sí. Las calculadoras fiscales y financieras utilizan los tipos impositivos y normativas vigentes en España, como los tipos de IVA (21%, 10%, 4%) o las tablas del IRPF.",
  },
  {
    question: "¿Puedo usar las calculadoras desde el móvil?",
    answer:
      "Por supuesto. Todas nuestras calculadoras están diseñadas para funcionar perfectamente en smartphones, tablets y ordenadores de escritorio.",
  },
];

export default function HomePage() {
  const featuredCalcs = CALCULATORS.filter((c) => c.featured);
  const popularCalcs = CALCULATORS.filter((c) => c.popular);

  const websiteSchema = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name: "Calculadoras España — Todas las calculadoras",
    description: "Listado completo de calculadoras gratuitas en español",
    itemListElement: CALCULATORS.map((calc, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: calc.name,
      url: `${SITE_CONFIG.url}${calc.href}`,
    })),
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteSchema) }}
      />

      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-b from-brand-950 via-brand-900 to-brand-800 pt-16 pb-20">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-32 -right-32 w-96 h-96 bg-brand-500/10 rounded-full blur-3xl" />
          <div className="absolute top-1/2 -left-20 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-1/3 w-64 h-64 bg-accent-500/5 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-brand-500/20 border border-brand-400/30 rounded-full text-brand-200 text-xs font-semibold mb-6 backdrop-blur-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
            {CALCULATORS.length}+ calculadoras gratuitas
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-5 text-balance leading-[1.1]">
            Calculadoras{" "}
            <span className="bg-gradient-to-r from-brand-300 to-blue-300 bg-clip-text text-transparent">
              gratuitas
            </span>{" "}
            en español
          </h1>

          <p className="text-lg sm:text-xl text-brand-200/80 max-w-2xl mx-auto mb-8 leading-relaxed text-balance">
            IVA, hipotecas, IMC, EVAU, interés compuesto y mucho más.
            Resultados instantáneos y precisos, sin registro.
          </p>

          <form action="/calculadoras" method="get" role="search" aria-label="Buscar calculadora" className="max-w-xl mx-auto relative mb-10">
            <label htmlFor="hero-search" className="sr-only">Buscar calculadora</label>
            <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              id="hero-search"
              type="search"
              name="q"
              placeholder="Busca una calculadora: IVA, hipoteca, IMC..."
              className="w-full pl-12 pr-5 py-4 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20 text-white placeholder-white/40 text-base focus:outline-none focus:ring-2 focus:ring-brand-400 focus:bg-white/15 transition-all"
              autoComplete="off"
            />
          </form>

          <div className="flex flex-wrap items-center justify-center gap-2" role="list" aria-label="Calculadoras populares">
            {popularCalcs.slice(0, 5).map((calc) => (
              <Link
                key={calc.id}
                href={calc.href}
                role="listitem"
                className="flex items-center gap-1.5 px-3.5 py-1.5 bg-white/10 hover:bg-white/20 border border-white/20 rounded-full text-sm text-white/80 hover:text-white transition-all backdrop-blur-sm"
              >
                <span aria-hidden="true">{calc.icon}</span>
                {calc.name.replace("Calculadora ", "").replace("de ", "")}
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Trust strip */}
      <section className="bg-white border-b border-neutral-200 py-4" aria-label="Características">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center justify-center gap-x-8 gap-y-3">
            {[
              { icon: "✅", text: "100% gratuito" },
              { icon: "🔒", text: "Sin registro" },
              { icon: "⚡", text: "Resultados instantáneos" },
              { icon: "📱", text: "Funciona en móvil" },
              { icon: "🇪🇸", text: "Adaptado a España" },
            ].map((item) => (
              <div key={item.text} className="flex items-center gap-1.5 text-sm font-medium text-neutral-600">
                <span aria-hidden="true">{item.icon}</span>
                {item.text}
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AdPlaceholder label="Publicidad — 728×90" height={90} />

        {/* Featured calculators */}
        <section className="py-10" aria-labelledby="destacadas-heading">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 id="destacadas-heading" className="section-title">Calculadoras destacadas</h2>
              <p className="section-subtitle">Las herramientas más usadas por los españoles</p>
            </div>
            <Link href="/calculadoras" className="text-sm font-semibold text-brand-600 hover:text-brand-700 hidden sm:block">
              Ver todas →
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {featuredCalcs.map((calc) => (
              <CalculatorCard key={calc.id} icon={calc.icon} name={calc.name} description={calc.description} href={calc.href} featured={calc.featured} popular={calc.popular} />
            ))}
          </div>
        </section>

        <AdPlaceholder label="Publicidad — 970×250" height={120} />

        {/* By category */}
        {CATEGORIES.map((category) => {
          const calcs = CALCULATORS.filter((c) => c.category === category.id);
          if (calcs.length === 0) return null;
          return (
            <section key={category.id} id={category.id} className="py-8 scroll-mt-20" aria-labelledby={`cat-${category.id}`}>
              <div className="flex items-center gap-3 mb-5">
                <span className="text-3xl" aria-hidden="true">{category.icon}</span>
                <div>
                  <h2 id={`cat-${category.id}`} className="text-xl font-bold text-neutral-900">{category.name}</h2>
                  <p className="text-sm text-neutral-500">{category.description}</p>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {calcs.map((calc) => (
                  <CalculatorCard key={calc.id} icon={calc.icon} name={calc.name} description={calc.description} href={calc.href} featured={calc.featured} popular={calc.popular} />
                ))}
              </div>
            </section>
          );
        })}

        {/* Why us */}
        <section className="py-12 border-t border-neutral-200" aria-labelledby="why-heading">
          <div className="text-center mb-8">
            <h2 id="why-heading" className="section-title">¿Por qué elegir Calculadoras España?</h2>
            <p className="section-subtitle max-w-2xl mx-auto">Más de miles de usuarios confían en nuestras herramientas cada mes</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {[
              { icon: "⚡", title: "Resultados instantáneos", desc: "Los cálculos se actualizan en tiempo real según introduces los datos. No hay que pulsar ningún botón." },
              { icon: "🧮", title: "Fórmulas verificadas", desc: "Todas nuestras calculadoras usan fórmulas matemáticas y financieras estándar, revisadas y actualizadas." },
              { icon: "🇪🇸", title: "Adaptadas a España", desc: "IVA, IRPF, tipos hipotecarios, notas EVAU... todo ajustado a la normativa y sistema español." },
              { icon: "📱", title: "Diseño responsive", desc: "Funcionan perfectamente en cualquier dispositivo: móvil, tablet u ordenador de sobremesa." },
              { icon: "🔒", title: "Privacidad total", desc: "Los cálculos se hacen en tu navegador. No enviamos ni almacenamos los datos que introduces." },
              { icon: "🎓", title: "Explicaciones claras", desc: "Cada calculadora incluye la fórmula, explicación paso a paso y ejemplos prácticos." },
            ].map((item) => (
              <div key={item.title} className="card p-5">
                <div className="text-3xl mb-3" aria-hidden="true">{item.icon}</div>
                <h3 className="font-semibold text-neutral-900 mb-1.5">{item.title}</h3>
                <p className="text-sm text-neutral-500 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </section>

        <div className="pb-12">
          <FAQ items={HOME_FAQS} title="Preguntas frecuentes sobre Calculadoras España" />
        </div>

        <AdPlaceholder label="Publicidad — 728×90" height={90} />
      </div>
    </>
  );
}
