import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { SITE_CONFIG } from "@/lib/config";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(SITE_CONFIG.url),
  title: {
    default: `${SITE_CONFIG.name} — Calculadoras Gratis en Español`,
    template: `%s | ${SITE_CONFIG.name}`,
  },
  description: SITE_CONFIG.description,
  authors: [{ name: SITE_CONFIG.author, url: SITE_CONFIG.url }],
  creator: SITE_CONFIG.author,
  publisher: SITE_CONFIG.author,
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  // NOTE: No openGraph or twitter here at the root level.
  // Every page defines its own complete openGraph+twitter block to avoid
  // Next.js's shallow-merge behavior dropping images on child pages.
  // (If a child page sets openGraph:{title, desc, url} without images,
  //  Next replaces the parent's openGraph entirely, losing og:image.)
  //
  // NOTE: No alternates.canonical here either.
  // Each page sets its own canonical. A root-level canonical would
  // propagate to pages that don't override it, making them self-identify
  // as the homepage — a critical duplicate-content signal for Google.
  //
  // NOTE: verification.google must be updated with the real GSC code
  // before going live. Leaving the placeholder here means the GSC
  // meta tag IS emitted but contains a non-functional value.
  // Replace "REPLACE_WITH_REAL_CODE" with your actual verification string.
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const websiteSchema = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: SITE_CONFIG.name,
    url: SITE_CONFIG.url,
    description: SITE_CONFIG.description,
    inLanguage: "es",
    // SearchAction: search URL must point to a real search results page.
    // The current site has no dedicated /calculadoras?q= results page,
    // so we omit SearchAction to avoid invalid structured data errors.
    // Add it back when a functional search results page is implemented.
    publisher: {
      "@type": "Organization",
      name: SITE_CONFIG.name,
      url: SITE_CONFIG.url,
      logo: {
        "@type": "ImageObject",
        url: `${SITE_CONFIG.url}/logo.png`,
        width: 512,
        height: 512,
      },
    },
  };

  return (
    <html lang="es" className={inter.variable}>
      <head>
        {/* Google AdSense — replace SITE_CONFIG.adsenseId with real Publisher ID */}
        <script
          async
          src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${SITE_CONFIG.adsenseId}`}
          crossOrigin="anonymous"
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteSchema) }}
        />
        <link rel="icon" href="/favicon.ico" sizes="32x32" />
        <link rel="icon" href="/icon.svg" type="image/svg+xml" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <link rel="manifest" href="/manifest.webmanifest" />
        <meta name="theme-color" content="#3366ff" />
        {/* Preconnect to AdSense CDN to reduce first ad render latency */}
        <link rel="preconnect" href="https://pagead2.googlesyndication.com" />
        <link rel="preconnect" href="https://googleads.g.doubleclick.net" />
      </head>
      <body className="min-h-screen flex flex-col antialiased">
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:px-4 focus:py-2 focus:bg-brand-600 focus:text-white focus:rounded-lg focus:font-semibold"
        >
          Saltar al contenido principal
        </a>
        <Header />
        <main id="main-content" className="flex-1">
          {children}
        </main>
        <Footer />
      </body>
    </html>
  );
}
