import { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Calculadoras España",
    short_name: "CalcES",
    description: "Las mejores calculadoras gratuitas en español: IVA, hipoteca, IMC, EVAU y más.",
    start_url: "/",
    display: "standalone",
    background_color: "#f8fafc",
    theme_color: "#3366ff",
    icons: [
      {
        src: "/icon-192.png",
        sizes: "192x192",
        type: "image/png",
      },
      {
        src: "/icon-512.png",
        sizes: "512x512",
        type: "image/png",
      },
      {
        src: "/icon.svg",
        sizes: "any",
        type: "image/svg+xml",
      },
    ],
  };
}
