import type { Metadata } from "next";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { SITE_CONFIG } from "@/lib/config";

export const metadata: Metadata = {
  title: "Política de Privacidad — Calculadoras España",
  description: "Política de privacidad conforme al RGPD. Información sobre el tratamiento de datos personales.",
  openGraph: {
    title: "Política de Privacidad — Calculadoras España",
    description: "Política de privacidad de Calculadoras España conforme al RGPD. Información sobre tratamiento de datos personales.",
    url: `${SITE_CONFIG.url}/legal/privacidad`,
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "Política de Privacidad — Calculadoras España",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Política de Privacidad — Calculadoras España",
    description: "Política de privacidad de Calculadoras España conforme al RGPD. Información sobre tratamiento de datos personales.",
    images: ["/og-image.png"],
  },
  alternates: { canonical: `${SITE_CONFIG.url}/legal/privacidad` },
};

export default function PrivacidadPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Breadcrumb items={[{ name: "Legal", href: "/legal/privacidad" }, { name: "Política de Privacidad", href: "/legal/privacidad" }]} />
      <div className="mt-6 card p-8">
        <h1 className="text-3xl font-bold text-neutral-900 mb-2">Política de Privacidad</h1>
        <p className="text-sm text-neutral-400 mb-8">Última actualización: 1 de enero de 2025</p>
        <div className="space-y-8 text-neutral-600 leading-relaxed">

          <section>
            <h2 className="text-xl font-bold text-neutral-900 mb-3">1. Responsable del tratamiento</h2>
            <p>El responsable del tratamiento es <strong>{SITE_CONFIG.name}</strong>, contacto: <strong>{SITE_CONFIG.email}</strong>.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-neutral-900 mb-3">2. Datos que recopilamos</h2>
            <ul className="list-disc list-inside space-y-2">
              <li><strong>Datos de calculadoras:</strong> Los valores introducidos se procesan únicamente en tu navegador. No se transmiten a nuestros servidores.</li>
              <li><strong>Datos analíticos:</strong> Datos anónimos de uso mediante cookies analíticas para mejorar el servicio.</li>
              <li><strong>Formulario de contacto:</strong> Nombre, email y mensaje, solo para responder tu consulta.</li>
              <li><strong>Publicidad:</strong> Google AdSense puede usar cookies para mostrar anuncios personalizados.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-neutral-900 mb-3">3. Base legal</h2>
            <ul className="list-disc list-inside space-y-2">
              <li><strong>Interés legítimo:</strong> Análisis anónimo del sitio web.</li>
              <li><strong>Consentimiento:</strong> Cookies no esenciales y publicidad personalizada.</li>
              <li><strong>Contrato:</strong> Respuesta a consultas de contacto.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-neutral-900 mb-3">4. Tus derechos (RGPD)</h2>
            <p className="mb-3">Tienes derecho de acceso, rectificación, supresión, oposición, portabilidad y limitación del tratamiento.</p>
            <p>Ejerce tus derechos en <strong>{SITE_CONFIG.email}</strong> o presenta reclamación ante la <a href="https://www.aepd.es" className="text-brand-600 hover:underline" target="_blank" rel="noopener noreferrer">AEPD</a>.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-neutral-900 mb-3">5. Transferencias internacionales</h2>
            <p>Google Analytics y AdSense pueden transferir datos fuera del EEE, amparadas por las cláusulas contractuales tipo de la Comisión Europea.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-neutral-900 mb-3">6. Contacto</h2>
            <p>Para consultas: <a href={`mailto:${SITE_CONFIG.email}`} className="text-brand-600 hover:underline">{SITE_CONFIG.email}</a></p>
          </section>
        </div>
      </div>
    </div>
  );
}
