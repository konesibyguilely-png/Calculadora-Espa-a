import type { Metadata } from "next";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { SITE_CONFIG } from "@/lib/config";

export const metadata: Metadata = {
  title: "Política de Cookies — Calculadoras España",
  description: "Información sobre los tipos de cookies utilizadas en Calculadoras España y cómo gestionarlas.",
  openGraph: {
    title: "Política de Cookies — Calculadoras España",
    description: "Información sobre los tipos de cookies utilizadas en Calculadoras España y cómo gestionarlas.",
    url: `${SITE_CONFIG.url}/legal/cookies`,
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "Política de Cookies — Calculadoras España",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Política de Cookies — Calculadoras España",
    description: "Información sobre los tipos de cookies utilizadas en Calculadoras España y cómo gestionarlas.",
    images: ["/og-image.png"],
  },
  alternates: { canonical: `${SITE_CONFIG.url}/legal/cookies` },
};

export default function CookiesPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Breadcrumb items={[{ name: "Legal", href: "/legal/cookies" }, { name: "Política de Cookies", href: "/legal/cookies" }]} />
      <div className="mt-6 card p-8">
        <h1 className="text-3xl font-bold text-neutral-900 mb-2">Política de Cookies</h1>
        <p className="text-sm text-neutral-400 mb-8">Última actualización: 1 de enero de 2025</p>
        <div className="space-y-8 text-neutral-600 leading-relaxed">

          <section>
            <h2 className="text-xl font-bold text-neutral-900 mb-3">¿Qué son las cookies?</h2>
            <p>Las cookies son pequeños ficheros de texto que se almacenan en tu dispositivo cuando visitas un sitio web. Conforme a la LSSI y el RGPD, te informamos sobre su uso en este sitio.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-neutral-900 mb-3">Tipos de cookies utilizadas</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm border border-neutral-200 rounded-xl overflow-hidden">
                <thead className="bg-neutral-50">
                  <tr>
                    {["Cookie", "Proveedor", "Finalidad", "Duración"].map((h) => (
                      <th key={h} className="text-left p-3 font-semibold text-neutral-700 border-b border-neutral-200">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {[
                    { name: "_ga, _ga_*", provider: "Google Analytics", purpose: "Analítica anónima de uso", duration: "2 años" },
                    { name: "IDE, DSID", provider: "Google AdSense", purpose: "Publicidad personalizada", duration: "1 año" },
                    { name: "cookieConsent", provider: "Calculadoras España", purpose: "Guarda preferencia de consentimiento", duration: "1 año" },
                  ].map((row) => (
                    <tr key={row.name} className="hover:bg-neutral-50">
                      <td className="p-3 font-mono text-xs text-neutral-700">{row.name}</td>
                      <td className="p-3 text-neutral-600">{row.provider}</td>
                      <td className="p-3 text-neutral-600">{row.purpose}</td>
                      <td className="p-3 text-neutral-600">{row.duration}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-bold text-neutral-900 mb-3">Cómo gestionar las cookies</h2>
            <p>Puedes configurar las cookies desde el banner de cookies o desde la configuración de tu navegador (Chrome, Firefox, Safari, Edge). Deshabilitar las cookies puede afectar al funcionamiento del sitio.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-neutral-900 mb-3">Más información</h2>
            <p>Consulta la <a href="https://policies.google.com/technologies/cookies" target="_blank" rel="noopener noreferrer" className="text-brand-600 hover:underline">política de cookies de Google</a>. Para dudas, contáctanos en <a href={`mailto:${SITE_CONFIG.email}`} className="text-brand-600 hover:underline">{SITE_CONFIG.email}</a>.</p>
          </section>
        </div>
      </div>
    </div>
  );
}
