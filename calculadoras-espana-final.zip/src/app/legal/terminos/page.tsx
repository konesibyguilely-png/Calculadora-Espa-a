import type { Metadata } from "next";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { SITE_CONFIG } from "@/lib/config";

export const metadata: Metadata = {
  title: "Términos y Condiciones — Calculadoras España",
  description: "Términos y condiciones de uso del servicio de Calculadoras España.",
  openGraph: {
    title: "Términos y Condiciones — Calculadoras España",
    description: "Términos y condiciones de uso del servicio de Calculadoras España.",
    url: `${SITE_CONFIG.url}/legal/terminos`,
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "Términos y Condiciones — Calculadoras España",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Términos y Condiciones — Calculadoras España",
    description: "Términos y condiciones de uso del servicio de Calculadoras España.",
    images: ["/og-image.png"],
  },
  alternates: { canonical: `${SITE_CONFIG.url}/legal/terminos` },
};

export default function TerminosPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Breadcrumb items={[{ name: "Legal", href: "/legal/terminos" }, { name: "Términos y Condiciones", href: "/legal/terminos" }]} />
      <div className="mt-6 card p-8">
        <h1 className="text-3xl font-bold text-neutral-900 mb-2">Términos y Condiciones</h1>
        <p className="text-sm text-neutral-400 mb-8">Última actualización: 1 de enero de 2025</p>
        <div className="space-y-8 text-neutral-600 leading-relaxed">

          <section>
            <h2 className="text-xl font-bold text-neutral-900 mb-3">1. Objeto y aceptación</h2>
            <p>Las presentes condiciones regulan el acceso y uso del sitio web <strong>{SITE_CONFIG.url}</strong> (en adelante, "el Sitio"), titularidad de <strong>{SITE_CONFIG.name}</strong>. El acceso al Sitio implica la aceptación plena de estos términos.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-neutral-900 mb-3">2. Descripción del servicio</h2>
            <p>Calculadoras España ofrece herramientas de cálculo online gratuitas en español (calculadoras de IVA, hipoteca, IMC, EVAU, etc.) con fines informativos y educativos. El servicio se presta de forma gratuita y sin necesidad de registro.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-neutral-900 mb-3">3. Carácter informativo y limitación de responsabilidad</h2>
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800 mb-4">
              <p className="font-semibold mb-1">⚠️ Aviso importante</p>
              <p>Los resultados de las calculadoras tienen carácter meramente orientativo e informativo. No constituyen asesoramiento financiero, fiscal, médico ni legal.</p>
            </div>
            <p>{SITE_CONFIG.name} no se hace responsable de:</p>
            <ul className="list-disc list-inside mt-2 space-y-1">
              <li>Decisiones tomadas basándose exclusivamente en los resultados de las calculadoras.</li>
              <li>Posibles errores en los resultados derivados de datos introducidos incorrectamente.</li>
              <li>Cambios normativos que puedan no estar reflejados inmediatamente en las calculadoras.</li>
              <li>Interrupciones del servicio por causas técnicas o de mantenimiento.</li>
            </ul>
            <p className="mt-3">Para decisiones importantes (hipotecas, inversiones, cuestiones fiscales o médicas), consulta siempre con un profesional cualificado.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-neutral-900 mb-3">4. Propiedad intelectual</h2>
            <p>Todos los contenidos del Sitio (textos, código, diseño, logotipos, calculadoras) son propiedad de {SITE_CONFIG.name} o de sus licenciantes, y están protegidos por la legislación española e internacional de propiedad intelectual. Queda prohibida su reproducción sin autorización expresa.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-neutral-900 mb-3">5. Publicidad</h2>
            <p>El Sitio se financia mediante publicidad a través de Google AdSense. Los anunciantes son terceros independientes y {SITE_CONFIG.name} no avala ni es responsable de sus productos o servicios.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-neutral-900 mb-3">6. Uso aceptable</h2>
            <p>El usuario se compromete a utilizar el Sitio de forma lícita y a no:</p>
            <ul className="list-disc list-inside mt-2 space-y-1">
              <li>Intentar acceder sin autorización a sistemas informáticos del Sitio.</li>
              <li>Realizar scraping masivo o uso automatizado que perjudique al servicio.</li>
              <li>Publicar o transmitir contenido ilícito, difamatorio o lesivo.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-neutral-900 mb-3">7. Modificaciones</h2>
            <p>{SITE_CONFIG.name} se reserva el derecho de modificar estos términos en cualquier momento. Los cambios se publicarán en esta página con la fecha de actualización. El uso continuado del Sitio tras la publicación de cambios implica su aceptación.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-neutral-900 mb-3">8. Ley aplicable y jurisdicción</h2>
            <p>Estos términos se rigen por la legislación española. Para cualquier controversia, las partes se someten a los juzgados y tribunales competentes de España, renunciando expresamente a cualquier otro fuero que pudiera corresponderles.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-neutral-900 mb-3">9. Contacto</h2>
            <p>Para cualquier consulta: <a href={`mailto:${SITE_CONFIG.email}`} className="text-brand-600 hover:underline">{SITE_CONFIG.email}</a></p>
          </section>
        </div>
      </div>
    </div>
  );
}
