import Link from "next/link";
import { SITE_CONFIG, CALCULATORS, CATEGORIES } from "@/lib/config";

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-neutral-900 text-neutral-300 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main footer grid */}
        <div className="py-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="lg:col-span-1">
            <Link href="/" className="flex items-center gap-2.5 mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-brand-500 to-brand-700 rounded-lg flex items-center justify-center">
                <svg
                  className="w-4 h-4 text-white"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                >
                  <rect x="3" y="3" width="7" height="7" rx="1" />
                  <rect x="14" y="3" width="7" height="7" rx="1" />
                  <rect x="3" y="14" width="7" height="7" rx="1" />
                  <rect x="14" y="14" width="7" height="7" rx="1" />
                </svg>
              </div>
              <span className="font-bold text-white text-sm">
                Calculadoras España
              </span>
            </Link>
            <p className="text-sm text-neutral-400 leading-relaxed mb-4">
              La plataforma de calculadoras gratuitas más completa en español.
              Resultados instantáneos y precisos para tus necesidades diarias.
            </p>
            <p className="text-xs text-neutral-500">
              © {currentYear} {SITE_CONFIG.name}.<br />
              Todos los derechos reservados.
            </p>
          </div>

          {/* Calculadoras */}
          <div>
            <h3 className="text-white font-semibold text-sm mb-4 uppercase tracking-wider" id="footer-calcs">
              Calculadoras
            </h3>
            <ul aria-labelledby="footer-calcs" className="space-y-2.5">
              {CALCULATORS.map((calc) => (
                <li key={calc.id}>
                  <Link
                    href={calc.href}
                    className="text-sm text-neutral-400 hover:text-white transition-colors flex items-center gap-1.5"
                  >
                    <span className="text-base leading-none">{calc.icon}</span>
                    {calc.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Categorías */}
          <div>
            <h3 className="text-white font-semibold text-sm mb-4 uppercase tracking-wider" id="footer-cats">
              Categorías
            </h3>
            <ul aria-labelledby="footer-cats" className="space-y-2.5 mb-6">
              {CATEGORIES.map((cat) => (
                <li key={cat.id}>
                  <Link
                    href={`/calculadoras#${cat.id}`}
                    className="text-sm text-neutral-400 hover:text-white transition-colors flex items-center gap-2"
                  >
                    <span>{cat.icon}</span>
                    {cat.name}
                  </Link>
                </li>
              ))}
            </ul>
            <h3 className="text-white font-semibold text-sm mb-4 uppercase tracking-wider" id="footer-empresa">
              Empresa
            </h3>
            <ul aria-labelledby="footer-empresa" className="space-y-2.5">
              <li>
                <Link
                  href="/contacto"
                  className="text-sm text-neutral-400 hover:text-white transition-colors"
                >
                  Contacto
                </Link>
              </li>
              <li>
                <Link
                  href="/contacto"
                  className="text-sm text-neutral-400 hover:text-white transition-colors"
                >
                  Sobre nosotros
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="text-white font-semibold text-sm mb-4 uppercase tracking-wider" id="footer-legal">
              Legal
            </h3>
            <ul aria-labelledby="footer-legal" className="space-y-2.5 mb-6">
              <li>
                <Link
                  href="/legal/privacidad"
                  className="text-sm text-neutral-400 hover:text-white transition-colors"
                >
                  Política de Privacidad
                </Link>
              </li>
              <li>
                <Link
                  href="/legal/cookies"
                  className="text-sm text-neutral-400 hover:text-white transition-colors"
                >
                  Política de Cookies
                </Link>
              </li>
              <li>
                <Link
                  href="/legal/terminos"
                  className="text-sm text-neutral-400 hover:text-white transition-colors"
                >
                  Términos y Condiciones
                </Link>
              </li>
            </ul>

            {/* Trust badges */}
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-xs text-neutral-500">
                <svg className="w-3.5 h-3.5 text-green-400 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Datos procesados localmente
              </div>
              <div className="flex items-center gap-2 text-xs text-neutral-500">
                <svg className="w-3.5 h-3.5 text-green-400 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Sin registro necesario
              </div>
              <div className="flex items-center gap-2 text-xs text-neutral-500">
                <svg className="w-3.5 h-3.5 text-green-400 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                100% gratuito para siempre
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="py-4 border-t border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-neutral-500">
          <p>
            Las calculadoras son orientativas. Consulta siempre con un profesional para decisiones importantes.
          </p>
          <p>Hecho con ❤️ para España</p>
        </div>
      </div>
    </footer>
  );
}
