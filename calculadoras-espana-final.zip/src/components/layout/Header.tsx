"use client";

import Link from "next/link";
import { useState, useRef, useEffect } from "react";
import { CATEGORIES, CALCULATORS } from "@/lib/config";

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement | null>(null);

  const filtered = search.trim().length >= 2
    ? CALCULATORS.filter(
        (c) =>
          c.name.toLowerCase().includes(search.toLowerCase()) ||
          c.description.toLowerCase().includes(search.toLowerCase()) ||
          c.keywords.some((k) => k.includes(search.toLowerCase()))
      ).slice(0, 6)
    : [];

  // Close search dropdown on outside click
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(e.target as Node | null)) {
        setSearchOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Close mobile menu on route change / ESC
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") {
        setMobileOpen(false);
        setSearchOpen(false);
      }
    }
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, []);

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-neutral-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">

          {/* Logo */}
          <Link href="/" className="flex items-center gap-2.5 flex-shrink-0" aria-label="Calculadoras España — Inicio">
            <div className="w-8 h-8 bg-gradient-to-br from-brand-500 to-brand-700 rounded-lg flex items-center justify-center shadow-sm" aria-hidden="true">
              <svg className="w-5 h-5 text-white" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <rect x="3" y="3" width="7" height="7" rx="1" />
                <rect x="14" y="3" width="7" height="7" rx="1" />
                <rect x="3" y="14" width="7" height="7" rx="1" />
                <rect x="14" y="14" width="7" height="7" rx="1" />
              </svg>
            </div>
            <span className="font-bold text-neutral-900 text-base hidden sm:block leading-tight">
              Calculadoras<br />
              <span className="text-brand-600 text-xs font-semibold tracking-wide uppercase">España</span>
            </span>
          </Link>

          {/* Desktop Search */}
          <div className="hidden md:flex flex-1 max-w-md relative" ref={searchRef}>
            <label htmlFor="header-search" className="sr-only">Buscar calculadora</label>
            <div className="relative w-full">
              <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                id="header-search"
                type="search"
                placeholder="Buscar calculadora..."
                value={search}
                onChange={(e) => { setSearch(e.target.value); setSearchOpen(true); }}
                onFocus={() => setSearchOpen(true)}
                className="w-full pl-9 pr-4 py-2 text-sm bg-neutral-100 border border-neutral-200 rounded-xl text-neutral-900 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-brand-400 focus:border-brand-400 focus:bg-white transition-all"
                autoComplete="off"
                aria-autocomplete="list"
                aria-controls="search-results"
                aria-expanded={searchOpen && filtered.length > 0}
              />
              {searchOpen && filtered.length > 0 && (
                <div
                  id="search-results"
                  role="listbox"
                  aria-label="Resultados de búsqueda"
                  className="absolute top-full left-0 right-0 mt-1.5 bg-white rounded-xl border border-neutral-200 shadow-xl overflow-hidden z-50"
                >
                  {filtered.map((calc) => (
                    <Link
                      key={calc.id}
                      href={calc.href}
                      role="option"
                      aria-selected="false"
                      onClick={() => { setSearch(""); setSearchOpen(false); }}
                      className="flex items-center gap-3 px-4 py-2.5 hover:bg-neutral-50 transition-colors"
                    >
                      <span className="text-lg" aria-hidden="true">{calc.icon}</span>
                      <div>
                        <p className="text-sm font-semibold text-neutral-900">{calc.name}</p>
                        <p className="text-xs text-neutral-500 truncate max-w-xs">{calc.description}</p>
                      </div>
                    </Link>
                  ))}
                  <Link
                    href={`/calculadoras`}
                    onClick={() => { setSearch(""); setSearchOpen(false); }}
                    className="flex items-center justify-center gap-2 px-4 py-2.5 bg-neutral-50 text-xs font-semibold text-brand-600 hover:bg-brand-50 transition-colors border-t border-neutral-100"
                  >
                    Ver todas las calculadoras →
                  </Link>
                </div>
              )}
              {searchOpen && search.trim().length >= 2 && filtered.length === 0 && (
                <div className="absolute top-full left-0 right-0 mt-1.5 bg-white rounded-xl border border-neutral-200 shadow-xl overflow-hidden z-50 px-4 py-3 text-sm text-neutral-500">
                  No se encontraron calculadoras para &ldquo;{search}&rdquo;
                </div>
              )}
            </div>
          </div>

          {/* Desktop nav */}
          <nav className="hidden lg:flex items-center gap-1" aria-label="Categorías de calculadoras">
            {CATEGORIES.map((cat) => (
              <Link
                key={cat.id}
                href={`/calculadoras#${cat.id}`}
                className="px-3 py-1.5 text-sm font-medium text-neutral-600 hover:text-brand-600 hover:bg-brand-50 rounded-lg transition-all"
              >
                {cat.name}
              </Link>
            ))}
            <Link
              href="/calculadoras"
              className="ml-1 px-3 py-1.5 text-sm font-semibold text-brand-600 hover:bg-brand-50 rounded-lg transition-all"
            >
              Todas
            </Link>
          </nav>

          {/* Mobile menu button */}
          <button
            className="lg:hidden p-2 rounded-lg text-neutral-600 hover:bg-neutral-100 transition-colors"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label={mobileOpen ? "Cerrar menú" : "Abrir menú"}
            aria-expanded={mobileOpen}
            aria-controls="mobile-menu"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
              {mobileOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div id="mobile-menu" className="lg:hidden border-t border-neutral-200 bg-white px-4 pb-4 pt-3">
          {/* Mobile search */}
          <div className="relative mb-3">
            <label htmlFor="mobile-search" className="sr-only">Buscar calculadora</label>
            <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              id="mobile-search"
              type="search"
              placeholder="Buscar calculadora..."
              className="w-full pl-9 pr-4 py-2.5 text-sm bg-neutral-100 border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-400 focus:bg-white transition-all"
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <nav aria-label="Menú de navegación móvil">
            <div className="grid grid-cols-2 gap-1.5 mb-3">
              {CATEGORIES.map((cat) => (
                <Link
                  key={cat.id}
                  href={`/calculadoras#${cat.id}`}
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center gap-2 px-3 py-2.5 text-sm font-medium text-neutral-700 bg-neutral-50 hover:bg-brand-50 hover:text-brand-700 rounded-xl transition-all"
                >
                  <span aria-hidden="true">{cat.icon}</span>
                  {cat.name}
                </Link>
              ))}
            </div>
            <Link
              href="/calculadoras"
              onClick={() => setMobileOpen(false)}
              className="flex items-center justify-center gap-2 w-full px-3 py-2.5 text-sm font-semibold text-brand-600 bg-brand-50 hover:bg-brand-100 rounded-xl transition-all"
            >
              Ver todas las calculadoras
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
