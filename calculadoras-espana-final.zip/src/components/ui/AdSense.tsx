"use client";

import { useEffect, useRef } from "react";
import { SITE_CONFIG } from "@/lib/config";

interface AdSenseProps {
  slot: string;
  format?: "auto" | "rectangle" | "leaderboard" | "banner";
  className?: string;
  style?: React.CSSProperties;
}

declare global {
  interface Window {
    adsbygoogle: unknown[];
  }
}

export function AdSense({ slot, format = "auto", className, style }: AdSenseProps) {
  const ref = useRef<HTMLElement | null>(null);
  const pushed = useRef(false);

  useEffect(() => {
    // Only push once per mount; avoid double-push on StrictMode
    if (pushed.current) return;
    pushed.current = true;
    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch {
      // AdSense script not loaded yet — silently ignore
    }
  }, []);

  // Don't render the ins tag if the publisher ID is the placeholder
  if (SITE_CONFIG.adsenseId.includes("XXXXXXXX")) {
    return (
      <div
        className={`ad-placeholder my-6 rounded-xl ${className ?? ""}`}
        style={{ minHeight: 90, ...style }}
        role="complementary"
        aria-label="Espacio publicitario"
      >
        <span className="text-neutral-400 text-xs">Anuncio</span>
      </div>
    );
  }

  return (
    <div className={`adsense-container my-6 ${className ?? ""}`}>
      <ins
        ref={ref}
        className="adsbygoogle"
        style={{ display: "block", ...style }}
        data-ad-client={SITE_CONFIG.adsenseId}
        data-ad-slot={slot}
        data-ad-format={format}
        data-full-width-responsive="true"
      />
    </div>
  );
}

export function AdPlaceholder({
  label = "Publicidad",
  height = 90,
}: {
  label?: string;
  height?: number;
}) {
  return (
    <div
      className="ad-placeholder my-6 rounded-xl"
      style={{ height, minHeight: height }}
      role="complementary"
      aria-label={label}
    >
      <span className="text-neutral-400 text-xs">{label}</span>
    </div>
  );
}

export function AffiliateBlock({
  title,
  description,
  cta,
  href,
  icon,
}: {
  title: string;
  description: string;
  cta: string;
  href: string;
  icon?: string;
}) {
  return (
    <aside className="bg-gradient-to-br from-accent-50 to-orange-50 border border-accent-200 rounded-2xl p-5 my-6">
      <div className="flex items-start gap-3">
        {icon && <span className="text-2xl flex-shrink-0" aria-hidden="true">{icon}</span>}
        <div className="flex-1">
          <h4 className="font-semibold text-neutral-900 mb-1">{title}</h4>
          <p className="text-sm text-neutral-600 mb-3">{description}</p>
          <a
            href={href}
            target="_blank"
            rel="noopener noreferrer sponsored"
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-accent-600 text-white text-sm font-semibold rounded-lg hover:bg-accent-700 transition-colors"
          >
            {cta}
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
            </svg>
            <span className="sr-only">(abre en nueva ventana)</span>
          </a>
        </div>
      </div>
    </aside>
  );
}
