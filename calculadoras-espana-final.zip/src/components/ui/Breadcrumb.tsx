import Link from "next/link";
import { SITE_CONFIG } from "@/lib/config";

interface BreadcrumbItem {
  name: string;
  href: string;
}

interface BreadcrumbProps {
  items: BreadcrumbItem[];
}

export function Breadcrumb({ items }: BreadcrumbProps) {
  const all = [{ name: "Inicio", href: "/" }, ...items];

  const schema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: all.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: item.name,
      // item URL is required for all entries including the current page
      // Google uses this to understand page hierarchy
      item: item.href.startsWith("http")
        ? item.href
        : `${SITE_CONFIG.url}${item.href.startsWith("/") ? item.href : "/" + item.href}`,
    })),
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
      />
      <nav aria-label="Ruta de navegación" aria-describedby={undefined}>
        <ol className="flex items-center gap-1.5 text-sm flex-wrap">
          {all.map((item, index) => {
            const isCurrent = index === all.length - 1;
            return (
              <li key={item.href} className="flex items-center gap-1.5">
                {index > 0 && (
                  <svg
                    className="w-3 h-3 text-neutral-300 flex-shrink-0"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                )}
                {isCurrent ? (
                  <span
                    className="text-neutral-900 font-medium truncate max-w-[200px]"
                    aria-current="page"
                  >
                    {item.name}
                  </span>
                ) : (
                  <Link
                    href={item.href}
                    className="text-neutral-500 hover:text-brand-600 transition-colors"
                  >
                    {item.name}
                  </Link>
                )}
              </li>
            );
          })}
        </ol>
      </nav>
    </>
  );
}
