"use client";

import { useState, useId } from "react";

interface FAQItem {
  question: string;
  answer: string;
}

interface FAQProps {
  items: FAQItem[];
  title?: string;
}

export function FAQ({ items, title = "Preguntas frecuentes" }: FAQProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const baseId = useId();

  // Schema is rendered as a plain script tag — this works fine in "use client"
  // because Next.js hydrates script tags without interference.
  const schema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: items.map((item) => ({
      "@type": "Question",
      name: item.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: item.answer,
      },
    })),
  };

  return (
    <section className="mt-10" aria-labelledby={`${baseId}-title`}>
      {/* JSON-LD injected server-side via dangerouslySetInnerHTML */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
      />
      <h2 id={`${baseId}-title`} className="section-title mb-6">{title}</h2>
      <div className="space-y-2" role="list">
        {items.map((item, index) => {
          const isOpen = openIndex === index;
          const questionId = `${baseId}-q-${index}`;
          const answerId = `${baseId}-a-${index}`;
          return (
            <div
              key={questionId}
              className="bg-white rounded-xl border border-neutral-200 overflow-hidden"
              role="listitem"
            >
              <h3>
                <button
                  id={questionId}
                  onClick={() => setOpenIndex(isOpen ? null : index)}
                  className="w-full flex items-center justify-between gap-4 px-5 py-4 text-left hover:bg-neutral-50 transition-colors"
                  aria-expanded={isOpen}
                  aria-controls={answerId}
                >
                  <span className="font-semibold text-neutral-900 text-sm sm:text-base">
                    {item.question}
                  </span>
                  <svg
                    className={`w-4 h-4 text-neutral-400 flex-shrink-0 transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </h3>
              <div
                id={answerId}
                role="region"
                aria-labelledby={questionId}
                hidden={!isOpen}
              >
                {isOpen && (
                  <div className="px-5 pb-4 pt-0">
                    <p className="text-sm sm:text-base text-neutral-600 leading-relaxed border-t border-neutral-100 pt-3">
                      {item.answer}
                    </p>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
