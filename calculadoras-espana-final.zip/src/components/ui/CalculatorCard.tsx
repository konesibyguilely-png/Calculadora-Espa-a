import Link from "next/link";
import { cn } from "@/lib/utils";

interface CalculatorCardProps {
  icon: string;
  name: string;
  description: string;
  href: string;
  featured?: boolean;
  popular?: boolean;
  category?: string;
  className?: string;
}

export function CalculatorCard({
  icon,
  name,
  description,
  href,
  featured,
  popular,
  className,
}: CalculatorCardProps) {
  return (
    <article className={cn("group", className)}>
      <Link
        href={href}
        className="block card-hover p-5 h-full flex flex-col"
        aria-label={`${name} — ${description}`}
      >
        <div className="flex items-start justify-between mb-3">
          <div
            className="w-11 h-11 flex items-center justify-center bg-brand-50 rounded-xl text-2xl group-hover:bg-brand-100 transition-colors"
            aria-hidden="true"
          >
            {icon}
          </div>
          <div className="flex gap-1.5">
            {popular && (
              <span className="px-2 py-0.5 text-xs font-semibold bg-accent-100 text-accent-700 rounded-full">
                Popular
              </span>
            )}
            {featured && !popular && (
              <span className="px-2 py-0.5 text-xs font-semibold bg-brand-100 text-brand-700 rounded-full">
                Destacado
              </span>
            )}
          </div>
        </div>
        <h3 className="font-semibold text-neutral-900 text-base mb-1.5 group-hover:text-brand-700 transition-colors">
          {name}
        </h3>
        <p className="text-sm text-neutral-500 leading-relaxed flex-1">
          {description}
        </p>
        <div className="flex items-center gap-1 mt-4 text-xs font-semibold text-brand-600 group-hover:gap-2 transition-all" aria-hidden="true">
          Usar calculadora
          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </Link>
    </article>
  );
}
