export const SITE_CONFIG = {
  name: "Calculadoras España",
  shortName: "CalcES",
  description:
    "Las mejores calculadoras gratuitas en español. IVA, hipoteca, interés compuesto, IMC, EVAU, edad y muchas más. Resultados instantáneos y precisos.",
  url: "https://calculadoras-espana.es",
  locale: "es_ES",
  author: "Calculadoras España",
  email: "contacto@calculadoras-espana.es",
  twitter: "@calculadoras_es",
  adsenseId: "ca-pub-XXXXXXXXXXXXXXXX", // Replace with real AdSense ID
};

export const CATEGORIES = [
  {
    id: "finanzas",
    name: "Finanzas",
    description: "Calculadoras financieras para tus decisiones económicas",
    icon: "💰",
    color: "brand",
    slug: "finanzas",
  },
  {
    id: "educacion",
    name: "Educación",
    description: "Calculadoras para estudiantes y notas académicas",
    icon: "📚",
    color: "purple",
    slug: "educacion",
  },
  {
    id: "salud",
    name: "Salud",
    description: "Calculadoras para tu bienestar y salud",
    icon: "❤️",
    color: "red",
    slug: "salud",
  },
  {
    id: "utilidades",
    name: "Utilidades",
    description: "Herramientas de cálculo para el día a día",
    icon: "🔧",
    color: "green",
    slug: "utilidades",
  },
];

export const CALCULATORS = [
  {
    id: "iva",
    name: "Calculadora de IVA",
    description:
      "Calcula el IVA de cualquier producto o servicio al instante. Tipos general (21%), reducido (10%) y superreducido (4%).",
    category: "finanzas",
    slug: "iva",
    href: "/calculadoras/iva",
    icon: "💶",
    featured: true,
    popular: true,
    keywords: ["iva", "impuesto", "precio sin iva", "precio con iva"],
  },
  {
    id: "hipoteca",
    name: "Calculadora de Hipoteca",
    description:
      "Calcula tu cuota mensual, el total a pagar y el desglose de amortización de tu hipoteca en España.",
    category: "finanzas",
    slug: "hipoteca",
    href: "/calculadoras/hipoteca",
    icon: "🏠",
    featured: true,
    popular: true,
    keywords: ["hipoteca", "cuota mensual", "prestamo", "amortizacion"],
  },
  {
    id: "interes-compuesto",
    name: "Calculadora de Interés Compuesto",
    description:
      "Descubre el poder del interés compuesto. Calcula el crecimiento de tus inversiones a lo largo del tiempo.",
    category: "finanzas",
    slug: "interes-compuesto",
    href: "/calculadoras/interes-compuesto",
    icon: "📈",
    featured: true,
    popular: false,
    keywords: ["interes compuesto", "inversion", "ahorro", "rentabilidad"],
  },
  {
    id: "evau",
    name: "Calculadora EVAU",
    description:
      "Calcula tu nota de acceso a la universidad (EVAU/Selectividad) con las ponderaciones de cada carrera.",
    category: "educacion",
    slug: "evau",
    href: "/calculadoras/evau",
    icon: "🎓",
    featured: true,
    popular: true,
    keywords: ["evau", "selectividad", "nota de corte", "universidad"],
  },
  {
    id: "bachillerato",
    name: "Calculadora Bachillerato",
    description:
      "Calcula tu nota media de Bachillerato ponderando las asignaturas según sus créditos.",
    category: "educacion",
    slug: "bachillerato",
    href: "/calculadoras/bachillerato",
    icon: "📖",
    featured: false,
    popular: false,
    keywords: ["bachillerato", "nota media", "asignaturas", "expediente"],
  },
  {
    id: "imc",
    name: "Calculadora IMC",
    description:
      "Calcula tu Índice de Masa Corporal (IMC) y descubre si tienes un peso saludable según la OMS.",
    category: "salud",
    slug: "imc",
    href: "/calculadoras/imc",
    icon: "⚖️",
    featured: true,
    popular: true,
    keywords: ["imc", "indice de masa corporal", "peso ideal", "obesidad"],
  },
  {
    id: "edad",
    name: "Calculadora de Edad",
    description:
      "Calcula tu edad exacta en años, meses, días, horas y minutos desde tu fecha de nacimiento.",
    category: "utilidades",
    slug: "edad",
    href: "/calculadoras/edad",
    icon: "🎂",
    featured: false,
    popular: true,
    keywords: ["calcular edad", "fecha nacimiento", "años cumplidos"],
  },
  {
    id: "diferencia-fechas",
    name: "Diferencia entre Fechas",
    description:
      "Calcula los días, semanas, meses y años entre dos fechas cualesquiera con precisión.",
    category: "utilidades",
    slug: "diferencia-fechas",
    href: "/calculadoras/diferencia-fechas",
    icon: "📅",
    featured: false,
    popular: false,
    keywords: ["diferencia fechas", "dias entre fechas", "calcular tiempo"],
  },
];
